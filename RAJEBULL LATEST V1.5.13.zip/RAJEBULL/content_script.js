const popUpObserver = setInterval(() => {
  const _0x58bd9d = document.querySelector(
    'button.btn.btn-primary[aria-label*="Press OK to confirm"]'
  )
  _0x58bd9d &&
    (console.log('Rajebull : Initial confirmation pop-up found. Clicking OK.'),
    _0x58bd9d.click(),
    clearInterval(popUpObserver))
}, 500)
function showOnScreenNotification(_0x34d54a, _0x501e93 = 4000) {
  const _0x5000b3 = document.getElementById('ocean-fallback-notification')
  _0x5000b3 && _0x5000b3.remove()
  const _0x2d8df1 = document.createElement('div')
  _0x2d8df1.id = 'ocean-fallback-notification'
  _0x2d8df1.textContent = '[OCEAN]: ' + _0x34d54a
  Object.assign(_0x2d8df1.style, {
    position: 'fixed',
    top: '20px',
    left: '50%',
    transform: 'translateX(-50%)',
    backgroundColor: 'rgba(217, 30, 24, 0.9)',
    color: 'white',
    padding: '12px 25px',
    borderRadius: '8px',
    zIndex: '99999',
    fontSize: '16px',
    fontWeight: 'bold',
    boxShadow: '0 4px 15px rgba(0,0,0,0.3)',
  })
  document.body.appendChild(_0x2d8df1)
  setTimeout(() => {
    const _0x4447bc = document.getElementById('ocean-fallback-notification')
    _0x4447bc && _0x4447bc.remove()
  }, _0x501e93)
}
function injectAnimationAssets() {
  if (document.getElementById('ocean-animation-script')) {
    console.log('Rajebull : Animation assets already present.')
    return
  }
  console.log('Rajebull : Injecting animation assets...')
  const _0xbfb110 = document.createElement('link')
  _0xbfb110.id = 'ocean-animation-style'
  _0xbfb110.rel = 'stylesheet'
  _0xbfb110.type = 'text/css'
  _0xbfb110.href = chrome.runtime.getURL('animation.css')
  document.head.appendChild(_0xbfb110)
  const _0x39c96c = document.createElement('script')
  _0x39c96c.id = 'ocean-animation-script'
  _0x39c96c.src = chrome.runtime.getURL('animation.js')
  ;(document.head || document.documentElement).appendChild(_0x39c96c)
  _0x39c96c.onload = () => {
    console.log('OCEAN: animation.js loaded successfully.')
    _0x39c96c.remove()
  }
  _0x39c96c.onerror = () => {
    console.error('Rajebull : Failed to load animation.js.')
  }
}
function dispatchInitialData(_0x1a5fb0) {
  const _0x352cf2 = window.location.href
  let _0x3677a7 = 'loadLoginDetails'
  if (_0x352cf2.includes('booking/psgninput')) {
    _0x3677a7 = 'fillPassengerDetails'
  } else {
    if (_0x352cf2.includes('booking/reviewBooking')) {
      _0x3677a7 = 'reviewBooking'
    } else {
      if (_0x352cf2.includes('payment/bkgPaymentOptions')) {
        _0x3677a7 = 'bkgPaymentOptions'
      } else {
        if (_0x352cf2.includes('booking/train-list')) {
          _0x3677a7 = 'selectJourney'
        } else {
          if (_0x352cf2.includes('nget/train-search')) {
            const _0x55c73a = document.querySelector(
              'a.loginText.ng-star-inserted'
            )
            _0x55c73a &&
              _0x55c73a.innerText.trim().toUpperCase() === 'LOGOUT' &&
              (_0x3677a7 = 'loadJourneyDetails')
          }
        }
      }
    }
  }
  const _0x10b497 = _0x1a5fb0.journey_details || {}
  _0x1a5fb0.irctc_credentials &&
    _0x1a5fb0.irctc_credentials.user_name &&
    (_0x10b497.username = _0x1a5fb0.irctc_credentials.user_name)
  const _0x104e03 = {
    journeyDetails: _0x10b497,
    initialStatus: _0x3677a7,
  }
  console.log("Rajebull : Dispatching 'Rajebull -init-data' with payload:", _0x104e03)
  setTimeout(() => {
    document.dispatchEvent(
      new CustomEvent('ocean-init-data', { detail: _0x104e03 })
    )
  }, 500)
}
function statusUpdate(_0xadbaca) {
  const _0x50fab0 = {
    status: _0xadbaca,
    time: new Date().toString().split(' ')[4],
  }
  chrome.runtime.sendMessage(getMsg(_0x50fab0, 'status_update'))
  console.log(
    "Rajebull : Dispatching 'Rajebull -status-update' for [" + _0xadbaca + ']'
  )
  const _0xa96ac = user_data.journey_details || {}
  user_data.irctc_credentials &&
    user_data.irctc_credentials.user_name &&
    (_0xa96ac.username = user_data.irctc_credentials.user_name)
  const _0x2d1ee8 = {
    statusKey: _0xadbaca,
    journeyDetails: _0xa96ac,
  }
  document.dispatchEvent(
    new CustomEvent('ocean-status-update', { detail: _0x2d1ee8 })
  )
}
function fastFill(_0x52a1b0, _0x5143fe) {
  if (!_0x52a1b0 || typeof _0x5143fe !== 'string') {
    console.warn('Element not provided or text is not a string for fastFill.')
    return
  }
  _0x52a1b0.focus()
  _0x52a1b0.value = _0x5143fe
  _0x52a1b0.dispatchEvent(
    new Event('input', {
      bubbles: true,
      cancelable: true,
    })
  )
  _0x52a1b0.dispatchEvent(
    new Event('change', {
      bubbles: true,
      cancelable: true,
    })
  )
  _0x52a1b0.blur()
}
function fastClick(_0x2759cf) {
  if (_0x2759cf && typeof _0x2759cf.click === 'function') {
    if (_0x2759cf.disabled) {
      console.warn('Attempted to click on a disabled element:', _0x2759cf)
      return
    }
    _0x2759cf.click()
  } else {
    console.warn('Attempted to click on an invalid element:', _0x2759cf)
  }
}
function addDelay(_0x1d6f3f) {
  const _0xb72a1d = Date.now()
  let _0x1198e8 = null
  do {
    _0x1198e8 = Date.now()
  } while (_0x1198e8 - _0xb72a1d < _0x1d6f3f)
}
function showCustomAlert(_0x1fd232) {
  const _0x1f16f9 = document.createElement('div')
  _0x1f16f9.id = 'custom-alert'
  _0x1f16f9.style.cssText =
    "\n        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n        background-color: #fff; border: 1px solid #ccc; border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); padding: 20px; z-index: 10000;\n        text-align: center; font-family: 'Inter', sans-serif; max-width: 90%; width: 300px;\n    "
  _0x1f16f9.innerHTML =
    '\n        <p class="text-lg font-semibold mb-4">' +
    _0x1fd232 +
    '</p>\n        <button id="custom-alert-ok" class="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">OK</button>\n    '
  document.body.appendChild(_0x1f16f9)
  document.getElementById('custom-alert-ok').onclick = () => _0x1f16f9.remove()
}
function showCustomConfirm(_0x237d24, _0x55d0db, _0x26b640) {
  const _0x1a1cbc = document.createElement('div')
  _0x1a1cbc.id = 'custom-confirm'
  _0x1a1cbc.style.cssText =
    "\n        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n        background-color: #fff; border: 1px solid #ccc; border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); padding: 20px; z-index: 10000;\n        text-align: center; font-family: 'Inter', sans-serif; max-width: 90%; width: 350px;\n    "
  _0x1a1cbc.innerHTML =
    '\n        <p class="text-lg font-semibold mb-4">' +
    _0x237d24 +
    '</p>\n        <button id="custom-confirm-yes" class="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 mr-2">Yes</button>\n        <button id="custom-confirm-no" class="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600">No</button>\n    '
  document.body.appendChild(_0x1a1cbc)
  document.getElementById('custom-confirm-yes').onclick = () => {
    _0x1a1cbc.remove()
    if (_0x55d0db) {
      _0x55d0db()
    }
  }
  document.getElementById('custom-confirm-no').onclick = () => {
    _0x1a1cbc.remove()
    if (_0x26b640) {
      _0x26b640()
    }
  }
}
const isElementVisibleAndInteractable = (_0x3cc21d) => {
  return (
    _0x3cc21d &&
    getComputedStyle(_0x3cc21d).display !== 'none' &&
    getComputedStyle(_0x3cc21d).visibility !== 'hidden' &&
    parseFloat(getComputedStyle(_0x3cc21d).opacity) > 0 &&
    !_0x3cc21d.disabled
  )
}
let user_data = {}
function getMsg(_0x5ec853, _0x320567) {
  return {
    msg: {
      type: _0x320567,
      data: _0x5ec853,
    },
    sender: 'content_script',
    id: 'irctc',
  }
}
function classTranslator(_0x34917c) {
  return '1A' === _0x34917c
    ? 'AC First Class (1A)'
    : 'EV' === _0x34917c
    ? 'Vistadome AC (EV)'
    : 'EC' === _0x34917c
    ? 'Exec. Chair Car (EC)'
    : '2A' === _0x34917c
    ? 'AC 2 Tier (2A)'
    : '3A' === _0x34917c
    ? 'AC 3 Tier (3A)'
    : '3E' === _0x34917c
    ? 'AC 3 Economy (3E)'
    : 'CC' === _0x34917c
    ? 'AC Chair car (CC)'
    : 'SL' === _0x34917c
    ? 'Sleeper (SL)'
    : '2S' === _0x34917c
    ? 'Second Sitting (2S)'
    : 'None'
}
function quotaTranslator(_0x1d3938) {
  return 'GN' === _0x1d3938
    ? 'GENERAL'
    : 'TQ' === _0x1d3938
    ? 'TATKAL'
    : 'PT' === _0x1d3938
    ? 'PREMIUM TATKAL'
    : 'LD' === _0x1d3938
    ? 'LADIES'
    : 'SR' === _0x1d3938
    ? 'LOWER BERTH/SR.CITIZEN'
    : ''
}
console.log('[Rajebull  Log] Step 1: content_script.js loaded successfully.')
let animationHasRun = false
function waitForPnrAndShowAnimation() {
  if (animationHasRun) {
    console.log('[Rajebull  Log] Step 4a: Animation has already run. Skipping.')
    return
  }
  console.log(
    "[Rajebull  Log] Step 4: Starting to check for BOTH 'PNR' and 'CNF' text on the page..."
  )
  const _0x3c43b1 = setInterval(() => {
    if (animationHasRun) {
      clearInterval(_0x3c43b1)
      return
    }
    console.log(
      '[Rajebull  Log] Step 4.1: Interval running... searching for elements.'
    )
    let _0x32be3c = false,
      _0x37e396 = false
    const _0x2fd93d = document.querySelectorAll('span, strong, div, p, a')
    for (const _0x20ab49 of _0x2fd93d) {
      if (_0x20ab49.offsetParent !== null && _0x20ab49.textContent) {
        const _0x2d7b12 = _0x20ab49.textContent.toUpperCase()
        _0x2d7b12.includes('PNR') &&
          ((_0x32be3c = true),
          console.log("[Rajebull  Log] Found 'PNR' text in element:", _0x20ab49))
        _0x2d7b12.includes('CNF') &&
          ((_0x37e396 = true),
          console.log("[Rajebull  Log] Found 'CNF' text in element:", _0x20ab49))
      }
    }
    _0x32be3c &&
      _0x37e396 &&
      (console.log(
        '[Rajebull  Log] Step 5: Success condition met! BOTH elements found.'
      ),
      clearInterval(_0x3c43b1),
      console.log('[Rajebull  Log] Step 5.1: Interval stopped.'),
      (animationHasRun = true),
      showPnrAnimation())
  }, 700)
}

 
async function showPnrAnimation() {
  console.log('[Rajebull  Log] Step 6: showPnrAnimation() function called.');
  try {
    console.log('[Rajebull  Log] Step 6.1: Attempting to get data from chrome.storage.');
    const _0x84ac2f = await chrome.storage.local.get([
        'journey_details',
        'other_preferences',
      ]),
      _0x44ce89 = _0x84ac2f.journey_details || {},
      _0x2d076d = _0x84ac2f.other_preferences || {};

    console.log('[Rajebull  Log] Step 6.2: Journey details from storage:', _0x44ce89);
    console.log('[Rajebull  Log] Step 6.2a: Other preferences from storage:', _0x2d076d);

    const _0x5e3649 = new Date();
    _0x5e3649.setSeconds(_0x5e3649.getSeconds() - 15);
    const _0x1c8eea = _0x5e3649.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      }),
      _0x1ca84d = _0x44ce89.from ? _0x44ce89.from.split('-') : [],
      _0x1491de = _0x44ce89.destination ? _0x44ce89.destination.split('-') : [],
      _0x2f3eab = _0x44ce89.date ? _0x44ce89.date.split('-') : [],
      _0x24541c = _0x1ca84d.length > 1 ? _0x1ca84d[1].trim() : _0x44ce89.from || '',
      _0x2b177d = _0x1491de.length > 1 ? _0x1491de[1].trim() : _0x44ce89.destination || '',
      _0x3ee96a = _0x2f3eab.length === 3 ? _0x2f3eab[2] + '-' + _0x2f3eab[1] + '-' + _0x2f3eab[0] : '',
      _0x510e07 = _0x44ce89.class || '',
      _0x594c21 = _0x44ce89.quota || '',
      _0x78316f = _0x44ce89['train-no'] || 'Train N/A',
      _0x20470e = (_0x24541c + '-' + _0x2b177d + ' ' + _0x3ee96a + ' ' + _0x510e07 + ' ' + _0x594c21).trim();

    let _0x5a881d = 'N/A';
    const _0x128b36 = _0x2d076d.paymentmethod || '';
    switch (_0x128b36) {
      case 'PAYTMUPI':
        _0x5a881d = 'Paytm UPI';
        break;
      case 'PHONEPEUPIQR':
        _0x5a881d = 'PhonePe QR';
        break;
      case 'RAZORPAYUPI':
        _0x5a881d = 'Razorpay UPI';
        break;
      case 'PAYUUPI':
        _0x5a881d = 'PayU UPI';
        break;
      case 'AMZPAYWAL':
        _0x5a881d = 'Amazon Pay';
        break;
      case 'HDFCDB':
        _0x5a881d = 'HDFC DC';
        break;
      case 'kotak_dc':
        _0x5a881d = 'KOTAK DC';
        break;
      case 'MOBIKWIKWAL':
        _0x5a881d = 'MOBIKWIK';
        break;
      case 'SBINETBANKING':
        _0x5a881d = 'SBI_NB';
        break;
      case 'IRCWA':
        _0x5a881d = 'IRCTC eWallet';
        break;
      case 'irctc_dc':
      case 'IRCUPIID':
      case 'IRCUPIQR':
        _0x5a881d = 'IRCTC iPay';
        break;
      default:
        _0x5a881d = _0x128b36;
    }

    console.log('[Rajebull  Log] Payment method determined as: ' + _0x5a881d);

    let _0x4a3ecd = 'N/A';
    const _0x5f6632 = [
      '.line-def .orange-text strong',
      'span.pull-right.orange-text strong',
      'span.font-bold.pull-right',
      '.fare-summary .amount',
    ];
    for (const _0x50a888 of _0x5f6632) {
      const _0x275f9f = document.querySelector(_0x50a888);
      if (_0x275f9f) {
        const _0x22e650 = _0x275f9f.innerText.replace(/[^0-9.]/g, '');
        if (_0x22e650) {
          _0x4a3ecd = _0x22e650;
          console.log("[Rajebull  Log] Fare found with selector '" + _0x50a888 + "': " + _0x4a3ecd);
          break;
        }
      }
    }

    const _0x300f47 = 'FARE,' + _0x4a3ecd;
    console.log('[Rajebull  Log] Step 6.3: All data processed. Creating CSS and pop-up now.');

    const _0x4a4c98 = document.createElement('style');
    _0x4a4c98.id = 'ocean-tatkal-style-v2';
    _0x4a4c98.textContent = `
            .ocean-tatkal-success-message {
                position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%);
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2); z-index: 99999;
                border-radius: 16px; overflow: hidden; text-align: center;
                width: 90%; max-width: 420px; background: #22313f; font-family: 'Roboto', sans-serif;
                border: 3px solid #4acfde;
            }
            .ocean-tatkal-success-message .ticket-header {
                background: linear-gradient(90deg, #4acfde, #197d9c); padding: 1rem 1.5rem;
                text-align: center; font-family: 'Montserrat', sans-serif; font-weight: 700;
                font-size: 1.5rem; letter-spacing: 1.1px; text-transform: uppercase;
            }
            .ocean-tatkal-success-message .ticket-body {
                padding: 1.5rem 2rem; color: #fff;
            }
            .ticket-info-row {
                display: flex; align-items: center; margin-bottom: 1rem;
                font-weight: 700; font-size: 1.1rem;
            }
            .ticket-info-icon {
                width: 28px; height: 28px; margin-right: 0.8rem;
            }
            .ticket-info-label { flex-basis: 140px; color: #50e3e0; }
            .ticket-info-value { flex-grow: 1; color: #f0f5f9; font-weight: 700; }
            .border-accent { border-top: 2px dashed #4acfde; margin: 1.5rem 0; }
            .ticket-train-info { font-size: 1.15rem; font-weight: 700; color: #a8d8ea; } 
            .ticket-info-icon {
              fill: #50e3e0;
            }  .ticket-header{ color: white; } 

          `;
    document.head.appendChild(_0x4a4c98);

    const _0x30df42 = document.createElement('div');
    _0x30df42.className = 'ocean-tatkal-success-message';
    _0x30df42.innerHTML = `
            <header class="ticket-header"> Success By Rajebull  </header>
            <section class="ticket-body">
                <div class="ticket-info-row">
                    <svg class="ticket-info-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                        <path d="M12 1.75C6.07 1.75 1.5 6.32 1.5 12.25S6.07 23 12 23 22.5 18.43 22.5 12.5 17.93 1.75 12 1.75zm0 18.5a7.75 7.75 0 1 1 0-15.5 7.75 7.75 0 0 1 0 15.5zM11.25 6v7.5l6.25 3.75.75-1.23-5.75-3.47V6z"/>
                    </svg>
                    <div class="ticket-info-label">Fare</div>
                    <div class="ticket-info-value">₹ ${_0x4a3ecd}</div>
                </div>

                <div class="ticket-info-row">
                    <svg class="ticket-info-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                        <path d="M12 4a8 8 0 1 0 8 8h-1.5a6.5 6.5 0 1 1-6.5-6.5V4z"/>
                        <path d="M12 7.75c-.414 0-.75.336-.75.75v3.19l2.22 1.33.78-1.28-1.75-1.04V8.5c0-.414-.336-.75-.75-.75z"/>
                    </svg>
                    <div class="ticket-info-label">PNR Time</div>
                    <div class="ticket-info-value">${_0x1c8eea}</div>
                </div>

                <div class="ticket-info-row">
                    <svg class="ticket-info-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                        <path d="M7 4v16l10-8-10-8z"/>
                    </svg>
                    <div class="ticket-info-label">Payment</div>
                    <div class="ticket-info-value">${_0x5a881d}</div>
                </div>

                <div class="border-accent"></div>

                <div class="ticket-train-info">
                    <strong>${_0x20470e}</strong> <br/>
                    <strong>Train:</strong> ${_0x78316f}
                </div>
            </section>
        `;
    document.body.appendChild(_0x30df42);

    console.log('[Rajebull  Log] Step 7: Success message displayed on the page. All done!');
  } catch (_0x55c72c) {
    console.error('[Rajebull  Log] Critical Error in showPnrAnimation:', _0x55c72c);
  }
}
console.log('[Rajebull  Log] Step 2: Setting up message listener.')
chrome.runtime.onMessage.addListener((_0x404fc8, _0x31db2c, _0x5d8233) => {
  const _0x199bd1 =
    (_0x404fc8 && _0x404fc8.type) ||
    (_0x404fc8 && _0x404fc8.msg && _0x404fc8.msg.type)
  _0x199bd1 === 'showPnrAnimation' &&
    (console.log(
      "[Rajebull  Log] Step 3: Message 'showPnrAnimation' received. Triggering animation check."
    ),
    waitForPnrAndShowAnimation(),
    _0x5d8233({ status: 'PNR check initiated.' }))
})
chrome.runtime.onMessage.addListener(
  async (_0x1c8cf9, _0x73a840, _0x1bdf33) => {
    if ('irctc' !== _0x1c8cf9.id) {
      return void _0x1bdf33('Invalid ID')
    }
    const _0x78fd4f = _0x1c8cf9.msg.type
    if ('selectJourney' === _0x78fd4f) {
      console.log('selectJourney action received')
      statusUpdate('selectJourney')
      let _0x33f80c = document.querySelectorAll('.btn.btn-primary')
      _0x33f80c.length > 1 &&
        _0x33f80c[1] &&
        (fastClick(_0x33f80c[1]), console.log('Close last trxn popup'))
      const _0x52367f = document.querySelector(
        '#divMain > div > app-train-list'
      )
      if (!_0x52367f) {
        console.error('Train list container not found for selectJourney.')
        return
      }
      const _0x49e702 = [
          ..._0x52367f.querySelectorAll('.tbis-div app-train-avl-enq'),
        ],
        _0x264fa2 = user_data.journey_details['train-no']
      if (!_0x264fa2) {
        console.error('Train number missing in user_data for selectJourney.')
        return
      }
      const _0x2eea99 = _0x49e702.find((_0x54c948) =>
        _0x54c948
          .querySelector('div.train-heading')
          ?.innerText.trim()
          .includes(_0x264fa2.split('-')[0])
      )
      if ('M' === user_data.travel_preferences.AvailabilityCheck) {
        return void showCustomAlert(
          'Please manually select train and click Book'
        )
      }
      if (
        'A' === user_data.travel_preferences.AvailabilityCheck ||
        'I' === user_data.travel_preferences.AvailabilityCheck
      ) {
        if (!_0x2eea99) {
          return void showCustomAlert(
            'Precheck - Train (' +
              _0x264fa2 +
              ') not found. Proceed manually or correct data.'
          )
        }
        const _0x522eb8 = classTranslator(user_data.journey_details.class)
        if (
          ![..._0x2eea99.querySelectorAll('table tr td div.pre-avl')].find(
            (_0x20161c) =>
              _0x20161c.querySelector('div')?.innerText === _0x522eb8
          )
        ) {
          return void showCustomAlert(
            'Precheck - Selected Class not available. Proceed manually or correct data.'
          )
        }
      }
      const _0x356c76 = document.querySelector(
        'div.row.col-sm-12.h_head1 > span > strong'
      )
      if ('A' === user_data.travel_preferences.AvailabilityCheck) {
        if (['TQ', 'PT', 'GN'].includes(user_data.journey_details.quota)) {
          console.log('Verify tatkal/general time')
          const _0x2d711c = user_data.journey_details.class
          let _0x2b5204 = '00:00:00'
          ;['1A', '2A', '3A', 'CC', 'EC', '3E'].includes(
            _0x2d711c.toUpperCase()
          )
            ? (_0x2b5204 = user_data.other_preferences.acbooktime)
            : (_0x2b5204 = user_data.other_preferences.slbooktime)
          if ('GN' === user_data.journey_details.quota) {
            _0x2b5204 = user_data.other_preferences.gnbooktime
          }
          console.log('Required Booking Time:', _0x2b5204)
          var _0x2a544e = 0
          let _0x28a268 = new MutationObserver(() => {
            let _0xdbce58 = new Date().toString().split(' ')[4]
            console.log('Current Time for booking:', _0xdbce58)
            if (_0xdbce58 >= _0x2b5204) {
              _0x28a268.disconnect()
              selectJourney()
            } else {
              if (_0x2a544e === 0) {
                try {
                  const _0x3b8535 = document.createElement('div')
                  _0x3b8535.textContent =
                    'Please wait... Booking will start at ' + _0x2b5204
                  Object.assign(_0x3b8535.style, {
                    textAlign: 'center',
                    color: 'white',
                    height: 'auto',
                    fontSize: '20px',
                  })
                  document
                    .querySelector(
                      '#divMain > div > app-train-list > div > div > div > div.clearfix'
                    )
                    ?.insertAdjacentElement('afterend', _0x3b8535)
                } catch (_0x405b6f) {
                  console.log('Wait message display failed', _0x405b6f)
                }
              }
              try {
                const _0x51ecab = document.querySelector(
                  '#divMain > div > app-train-list > div > div > div > div:nth-child(2)'
                )
                if (_0x51ecab) {
                  _0x51ecab.style.background =
                    _0x2a544e % 2 === 0 ? 'green' : 'red'
                }
              } catch (_0xdc853c) {
                console.log('Wait indicator style failed', _0xdc853c)
              }
              _0x2a544e++
            }
          })
          if (_0x356c76) {
            _0x28a268.observe(_0x356c76, {
              childList: true,
              subtree: true,
              characterDataOldValue: true,
            })
          } else {
            console.warn('Header element for time observer not found.')
          }
        } else {
          selectJourney()
        }
      } else {
        'I' === user_data.travel_preferences.AvailabilityCheck &&
          selectJourney()
      }
    } else {
      if ('fillPassengerDetails' === _0x78fd4f) {
        statusUpdate('fillPassengerDetails')
        await fillPassengerDetails()
      } else {
        if ('reviewBooking' === _0x78fd4f) {
          statusUpdate('reviewBooking')
          if (user_data.fare_limit?.enableFareLimit) {
            let _0x37be37 = 0
            const _0x1b5e5f = [
              '#fare-summary .col-xs-12.line-def.top-header span.pull-right strong',
              '.total-fare',
              '#totalAmount',
              '.fare-summary span.amount',
              'span.fare-value',
              '.fare-breakup-summary .fare-amount',
              "div.fare-detail-item:has(span.fare-label:contains('Total Fare')) span.fare-value",
              'div.col-sm-12.fare-summary div.col-sm-6.text-right.font-small-bold',
              'div.fare-breakup-summary div.fare-amount',
              'div.fare-detail-item:nth-child(5) > div:nth-child(2)',
              'div.col-sm-6.text-right.font-small-bold',
            ]
            for (const _0x516cf0 of _0x1b5e5f) {
              const _0x1becc7 = document.querySelector(_0x516cf0)
              if (_0x1becc7?.innerText.match(/(\d[\d,]*\.?\d*)/)) {
                _0x37be37 = parseFloat(
                  _0x1becc7.innerText.replace(/[^0-9.]/g, '')
                )
                if (!isNaN(_0x37be37)) {
                  console.log(
                    'Found total fare ' +
                      _0x37be37 +
                      ' using "' +
                      _0x516cf0 +
                      '"'
                  )
                  break
                }
              }
            }
            if (!isNaN(_0x37be37) && _0x37be37 > 0) {
              const _0x15ba1d = parseFloat(user_data.fare_limit.maxFareAmount)
              if (!isNaN(_0x15ba1d) && _0x37be37 > _0x15ba1d) {
                return showCustomConfirm(
                  'Total fare (' +
                    _0x37be37 +
                    ') exceeds limit (' +
                    _0x15ba1d +
                    '). Proceed?',
                  () => proceedAfterFareCheck(),
                  () => {
                    showCustomAlert('Booking cancelled due to high fare.')
                    window.location.href =
                      'https://www.irctc.co.in/nget/train-search'
                  }
                )
              }
            } else {
              console.warn('Could not determine total fare for limit check.')
            }
          }
          await proceedAfterFareCheck()
        } else {
          if ('bkgPaymentOptions' === _0x78fd4f) {
            statusUpdate('bkgPaymentOptions')
            console.log('Rajebull : bkgPaymentOptions action received.')
            const _0x231bb0 = setInterval(async () => {
              if (document.getElementsByClassName('bank-type').length > 1) {
                clearInterval(_0x231bb0)
                const _0x5500ca = user_data.other_preferences.paymentmethod,
                  _0x2d4ad9 = user_data.other_preferences.backup_payment_method,
                  _0x450975 = async (_0x53054c) => {
                    if (!_0x53054c) {
                      return {
                        success: false,
                        optionText: 'None',
                      }
                    }
                    let _0x484816, _0x43ee9a
                    console.log(
                      'Rajebull : Attempting to execute payment for: ' + _0x53054c
                    )
                    if (_0x53054c.includes('PAYTMUPI')) {
                      _0x484816 = 'BHIM/ UPI/ USSD'
                      _0x43ee9a = 'Pay using BHIM (Powered by PAYTM )'
                    } else {
                      if (_0x53054c.includes('PHONEPEUPIQR')) {
                        _0x484816 = 'Multiple Payment Service'
                        _0x43ee9a = 'Powered by PhonePe'
                      } else {
                        if (_0x53054c.includes('RAZORPAYUPI')) {
                          _0x484816 = 'Multiple Payment Service'
                          _0x43ee9a =
                            'Credit & Debit cards / Net Banking / UPI (Powered by Razorpay)'
                        } else {
                          if (_0x53054c.includes('PAYUUPI')) {
                            _0x484816 = 'Multiple Payment Service'
                            _0x43ee9a =
                              'Credit & Debit cards /Net Banking/Wallets/UPI/ International Cards (Powered by PayU)'
                          } else {
                            if (_0x53054c.includes('AMZPAYWAL')) {
                              _0x484816 = 'Wallets / Cash Card'
                              _0x43ee9a = 'Amazon Pay'
                            } else {
                              if (_0x53054c.includes('MOBIKWIKWAL')) {
                                _0x484816 = 'Wallets / Cash Card'
                                _0x43ee9a = 'Mobikwik Wallet'
                              } else {
                                if (_0x53054c.includes('HDFCDB')) {
                                  _0x484816 =
                                    'Payment Gateway / Credit Card / Debit Card'
                                  _0x43ee9a = 'Powered By HDFC BANK'
                                } else {
                                  if (_0x53054c.includes('kotak_dc')) {
                                    _0x484816 =
                                      'Payment Gateway / Credit Card / Debit Card'
                                    _0x43ee9a = 'Powered by KOTAK BANK'
                                  } else {
                                    if (_0x53054c.includes('SBINETBANKING')) {
                                      _0x484816 = 'Netbanking'
                                      _0x43ee9a = 'State Bank of India'
                                    } else {
                                      _0x53054c.includes('IRCWA')
                                        ? ((_0x484816 = 'IRCTC eWallet'),
                                          (_0x43ee9a = 'IRCTC eWallet'))
                                        : ((_0x484816 =
                                            'IRCTC iPay (Credit Card/Debit Card/UPI)'),
                                          (_0x43ee9a =
                                            'Credit cards/Debit cards/Netbanking/UPI (Powered by IRCTC)'))
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                    let _0x25f823 = document.querySelectorAll(
                        '#pay-type span.bank-type-heading, #pay-type div.bank-type'
                      ),
                      _0x2a8ef2 = Array.from(_0x25f823).find(
                        (_0x47edfa) =>
                          _0x47edfa &&
                          _0x47edfa.innerText &&
                          _0x47edfa.innerText
                            .toUpperCase()
                            .includes(_0x484816.toUpperCase())
                      )
                    if (!_0x2a8ef2) {
                      return (
                        console.error(
                          "Rajebull : CATEGORY '" + _0x484816 + "' not found."
                        ),
                        {
                          success: false,
                          optionText: _0x484816,
                        }
                      )
                    }
                    return (
                      fastClick(_0x2a8ef2),
                      console.log(
                        "Rajebull : Clicked category '" + _0x484816 + "'."
                      ),
                      new Promise((_0x2c9acf) => {
                        setTimeout(() => {
                          let _0x3251be =
                              document.getElementsByClassName(
                                'border-all no-pad'
                              ),
                            _0x27c962 = Array.from(_0x3251be).find(
                              (_0x181269) => {
                                const _0xe6b9e1 =
                                  _0x181269?.getElementsByTagName('span')[0]
                                return (
                                  isElementVisibleAndInteractable(_0x181269) &&
                                  _0xe6b9e1 &&
                                  _0xe6b9e1.innerText
                                    .toUpperCase()
                                    .includes(_0x43ee9a.toUpperCase())
                                )
                              }
                            )
                          _0x27c962
                            ? (console.log(
                                "Rajebull : Option '" +
                                  _0x43ee9a +
                                  "' found. Clicking."
                              ),
                              fastClick(_0x27c962),
                              _0x2c9acf({ success: true }))
                            : (console.warn(
                                "Rajebull : Option '" + _0x43ee9a + "' not found."
                              ),
                              _0x2c9acf({
                                success: false,
                                optionText: _0x43ee9a,
                              }))
                        }, 800)
                      })
                    )
                  },
                  _0x4f6db5 = await _0x450975(_0x5500ca)
                if (_0x4f6db5.success) {
                  const _0x3a8fcb =
                    document.getElementsByClassName('btn-primary')[0]
                  _0x3a8fcb &&
                    !user_data.other_preferences.paymentManual &&
                    setTimeout(() => {
                      statusUpdate('redirectToBank')
                      fastClick(_0x3a8fcb)
                      if (_0x5500ca === 'IRCWA') {
                        console.log(
                          'Rajebull : IRCWA method detected. Now searching for the final CONFIRM pop-up button.'
                        )
                        let _0x425810 = 0
                        const _0x20bc55 = setInterval(() => {
                          _0x425810++
                          const _0x49b980 = Array.from(
                            document.querySelectorAll(
                              'button.mob-bot-btn.search_btn'
                            )
                          ).find(
                            (_0x4dc1a2) =>
                              _0x4dc1a2.innerText.trim().toUpperCase() ===
                              'CONFIRM'
                          )
                          if (
                            _0x49b980 &&
                            isElementVisibleAndInteractable(_0x49b980)
                          ) {
                            console.log(
                              'Rajebull : Found and clicking the final eWallet CONFIRM button.'
                            )
                            fastClick(_0x49b980)
                            clearInterval(_0x20bc55)
                          } else {
                            _0x425810 >= 25 &&
                              (console.warn(
                                'Rajebull : Could not find the eWallet CONFIRM button after 5 seconds. Please click manually.'
                              ),
                              clearInterval(_0x20bc55))
                          }
                        }, 200)
                      }
                    }, 100)
                } else {
                  console.warn(
                    'Rajebull : Primary method failed. Initiating FALLBACK.'
                  )
                  if (_0x2d4ad9 && _0x2d4ad9 !== '') {
                    showOnScreenNotification(
                      'Primary method failed. Switching to backup: ' +
                        _0x2d4ad9,
                      5000
                    )
                    const _0x31e097 = await _0x450975(_0x2d4ad9)
                    _0x31e097.success
                      ? (console.log(
                          'Rajebull  FALLBACK: Updating storage to: ' + _0x2d4ad9
                        ),
                        (user_data.other_preferences.paymentmethod = _0x2d4ad9),
                        chrome.storage.local.set(
                          { other_preferences: user_data.other_preferences },
                          () => {
                            console.log(
                              'Rajebull  FALLBACK: Storage updated. Now clicking Pay.'
                            )
                            const _0x5e401f =
                              document.getElementsByClassName('btn-primary')[0]
                            _0x5e401f &&
                              !user_data.other_preferences.paymentManual &&
                              setTimeout(() => {
                                statusUpdate('redirectToBank')
                                fastClick(_0x5e401f)
                              }, 100)
                          }
                        ))
                      : showOnScreenNotification(
                          'Primary and Backup options both failed. Please proceed manually.',
                          6000
                        )
                  } else {
                    showOnScreenNotification(
                      'Primary method failed and no backup is set. Please proceed manually.',
                      6000
                    )
                  }
                }
              }
            }, 200)
          } else {
            if ('showPnrAnimation' === _0x78fd4f) {
              const _0x5984a2 = document.querySelector(
                'div.cnf-pad.ng-star-inserted'
              )
              _0x5984a2 && showPnrAnimation(_0x5984a2)
            } else {
              _0x1bdf33('Something went wrong: Unknown message type')
            }
          }
        }
      }
    }
  }
)
async function proceedAfterFareCheck() {
  document.querySelector('#captcha')?.scrollIntoView({
    behavior: 'smooth',
    block: 'center',
  })
  if (user_data.other_preferences.autoCaptcha) {
    setTimeout(getCaptchaTC, 200)
  } else {
    const _0x3a6f03 = document.querySelector('#captcha')
    _0x3a6f03 && (fastFill(_0x3a6f03, 'X'), _0x3a6f03.focus())
  }
}
let captchaRetry = 0
async function getCaptchaTC() {
  if (captchaRetry >= 100) {
    return
  }
  captchaRetry++
  const _0x20cc5c = document.querySelector('.captcha-img')
  if (!_0x20cc5c || !_0x20cc5c.src || _0x20cc5c.src.length < 23) {
    setTimeout(getCaptchaTC, 1000)
    return
  }
  const _0x3cc3d9 = _0x20cc5c.src.substr(22)
  try {
    // Use the new TrueCaptcha API
    const response = await fetch('https://api.apitruecaptcha.org/one/gettext', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        userid: 'shankar',
        apikey: 'BngjEggtgoe6LaWy60Fs',
        data: _0x3cc3d9,
      }),
    })
    if (!response.ok) {
      const errorText = await response.text()
      showCustomAlert('Error from captcha server: ' + response.status + ' - ' + errorText)
      console.error('Captcha server returned an error:', response.status)
      return
    }
    const resultJson = await response.json()
    let _0xd84148 = resultJson.result || '',
      _0xf8f944 = ''
    for (const _0x55c7a2 of String(_0xd84148)
      .replace(/\s/g, '')
      .replace(')', 'J')
      .replace(']', 'J')) {
      if (
        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@'.includes(
          _0x55c7a2
        )
      ) {
        _0xf8f944 += _0x55c7a2
      }
    }
    const _0x234885 = document.querySelector('#captcha')
    if (_0x234885) {
      fastFill(_0x234885, _0xf8f944)
    }
    if (!_0xd84148) {
      fastClick(
        document.querySelector('.glyphicon.glyphicon-repeat')?.parentElement
      )
      setTimeout(getCaptchaTC, 500)
      return
    }
    const _0x46382c = document.querySelector('app-login'),
      _0x848a53 = document.querySelector(
        '#divMain > div > app-review-booking > p-toast'
      ),
      _0x3bbaa8 = (_0x33048d, _0x265eb6) => {
        setTimeout(getCaptchaTC, 500)
        _0x265eb6.disconnect()
      },
      _0x7b9dd3 = new MutationObserver((_0x1be30, _0x107de3) => {
        if (_0x46382c?.innerText.toLowerCase().includes('valid captcha')) {
          _0x3bbaa8('login', _0x107de3)
        }
        if (_0x848a53?.innerText.toLowerCase().includes('valid captcha')) {
          _0x3bbaa8('review', _0x107de3)
        }
      })
    if (_0x46382c) {
      _0x7b9dd3.observe(_0x46382c, {
        childList: true,
        subtree: true,
      })
    }
    if (_0x848a53) {
      _0x7b9dd3.observe(_0x848a53, {
        childList: true,
        subtree: true,
      })
    }
    if (user_data.other_preferences.CaptchaSubmitMode === 'A') {
      const _0x5d4e73 = document.querySelector('#divMain > app-login')
      if (_0x5d4e73) {
        const _0x2c43d8 = _0x5d4e73.querySelector(
            "input[formcontrolname='userid']"
          ),
          _0x2a2e63 = _0x5d4e73.querySelector(
            "input[formcontrolname='password']"
          )
        _0x2c43d8?.value && _0x2a2e63?.value
          ? setTimeout(() => {
              fastClick(
                _0x5d4e73.querySelector(
                  "button[type='submit'][class='search_btn train_Search']"
                )
              )
              fastClick(
                _0x5d4e73.querySelector(
                  "button[type='submit'][class='search_btn train_Search train_Search_custom_hover']"
                )
              )
            }, 100)
          : showCustomAlert('Username/password not filled for auto-submit.')
      }
      const _0x1b3e50 = document.querySelector(
        '#divMain > div > app-review-booking'
      )
      if (_0x1b3e50 && _0x234885?.value) {
        const _0x3c9a8e = _0x1b3e50.querySelector('.btnDefault.train_Search')
        _0x3c9a8e &&
          setTimeout(() => {
            user_data.other_preferences.confirmberths
              ? document.querySelector('.AVAILABLE')
                ? fastClick(_0x3c9a8e)
                : showCustomConfirm(
                    'No seats available. Continue booking?',
                    () => fastClick(_0x3c9a8e),
                    () => console.log('Booking stopped.')
                  )
              : fastClick(_0x3c9a8e)
          }, 100)
      } else {
        _0x1b3e50 &&
          !_0x234885?.value &&
          showCustomAlert('Captcha not filled for auto-submit on review page.')
      }
    }
  } catch (_0x24f1e3) {
    console.error('Failed to connect to captcha server:', _0x24f1e3)
    showCustomAlert(
      'Could not connect to the captcha server. Please check your network or server status.'
    )
  }
}
async function loadLoginDetails() {
  statusUpdate('loadLoginDetails')
  const _0x568112 = document.querySelector('#divMain > app-login'),
    _0x30d5d9 = _0x568112.querySelector(
      "input[type='text'][formcontrolname='userid']"
    ),
    _0x4351b1 = _0x568112.querySelector(
      "input[type='password'][formcontrolname='password']"
    )
  fastFill(_0x30d5d9, user_data.irctc_credentials.user_name ?? '')
  fastFill(_0x4351b1, user_data.irctc_credentials.password ?? '')
  document.querySelector('#captcha').scrollIntoView({
    behavior: 'smooth',
    block: 'center',
  })
  if (user_data.other_preferences.autoCaptcha) {
    setTimeout(getCaptchaTC, 200)
  } else {
    const _0x46c36d = document.querySelector('#captcha')
    fastFill(_0x46c36d, 'X')
    _0x46c36d.focus()
  }
}
function loadJourneyDetails() {
  statusUpdate('loadJourneyDetails')
  console.log('filling_journey_details')
  const _0x5e84ba = document.querySelector('app-jp-input form'),
    _0x2f19b4 = _0x5e84ba.querySelector('#origin > span > input')
  _0x2f19b4.value = user_data.journey_details.from
  _0x2f19b4.dispatchEvent(new Event('keydown'))
  _0x2f19b4.dispatchEvent(new Event('input'))
  const _0x175a09 = _0x5e84ba.querySelector('#destination > span > input')
  _0x175a09.value = user_data.journey_details.destination
  _0x175a09.dispatchEvent(new Event('keydown'))
  _0x175a09.dispatchEvent(new Event('input'))
  const _0x297731 = _0x5e84ba.querySelector('#jDate > span > input')
  _0x297731.value = user_data.journey_details.date
    ? '' + user_data.journey_details.date.split('-').reverse().join('/')
    : ''
  _0x297731.dispatchEvent(new Event('keydown'))
  _0x297731.dispatchEvent(new Event('input'))
  const _0xdd423a = _0x5e84ba.querySelector('#journeyClass')
  _0xdd423a.querySelector("div > div[role='button']").click()
  addDelay(300)
  ;[..._0xdd423a.querySelectorAll('ul li')]
    .find(
      (_0x1385b1) =>
        _0x1385b1.innerText === classTranslator(user_data.journey_details.class)
    )
    ?.click()
  addDelay(300)
  const _0x5081df = _0x5e84ba.querySelector('#journeyQuota')
  _0x5081df.querySelector("div > div[role='button']").click()
  ;[..._0x5081df.querySelectorAll('ul li')]
    .find(
      (_0xd3c734) =>
        _0xd3c734.innerText === quotaTranslator(user_data.journey_details.quota)
    )
    ?.click()
  addDelay(300)
  const _0x5210be = _0x5e84ba.querySelector(
    "button.search_btn.train_Search[type='submit']"
  )
  addDelay(300)
  console.log('filled_journey_details')
  _0x5210be.click()
}
function retrySelectJourney() {
  console.log('Retrying selectJourney...')
  setTimeout(selectJourney, 1000)
}
function selectJourney() {
  statusUpdate('train-list')
  const _0x534c42 = setInterval(() => {
    const _0x3bcbeb = document.querySelector(
        '#divMain > div > app-train-list > p-toast > div > p-toastitem > div > div > a'
      ),
      _0x4e3d58 = document.querySelector(
        'body > app-root > app-home > div.header-fix > app-header > p-toast > div > p-toastitem > div > div > a'
      ),
      _0x1db88b = _0x3bcbeb || _0x4e3d58,
      _0x1af596 = document.querySelector('#loaderP'),
      _0x1c39af = _0x1af596 && _0x1af596.style.display !== 'none'
    _0x1db88b &&
      !_0x1c39af &&
      (console.log('Toast link found. Clicking it now...'),
      _0x1db88b.click(),
      console.log('Toast link clicked'),
      retrySelectJourney(),
      clearInterval(_0x534c42))
  }, 1000)
  if (!user_data?.journey_details?.['train-no']) {
    console.error('Train number is not available in user_data.')
    return
  }
  const _0x481cd6 = document.querySelector('#divMain > div > app-train-list')
  if (!_0x481cd6) {
    console.error('Train list parent not found.')
    return
  }
  const _0x1d37d9 = Array.from(
      _0x481cd6.querySelectorAll('.tbis-div app-train-avl-enq')
    ),
    _0x16fda4 = user_data.journey_details['train-no'],
    _0x507eb9 = classTranslator(user_data.journey_details.class),
    _0x5dc544 = new Date(user_data.journey_details.date),
    _0x58ce78 =
      _0x5dc544.toDateString().split(' ')[0] +
      ', ' +
      _0x5dc544.toDateString().split(' ')[2] +
      ' ' +
      _0x5dc544.toDateString().split(' ')[1]
  console.log('Train Number:', _0x16fda4)
  console.log('Class:', _0x507eb9)
  console.log('Date:', _0x58ce78)
  const _0x1a722b = _0x1d37d9.find((_0x1fb304) =>
    _0x1fb304
      .querySelector('div.train-heading')
      .innerText.trim()
      .includes(_0x16fda4.split('-')[0])
  )
  if (!_0x1a722b) {
    console.error('Train not found.')
    statusUpdate('journey_selection_stopped.no_train')
    return
  }
  const _0x4e4374 = (_0x477857) => {
      if (!_0x477857) {
        return false
      }
      const _0x23010f = window.getComputedStyle(_0x477857)
      return (
        _0x23010f.display !== 'none' &&
        _0x23010f.visibility !== 'hidden' &&
        _0x23010f.opacity !== '0'
      )
    },
    _0x420952 = Array.from(
      _0x1a722b.querySelectorAll('table tr td div.pre-avl')
    ),
    _0x169a9a = _0x420952.find(
      (_0x3add2d) =>
        _0x3add2d.querySelector('div').innerText.trim() === _0x507eb9
    ),
    _0x3e884f = Array.from(_0x1a722b.querySelectorAll('span')).find(
      (_0x4efedc) => _0x4efedc.innerText.trim() === _0x507eb9
    ),
    _0x1c0320 = _0x169a9a || _0x3e884f
  if (!_0x1c0320) {
    console.error('Class to click not found.')
    return
  }
  const _0x2ed344 = document.querySelector('#loaderP')
  if (_0x4e4374(_0x2ed344)) {
    console.error('Loader is visible. Cannot click the class yet.')
    return
  }
  _0x1c0320.click()
  let _0x42ab54
  new MutationObserver((_0x160224, _0x211511) => {
    console.log('Mutation observed at', new Date().toLocaleTimeString())
    clearTimeout(_0x42ab54)
    _0x42ab54 = setTimeout(() => {
      const _0x45385c = Array.from(
          _0x1a722b.querySelectorAll('div div table td div.pre-avl')
        ),
        _0x4e1bd9 = _0x45385c.find(
          (_0x4eb96f) =>
            _0x4eb96f.querySelector('div').innerText.trim() === _0x58ce78
        )
      console.log('FOUND date cell to click:', _0x4e1bd9)
      _0x4e1bd9
        ? (_0x4e1bd9.click(),
          console.log('Clicked on date cell'),
          setTimeout(() => {
            const _0x3187ed = () => {
              const _0x456bba = _0x1a722b.querySelector(
                'button.btnDefault.train_Search.ng-star-inserted'
              )
              if (_0x4e4374(document.querySelector('#loaderP'))) {
                return (
                  console.warn('Loader still visible, retrying...'),
                  setTimeout(_0x3187ed, 100)
                )
              }
              !_0x456bba ||
              _0x456bba.classList.contains('disable-book') ||
              _0x456bba.disabled
                ? (console.warn(
                    'Book button disabled or not found, retrying...'
                  ),
                  retrySelectJourney())
                : setTimeout(() => {
                    _0x456bba.click()
                    console.log('Clicked on Book button')
                    clearTimeout(_0x42ab54)
                    _0x211511.disconnect()
                  }, 200)
            }
            _0x3187ed()
          }, 500))
        : console.warn('Date cell to click not found.')
    }, 500)
  }).observe(_0x1a722b, {
    attributes: false,
    childList: true,
    subtree: true,
  })
}
async function fillPassengerDetails() {
  console.log('passenger_filling_started')
  if (user_data.journey_details.boarding?.length > 0) {
    const _0x5ed60b = [...document.getElementsByTagName('strong')].find(
      (_0xaf3a39) =>
        _0xaf3a39.innerText.includes(
          user_data.journey_details.from.split('-')[0].trim() + ' | '
        )
    )
    if (_0x5ed60b) {
      fastClick(_0x5ed60b)
    }
    setTimeout(() => {
      const _0xfb9fcb = [...document.getElementsByTagName('strong')].find(
        (_0x2f7ac6) =>
          _0x2f7ac6.innerText.includes(
            user_data.journey_details.boarding.split('-')[0].trim()
          )
      )
      if (_0xfb9fcb) {
        fastClick(_0xfb9fcb)
      }
    }, 100)
  }
  const _0x1b89c3 = document.querySelector('app-passenger-input')
  if (!_0x1b89c3) {
    return console.error('Passenger app element not found.')
  }
  for (
    let _0x360ca4 = 1;
    _0x360ca4 < user_data.passenger_details.length;
    _0x360ca4++
  ) {
    fastClick(document.getElementsByClassName('prenext')[0])
  }
  for (
    let _0x53c291 = 0;
    _0x53c291 < (user_data.infant_details || []).length;
    _0x53c291++
  ) {
    fastClick(document.getElementsByClassName('prenext')[2])
  }
  await new Promise((_0x152818) => setTimeout(_0x152818, 200))
  const _0x9a45e7 = [..._0x1b89c3.querySelectorAll('app-passenger')]
  user_data.passenger_details.forEach((_0x2b18ca, _0x5437d1) => {
    if (!_0x9a45e7[_0x5437d1]) {
      return
    }
    const _0x239bbc = _0x9a45e7[_0x5437d1]
    fastFill(_0x239bbc.querySelector('p-autocomplete input'), _0x2b18ca.name)
    fastFill(
      _0x239bbc.querySelector("input[formcontrolname='passengerAge']"),
      _0x2b18ca.age
    )
    const _0x20f862 = _0x239bbc.querySelector(
      "select[formcontrolname='passengerGender']"
    )
    _0x20f862 &&
      ((_0x20f862.value = _0x2b18ca.gender),
      _0x20f862.dispatchEvent(new Event('change')))
    const _0x33e7ae = _0x239bbc.querySelector(
      "select[formcontrolname='passengerBerthChoice']"
    )
    _0x33e7ae &&
      ((_0x33e7ae.value = _0x2b18ca.berth),
      _0x33e7ae.dispatchEvent(new Event('change')))
  })
  user_data.other_preferences.mobileNumber &&
    fastFill(
      _0x1b89c3.querySelector('input#mobileNumber'),
      user_data.other_preferences.mobileNumber
    )
  const _0xd195ed = [
    ..._0x1b89c3.querySelectorAll(
      "p-radiobutton[formcontrolname='paymentType'] input"
    ),
  ].find(
    (_0x3a0353) =>
      _0x3a0353.value ===
      (user_data.other_preferences.paymentmethod.includes('UPI') ? '2' : '1')
  )
  if (_0xd195ed) {
    fastClick(_0xd195ed)
  }
  const _0x2c0911 = _0x1b89c3.querySelector('input#autoUpgradation')
  if (
    _0x2c0911 &&
    user_data.other_preferences.autoUpgradation !== _0x2c0911.checked
  ) {
    fastClick(_0x2c0911)
  }
  const _0x415c09 = _0x1b89c3.querySelector('input#confirmberths')
  if (
    _0x415c09 &&
    user_data.other_preferences.confirmberths !== _0x415c09.checked
  ) {
    fastClick(_0x415c09)
  }
  const _0x546eb1 = [
    ..._0x1b89c3.querySelectorAll(
      "p-radiobutton[formcontrolname='travelInsuranceOpted'] input"
    ),
  ].find(
    (_0x2ad459) =>
      _0x2ad459.value ===
      (user_data.travel_preferences.travelInsuranceOpted === 'yes'
        ? 'true'
        : 'false')
  )
  if (_0x546eb1) {
    fastClick(_0x546eb1)
  }
  submitPassengerDetailsForm()
}
function submitPassengerDetailsForm() {
  window.scrollBy(0, 600, 'smooth')
  if (user_data.other_preferences.psgManual) {
    return showCustomAlert('Manually submit passenger page.')
  }
  setTimeout(() => {
    const _0x38dbfb = document.querySelector(
      "button.train_Search.btnDefault[type='submit']"
    )
    _0x38dbfb && isElementVisibleAndInteractable(_0x38dbfb)
      ? (console.log('\uD83D\uDE80 क्लिक कर रहे हैं:', _0x38dbfb),
        fastClick(_0x38dbfb))
      : (console.error(
          "\u274C 'Continue' बटन नहीं मिला\u2014कृपया मैन्युअली क्लिक करें\u0964"
        ),
        showCustomAlert(
          "Could not find the 'Continue' button automatically. Please click it manually."
        ))
  }, 1000)
}
async function continueScript() {
  const _0x93d297 = document.querySelector(
    'body > app-root > app-home > div.header-fix > app-header a.search_btn.loginText.ng-star-inserted'
  )
  if (window.location.href.includes('train-search')) {
    if (_0x93d297 && _0x93d297.innerText.trim().toUpperCase() === 'LOGOUT') {
      console.log('User is logged in. Proceeding to load journey details.')
      loadJourneyDetails()
    } else {
      if (_0x93d297 && _0x93d297.innerText.trim().toUpperCase() === 'LOGIN') {
        console.log(
          'IRCTC page loaded. LOGIN button found. Starting countdown...'
        )
        let _0x471f27 = document.getElementById('irctc-login-countdown-element')
        !_0x471f27 &&
          ((_0x471f27 = document.createElement('div')),
          (_0x471f27.id = 'irctc-login-countdown-element'),
          (_0x471f27.style.cssText =
            'position:fixed;top:10px;left:50%;transform:translateX(-50%);background-color:rgba(0,0,0,.7);color:#fff;padding:10px 20px;border-radius:5px;z-index:20000;font-size:16px'),
          document.body.appendChild(_0x471f27))
        let _0xf2dd45 = 15
        _0x471f27.textContent =
          '' + _0xf2dd45 + ''
        const _0x57decf = setInterval(async () => {
          _0xf2dd45--
          if (_0x471f27) {
            _0x471f27.textContent =
              '' + _0xf2dd45 + ''
          }
          if (_0xf2dd45 <= 0) {
            clearInterval(_0x57decf)
            if (_0x471f27 && _0x471f27.parentElement) {
              _0x471f27.remove()
            }
            fastClick(_0x93d297)
            await loadLoginDetails()
          }
        }, 1000)
      }
    }
  }
}
function injectLiveTimer() {
  if (document.getElementById('Rajebull -live-timer')) return;
  const timerDiv = document.createElement('div');
  timerDiv.id = 'Rajebull -live-timer';
  timerDiv.style.cssText = `
    position:fixed;
    top:60px;
    right:20px;
    background:rgba(34,49,63,0.95);
    color:#fff;
    padding:10px 22px;
    border-radius:8px;
    font-size:20px;
    font-family:monospace;
    z-index:99999;
    box-shadow:0 2px 8px rgba(0,0,0,0.2);
    letter-spacing:2px;
  `;
  timerDiv.textContent = '00:00:00';
  document.body.appendChild(timerDiv);

  function updateTimer() {
    const now = new Date();
    timerDiv.textContent = now.toLocaleTimeString('en-IN', { hour12: false });
  }
  updateTimer();
  setInterval(updateTimer, 1000);
}

window.onload = function () {
  console.log('Content script loaded and window.onload triggered.')
  injectAnimationAssets()
  injectLiveTimer(); // <-- Add this line
  setInterval(() => statusUpdate('Keep listener alive.'), 15000)
  const _0x2588d5 = document.querySelector(
    'body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1'
  )
  _0x2588d5 &&
    new MutationObserver((_0x1f949f, _0x58e2f7) => {
      _0x1f949f.some(
        (_0x49e2c4) =>
          _0x49e2c4.type === 'childList' &&
          [..._0x49e2c4.addedNodes].some(
            (_0x2245a2) =>
             
              _0x2245a2?.innerText?.trim().toUpperCase() === 'LOGOUT'
          )
      ) &&
        (console.log('LOGOUT detected in header via MutationObserver.'),
        _0x58e2f7.disconnect(),
        loadJourneyDetails())
    }).observe(_0x2588d5, {
      childList: true,
      subtree: false,
    })
  chrome.storage.local.get(null, (_0x1499d3) => {
    user_data = _0x1499d3;
    // Set the captcha API key directly
    user_data.authToken = 'f7YszqjkY1NIpNfG9JJD';
    console.log('User data loaded from storage:', user_data);
    dispatchInitialData(user_data);
    continueScript();
  })
}
