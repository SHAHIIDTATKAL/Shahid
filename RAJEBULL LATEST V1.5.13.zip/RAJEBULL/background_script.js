function applyProxyFromSettings(_0x57dd94) {
  const _0x4f0231 = parseInt(_0x57dd94.activeProxy, 0xa) - 0x1;
  if (isNaN(_0x4f0231) || !_0x57dd94.proxies || !_0x57dd94.proxies[_0x4f0231]) {
    console.error("❌ Invalid proxy configuration", {
      'activeIndex': _0x4f0231,
      'hasProxies': !!_0x57dd94.proxies,
      'proxiesLength': _0x57dd94.proxies?.['length'] || 0x0
    });
    chrome.proxy.settings.clear({
      'scope': "regular"
    });
    return;
  }
  const _0x3a5e30 = _0x57dd94.proxies[_0x4f0231];
  if (!_0x3a5e30.ip || !_0x3a5e30.port) {
    console.warn("⚠️ Active proxy missing IP or Port - clearing proxy", {
      'proxyIndex': _0x4f0231,
      'hasIp': !!_0x3a5e30.ip,
      'hasPort': !!_0x3a5e30.port
    });
    chrome.proxy.settings.clear({
      'scope': "regular"
    });
    return;
  }
  const _0x124b5b = {
    'mode': 'fixed_servers',
    'rules': {
      'singleProxy': {
        'scheme': "http",
        'host': _0x3a5e30.ip,
        'port': parseInt(_0x3a5e30.port, 0xa)
      },
      'bypassList': ["<local>"]
    }
  };
  chrome.proxy.settings.set({
    'value': _0x124b5b,
    'scope': 'regular'
  }, () => {
    if (chrome.runtime.lastError) {
      console.error("❌ Failed to set proxy settings", {
        'error': chrome.runtime.lastError.message,
        'proxyConfig': {
          'ip': _0x3a5e30.ip,
          'port': _0x3a5e30.port
        }
      });
    } else {
      console.info("🌐 Proxy settings applied successfully", {
        'proxyHost': _0x3a5e30.ip + ':' + _0x3a5e30.port,
        'proxyIndex': _0x4f0231
      });
    }
  });
}
function applyProxyFromConfig(_0x56fc3d) {
  if (!_0x56fc3d.proxyIp || !_0x56fc3d.proxyPort) {
    console.warn("⚠️ Proxy config missing IP or Port - clearing proxy", {
      'hasIp': !!_0x56fc3d.proxyIp,
      'hasPort': !!_0x56fc3d.proxyPort
    });
    chrome.proxy.settings.clear({
      'scope': "regular"
    });
    return;
  }
  const _0x5e948c = {
    'mode': "fixed_servers",
    'rules': {
      'singleProxy': {
        'scheme': "http",
        'host': _0x56fc3d.proxyIp,
        'port': parseInt(_0x56fc3d.proxyPort, 0xa)
      },
      'bypassList': ['<local>']
    }
  };
  chrome.proxy.settings.set({
    'value': _0x5e948c,
    'scope': "regular"
  }, () => {
    if (chrome.runtime.lastError) {
      console.error("❌ Failed to set proxy config settings", {
        'error': chrome.runtime.lastError.message,
        'proxyConfig': {
          'ip': _0x56fc3d.proxyIp,
          'port': _0x56fc3d.proxyPort
        }
      });
    } else {
      console.info("🌐 Proxy config applied successfully", {
        'proxyHost': _0x56fc3d.proxyIp + ':' + _0x56fc3d.proxyPort,
        'hasAuth': !!(_0x56fc3d.proxyUsername && _0x56fc3d.proxyPassword)
      });
    }
  });
}
function applyProxySettings() {
  chrome.storage.local.get(['proxy_settings', 'proxy_config'], _0x420152 => {
    const _0x506147 = _0x420152.proxy_settings;
    const _0x47ba12 = _0x420152.proxy_config;
    console.debug("🔍 Retrieved proxy storage data", {
      'hasProxySettings': !!_0x506147,
      'hasProxyConfig': !!_0x47ba12,
      'activeProxy': _0x506147?.['activeProxy'],
      'enableProxy': _0x47ba12?.["enableProxy"]
    });
    if (_0x506147 && _0x506147.activeProxy !== "disabled") {
      console.debug("🔧 Using proxy_settings system");
      applyProxyFromSettings(_0x506147);
      return;
    }
    if (_0x47ba12 && _0x47ba12.enableProxy) {
      console.debug("🔧 Using proxy_config system as fallback");
      applyProxyFromConfig(_0x47ba12);
      return;
    }
    console.info("🔄 Clearing proxy settings - disabled or no settings");
    chrome.proxy.settings.clear({
      'scope': 'regular'
    }, () => {
      console.info("✅ Proxy settings cleared successfully");
    });
  });
}
function disableRegularAuthHandler() {
  try {
    chrome.webRequest.onAuthRequired.removeListener(null);
    console.debug("🔧 Regular auth handler temporarily disabled");
    return true;
  } catch (_0x3a56a1) {
    console.warn("⚠️ Error disabling regular auth handler", {
      'error': _0x3a56a1.message
    });
    return false;
  }
  return false;
}
function enableRegularAuthHandler() {
  try {
    chrome.webRequest.onAuthRequired.addListener(null, {
      'urls': ['<all_urls>']
    }, ["asyncBlocking"]);
    console.debug("🔧 Regular auth handler re-enabled");
    return true;
  } catch (_0x366129) {
    console.warn("⚠️ Error re-enabling regular auth handler", {
      'error': _0x366129.message
    });
    return false;
  }
  return false;
}
async function testProxyConnectivity(_0x3e4d5e) {
  console.info("🧪 Testing proxy connectivity", {
    'proxyHost': _0x3e4d5e.ip + ':' + _0x3e4d5e.port,
    'hasAuth': !!(_0x3e4d5e.user && _0x3e4d5e.pass),
    'userLength': _0x3e4d5e.user ? _0x3e4d5e.user.length : 0x0,
    'passLength': _0x3e4d5e.pass ? _0x3e4d5e.pass.length : 0x0
  });
  const _0x3d84ff = {
    'mode': "fixed_servers",
    'rules': {
      'singleProxy': {
        'scheme': "http",
        'host': _0x3e4d5e.ip,
        'port': parseInt(_0x3e4d5e.port, 0xa)
      },
      'bypassList': ["<local>"]
    }
  };
  let _0x3913fe = false;
  let _0x519c0a = '';
  let _0x76e6c9 = null;
  let _0x604f41 = false;
  try {
    if (_0x3e4d5e.user && _0x3e4d5e.pass) {
      console.debug("🔐 Setting up temporary auth handler for proxy test", {
        'hasUser': !!_0x3e4d5e.user,
        'hasPass': !!_0x3e4d5e.pass
      });
      const _0x31a9d1 = disableRegularAuthHandler();
      console.debug("🔧 Regular handler disabled for test", {
        'success': _0x31a9d1
      });
      _0x76e6c9 = function (_0xc1fd02, _0x328694) {
        console.info("🔐 Test proxy auth challenge received", {
          'url': _0xc1fd02.url,
          'challenger': _0xc1fd02.challenger,
          'isProxy': _0xc1fd02.isProxy,
          'scheme': _0xc1fd02.scheme,
          'realm': _0xc1fd02.realm
        });
        if (_0xc1fd02.isProxy) {
          console.info("✅ Providing credentials for proxy test authentication", {
            'username': _0x3e4d5e.user,
            'hasPassword': !!_0x3e4d5e.pass
          });
          _0x604f41 = true;
          _0x328694({
            'authCredentials': {
              'username': _0x3e4d5e.user,
              'password': _0x3e4d5e.pass
            }
          });
        } else {
          console.debug("🔐 Not a proxy auth challenge, ignoring");
          _0x328694({});
        }
      };
      chrome.webRequest.onAuthRequired.addListener(_0x76e6c9, {
        'urls': ["<all_urls>"]
      }, ["asyncBlocking"]);
      console.debug("🔧 Temporary auth handler registered, waiting for setup");
      await new Promise(_0x3c514b => setTimeout(_0x3c514b, 0xc8));
    }
    await new Promise((_0x2889f6, _0x4dbf1b) => {
      chrome.proxy.settings.set({
        'value': _0x3d84ff,
        'scope': "regular"
      }, () => {
        if (chrome.runtime.lastError) {
          const _0x1d0eb6 = new Error("Failed to set proxy settings: " + chrome.runtime.lastError.message);
          console.error("❌ Proxy test setup failed", {
            'error': chrome.runtime.lastError.message,
            'proxyHost': _0x3e4d5e.ip + ':' + _0x3e4d5e.port
          });
          _0x4dbf1b(_0x1d0eb6);
        } else {
          console.debug("✅ Temporary proxy set for testing", {
            'proxyHost': _0x3e4d5e.ip + ':' + _0x3e4d5e.port
          });
          _0x2889f6();
        }
      });
    });
    const _0x4fd857 = new AbortController();
    const _0x9a1e30 = self.setTimeout(() => _0x4fd857.abort(), 0x2710);
    try {
      console.debug("🧪 Making test request through proxy", {
        'url': "https://www.google.com/generate_204",
        'proxyHost': _0x3e4d5e.ip + ':' + _0x3e4d5e.port,
        'hasAuth': !!(_0x3e4d5e.user && _0x3e4d5e.pass)
      });
      const _0x5294af = await fetch("https://www.google.com/generate_204", {
        'signal': _0x4fd857.signal
      });
      self.clearTimeout(_0x9a1e30);
      console.debug("🧪 Test request completed", {
        'status': _0x5294af.status,
        'statusText': _0x5294af.statusText,
        'ok': _0x5294af.ok
      });
      if (_0x5294af.status === 0xcc) {
        _0x3913fe = true;
        _0x519c0a = "Proxy is working.";
        console.info("✅ Proxy connectivity test passed", {
          'proxyHost': _0x3e4d5e.ip + ':' + _0x3e4d5e.port,
          'responseStatus': _0x5294af.status
        });
      } else if (_0x5294af.status === 0x197) {
        _0x3913fe = false;
        if (_0x3e4d5e.user && _0x3e4d5e.pass) {
          if (_0x604f41) {
            _0x519c0a = "Proxy authentication failed. Username or password may be incorrect.";
            console.warn("🔐 Proxy authentication failed during test (credentials were provided)", {
              'proxyHost': _0x3e4d5e.ip + ':' + _0x3e4d5e.port,
              'status': _0x5294af.status,
              'hasCredentials': true,
              'authAttempted': true
            });
          } else {
            _0x519c0a = "Proxy authentication handler was not called. This may be a timing issue.";
            console.warn("🔐 Proxy auth handler not triggered despite credentials", {
              'proxyHost': _0x3e4d5e.ip + ':' + _0x3e4d5e.port,
              'status': _0x5294af.status,
              'hasCredentials': true,
              'authAttempted': false
            });
          }
        } else {
          _0x519c0a = "Proxy requires authentication. Please provide username and password.";
          console.warn("🔐 Proxy requires authentication but no credentials provided", {
            'proxyHost': _0x3e4d5e.ip + ':' + _0x3e4d5e.port,
            'status': _0x5294af.status
          });
        }
      } else {
        _0x3913fe = false;
        _0x519c0a = "Proxy returned unexpected status: " + _0x5294af.status;
        console.warn("⚠️ Proxy test returned unexpected status", {
          'proxyHost': _0x3e4d5e.ip + ':' + _0x3e4d5e.port,
          'status': _0x5294af.status
        });
      }
    } catch (_0x354f09) {
      self.clearTimeout(_0x9a1e30);
      if (_0x354f09.name === "AbortError") {
        _0x519c0a = "Proxy test timed out (10 seconds).";
        console.warn("⏰ Proxy test timed out", {
          'proxyHost': _0x3e4d5e.ip + ':' + _0x3e4d5e.port,
          'timeout': "10 seconds"
        });
      } else if (_0x354f09.message.includes("ERR_NO_SUPPORTED_PROXIES")) {
        _0x519c0a = "Proxy requires authentication or is unreachable. Please check username/password or IP/port.";
        console.error("🔐 Proxy authentication or connectivity issue", {
          'proxyHost': _0x3e4d5e.ip + ':' + _0x3e4d5e.port,
          'error': _0x354f09.message
        });
      } else {
        _0x519c0a = "Network error or proxy unreachable: " + _0x354f09.message;
        console.error("🌐 Network error during proxy test", {
          'proxyHost': _0x3e4d5e.ip + ':' + _0x3e4d5e.port,
          'error': _0x354f09.message
        });
      }
      _0x3913fe = false;
    }
  } catch (_0x5ad19a) {
    _0x3913fe = false;
    _0x519c0a = _0x5ad19a.message;
    console.error("❌ Proxy test failed with error", {
      'proxyHost': _0x3e4d5e.ip + ':' + _0x3e4d5e.port,
      'error': _0x5ad19a.message
    });
  } finally {
    if (_0x76e6c9) {
      try {
        chrome.webRequest.onAuthRequired.removeListener(_0x76e6c9);
        console.debug("🧹 Temporary auth handler removed after test");
      } catch (_0x3a81d2) {
        console.warn("⚠️ Error removing temporary auth handler", {
          'error': _0x3a81d2.message
        });
      }
      const _0x111be8 = enableRegularAuthHandler();
      console.debug("🔧 Regular handler re-enabled after test", {
        'success': _0x111be8
      });
    }
    await new Promise(_0x2a79ea => {
      chrome.proxy.settings.clear({
        'scope': "regular"
      }, () => {
        console.debug("🧹 Temporary proxy settings cleared after test");
        _0x2a79ea();
      });
    });
  }
  console.info("🧪 Proxy connectivity test completed", {
    'proxyHost': _0x3e4d5e.ip + ':' + _0x3e4d5e.port,
    'success': _0x3913fe,
    'message': _0x519c0a
  });
  return {
    'success': _0x3913fe,
    'message': _0x519c0a
  };
}
chrome.webRequest.onAuthRequired.addListener((_0x221a3b, _0x114508) => {
  console.log("Proxy authentication required:", _0x221a3b);
  chrome.storage.local.get('proxy_settings', _0x12b3e9 => {
    const _0x101548 = _0x12b3e9.proxy_settings;
    if (_0x101548 && _0x101548.activeProxy !== "disabled") {
      const _0x465cdc = parseInt(_0x101548.activeProxy, 0xa) - 0x1;
      const _0x308882 = _0x101548.proxies[_0x465cdc];
      if (_0x308882 && _0x308882.user && _0x308882.pass) {
        _0x114508({
          'authCredentials': {
            'username': _0x308882.user,
            'password': _0x308882.pass
          }
        });
      } else {
        _0x114508({
          'cancel': true
        });
      }
    } else {
      _0x114508({
        'cancel': true
      });
    }
  });
  return {
    'cancel': false
  };
}, {
  'urls': ["<all_urls>"]
}, ["asyncBlocking"]);
applyProxySettings();
let tabDetails;
let status_updates = {};
function getMsg(_0xfec276, _0x1af451) {
  return {
    'msg': {
      'type': _0xfec276,
      'data': _0x1af451
    },
    'sender': 'popup',
    'id': "irctc"
  };
}
chrome.runtime.onMessage.addListener((_0x4bbc7e, _0xb55fe2, _0x1dcd3c) => {
  if (_0x4bbc7e.type === "FETCH_TRAIN_LIST" && _0x4bbc7e.url) {
    console.log("Background: Handling FETCH_TRAIN_LIST for URL:", _0x4bbc7e.url);
    fetch(_0x4bbc7e.url).then(_0x576a7f => {
      if (!_0x576a7f.ok) {
        throw new Error("HTTP error! Status: " + _0x576a7f.status);
      }
      return _0x576a7f.text();
    }).then(_0x327d86 => {
      console.log("Background: Train list fetch SUCCESS. Sending response to popup.");
      _0x1dcd3c({
        'success': true,
        'data': _0x327d86
      });
    })["catch"](_0x184e1c => {
      console.error("Background: Train list fetch FAILED. Error:", _0x184e1c);
      _0x1dcd3c({
        'success': false,
        'error': _0x184e1c.message
      });
    });
    return true;
  }
  if (_0x4bbc7e.action === 'checkProxyConnectivity') {
    console.log("Received request to check proxy connectivity:", _0x4bbc7e.proxy);
    testProxyConnectivity(_0x4bbc7e.proxy).then(_0x3fbce2 => {
      _0x1dcd3c(_0x3fbce2);
    });
    return true;
  }
  if (_0x4bbc7e.action === "updateProxy") {
    console.log("Received request to update proxy.");
    applyProxySettings();
    _0x1dcd3c({
      'status': "Proxy settings updated."
    });
    return true;
  }
  if ("irctc" !== _0x4bbc7e.id) {
    _0x1dcd3c("Invalid Id");
    return true;
  }
  let _0x48a645 = _0x4bbc7e.msg.type;
  let _0x114883 = _0x4bbc7e.msg.data;
  if ('activate_script' === _0x48a645) {
    if (_0x114883.fare_limit?.["bookInPopup"]) {
      chrome.windows.create({
        'url': "https://www.irctc.co.in/nget/train-search",
        'type': 'popup',
        'width': 0x200,
        'height': 0x238
      }, _0xb37d4f => {
        if (chrome.runtime.lastError) {
          console.error("[background_script.js] Error creating window:", chrome.runtime.lastError.message);
          _0x1dcd3c("Error creating window: " + chrome.runtime.lastError.message);
          return;
        }
        if (_0xb37d4f && _0xb37d4f.tabs && _0xb37d4f.tabs.length > 0x0) {
          tabDetails = _0xb37d4f.tabs[0x0];
          chrome.scripting.executeScript({
            'target': {
              'tabId': tabDetails.id
            },
            'files': ['./content_script.js']
          }, () => {
            if (chrome.runtime.lastError) {
              console.error("[background_script.2A42.js] Error injecting script into window:", chrome.runtime.lastError.message);
              _0x1dcd3c("Error injecting script: " + chrome.runtime.lastError.message);
            } else {
              console.log("[background_script.js] Script activated in new window, tab ID:", tabDetails.id);
              _0x1dcd3c("Script activated in new window");
            }
          });
        } else {
          console.error("[background_script.js] Failed to create popup window or get its tab details.");
          _0x1dcd3c("Failed to activate script in popup window.");
        }
      });
    } else {
      chrome.tabs.create({
        'url': "https://www.irctc.co.in/nget/train-search"
      }, _0x3b7cc5 => {
        if (chrome.runtime.lastError) {
          console.error("[background_script.js] Error creating tab:", chrome.runtime.lastError.message);
          _0x1dcd3c("Error creating tab: " + chrome.runtime.lastError.message);
          return;
        }
        tabDetails = _0x3b7cc5;
        chrome.scripting.executeScript({
          'target': {
            'tabId': tabDetails.id
          },
          'files': ["./content_script.js"]
        }, () => {
          if (chrome.runtime.lastError) {
            console.error("[background_script.js] Error injecting script into tab:", chrome.runtime.lastError.message);
            _0x1dcd3c("Error injecting script: " + chrome.runtime.lastError.message);
          } else {
            console.log("[background_script.js] Script activated in new tab, tab ID:", tabDetails.id);
            _0x1dcd3c("Script activated in new tab");
          }
        });
      });
    }
    return true;
  } else {
    if ("status_update" === _0x48a645) {
      const _0x3d323b = _0xb55fe2.tab?.['id'] || "popup_or_unknown";
      status_updates[_0x3d323b] = status_updates[_0x3d323b] || [];
      status_updates[_0x3d323b].push({
        'sender': _0xb55fe2,
        'data': _0x114883
      });
      _0x1dcd3c("Status received");
    } else {
      _0x1dcd3c("Something went wrong with message type");
    }
  }
  return true;
});
chrome.tabs.onUpdated.addListener((_0x17ebb6, _0x28eb41, _0x530409) => {
  if (_0x28eb41?.["status"] !== "complete" || !_0x530409.url) {
    return;
  }
  const _0x582ec1 = _0x530409.url;
  let _0x390f81 = null;
  let _0x462ea3 = null;
  let _0x3a5005 = false;
  if (tabDetails && _0x17ebb6 === tabDetails.id) {
    _0x462ea3 = tabDetails.id;
    console.log("[background_script.js] Main tab (" + _0x462ea3 + ") updated: " + _0x582ec1);
    if (_0x582ec1.includes('booking/train-list')) {
      _0x390f81 = "selectJourney";
      _0x3a5005 = true;
    } else {
      if (_0x582ec1.includes("booking/psgninput")) {
        _0x390f81 = "fillPassengerDetails";
        _0x3a5005 = true;
      } else {
        if (_0x582ec1.includes("booking/reviewBooking")) {
          _0x390f81 = "reviewBooking";
          _0x3a5005 = true;
        } else if (_0x582ec1.includes("payment/bkgPaymentOptions")) {
          console.log("[background_script.js] Payment options page detected on main tab by URL:", _0x582ec1);
          _0x390f81 = 'bkgPaymentOptions';
          _0x3a5005 = true;
        }
      }
    }
  }
  if (_0x3a5005 && _0x390f81 && _0x462ea3) {
    console.log("[background_script.js] Sending (main flow) " + _0x390f81 + " to tab " + _0x462ea3 + " for URL: " + _0x582ec1);
    chrome.tabs.sendMessage(_0x462ea3, {
      'msg': {
        'type': _0x390f81,
        'data': null
      },
      'sender': "popup",
      'id': "irctc"
    }).then(_0x49c10e => console.log("[background_script.js] (Main flow) " + _0x390f81 + " message acknowledged by tab " + _0x462ea3 + ':', _0x49c10e))["catch"](_0x3b1ece => console.warn("[background_script.js] (Main flow) Error sending " + _0x390f81 + " to tab " + _0x462ea3 + ':', _0x3b1ece.message));
  }
  if (_0x582ec1.startsWith("https://www.irctc.co.in/") && (_0x582ec1.includes("booking/train-ticket") || _0x582ec1.includes("eticket") || _0x582ec1.includes("booking-confirm"))) {
    console.log("[background_script.js] PNR page detected on tab " + _0x17ebb6 + ": " + _0x582ec1 + '.');
    chrome.scripting.executeScript({
      'target': {
        'tabId': _0x17ebb6
      },
      'files': ["./content_script.js"]
    }, _0x7e40d6 => {
      if (chrome.runtime.lastError) {
        console.warn("[background_script.js] executeScript on PNR tab " + _0x17ebb6 + " had an issue (might be ok if already injected): " + chrome.runtime.lastError.message);
      } else {
        console.log("[background_script.js] Content script ensured on PNR tab " + _0x17ebb6 + '.');
      }
      setTimeout(() => {
        console.log("[background_script.js] Sending showPnrAnimation to tab " + _0x17ebb6);
        chrome.tabs.sendMessage(_0x17ebb6, {
          'msg': {
            'type': "showPnrAnimation",
            'data': null
          },
          'sender': 'popup',
          'id': "irctc"
        }).then(_0x34dceb => console.log("[background_script.js] showPnrAnimation message acknowledged by tab " + _0x17ebb6 + ':', _0x34dceb))["catch"](_0x1e500e => console.warn("[background_script.js] Error sending showPnrAnimation to tab " + _0x17ebb6 + " (content script might not be listening, or tab closed):", _0x1e500e.message));
      }, 0xfa);
    });
  }
});