document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.local.get('trainSearchQuery', (_0x270c3b) => {
    if (_0x270c3b.trainSearchQuery) {
      const {
        from: _0x3e703a,
        to: _0x5b84d3,
        date: _0x44818f,
      } = _0x270c3b.trainSearchQuery
      document.getElementById('title').innerText =
        'Results for ' + _0x3e703a + ' to ' + _0x5b84d3
      fetchTrainListFromEtrainInfo(_0x3e703a, _0x5b84d3, _0x44818f)
    }
  })
  const _0x1429ed = document.getElementById('results-table')
  _0x1429ed.addEventListener('click', function (_0x1057c2) {
    if (
      _0x1057c2.target &&
      _0x1057c2.target.classList.contains('class-selector')
    ) {
      const _0x5720e1 = _0x1057c2.target.dataset.trainNumber,
        _0x422574 = _0x1057c2.target.dataset.trainName,
        _0x14c851 = _0x1057c2.target.dataset.classCode,
        _0x275414 = _0x5720e1 + '- ' + _0x422574
      chrome.runtime.sendMessage(
        {
          type: 'TRAIN_SELECTED',
          payload: {
            trainNo: _0x275414,
            trainClass: _0x14c851,
          },
        },
        () => {
          window.close()
        }
      )
    }
  })
})
function getStationNameAndCode(_0x5f1b13) {
  let _0x1ab264 = _0x5f1b13.trim().match(/^(.*)\s+-\s+([A-Z]{2,5})$/)
  if (_0x1ab264) {
    return {
      name: _0x1ab264[1].trim(),
      code: _0x1ab264[2],
    }
  }
  return {
    name: _0x5f1b13.trim(),
    code: '',
  }
}
function fetchTrainListFromEtrainInfo(_0x4291fc, _0x55c6ee, _0x3e4c53) {
  let _0x5d8350 = getStationNameAndCode(_0x4291fc),
    _0x328945 = getStationNameAndCode(_0x55c6ee)
  if (!_0x5d8350.code || !_0x328945.code) {
    document.getElementById('results-table').innerHTML =
      '<tr><td>Invalid station format.</td></tr>'
    return
  }
  let _0x20347c = _0x3e4c53.replace(/-/g, ''),
    _0x41534e =
      'https://m.etrain.info/trains/' +
      _0x5d8350.name.replace(/\s+/g, '-') +
      '-' +
      _0x5d8350.code +
      '-to-' +
      _0x328945.name.replace(/\s+/g, '-') +
      '-' +
      _0x328945.code +
      '?date=' +
      _0x20347c
  chrome.runtime.sendMessage(
    {
      type: 'FETCH_TRAIN_LIST',
      url: _0x41534e,
    },
    (_0x3e85bd) => {
      _0x3e85bd && _0x3e85bd.success
        ? parseAndDisplayHTMLForEtrainInfo(_0x3e85bd.data, _0x3e4c53)
        : (document.getElementById('results-table').innerHTML =
            '<tr><td>Failed to fetch results.</td></tr>')
    }
  )
}
function parseAndDisplayHTMLForEtrainInfo(_0xf68a93, _0x5b01a4) {
  const _0x3f7937 = document.getElementById('results-table')
  try {
    const _0x51a888 = new Date(_0x5b01a4),
      _0x25b65d = _0x51a888.getUTCDay()
    let _0x14cf17 = new DOMParser(),
      _0x427965 = _0x14cf17.parseFromString(_0xf68a93, 'text/html'),
      _0x3ab0ee = _0x427965.querySelectorAll(
        '.myTable.data tbody tr[data-train]'
      ),
      _0x21b7c9 =
        '<thead><tr><th>Number</th><th>Name</th><th>From</th><th>Dep</th><th>To</th><th>Arr</th><th>Classes</th></tr></thead><tbody>',
      _0x53de2c = 0
    _0x3ab0ee.forEach((_0x3caa3a) => {
      const _0x2f8f2a = JSON.parse(_0x3caa3a.getAttribute('data-train')),
        _0x3cf7a6 = _0x2f8f2a.dy || '0000000'
      if (_0x3cf7a6[_0x25b65d] === '1') {
        _0x53de2c++
        const {
          num: _0x34c53e,
          name: _0x370a25,
          s: _0xab45ff,
          st: _0x80d64,
          d: _0x4945c1,
          dt: _0x568595,
        } = _0x2f8f2a
        let _0x7b433 = Array.from(
          _0x3caa3a.querySelectorAll('td:last-child a.cavlink')
        )
          .map((_0x10184b) => {
            const _0x2f098d = _0x10184b.innerText.trim()
            return (
              '<span class="class-selector" data-train-number="' +
              _0x34c53e +
              '" data-train-name="' +
              _0x370a25 +
              '" data-class-code="' +
              _0x2f098d +
              '">' +
              _0x2f098d +
              '</span>'
            )
          })
          .join('')
        _0x21b7c9 +=
          '<tr><td>' +
          _0x34c53e +
          '</td><td>' +
          _0x370a25 +
          '</td><td>' +
          _0xab45ff +
          '</td><td>' +
          _0x80d64 +
          '</td><td>' +
          _0x4945c1 +
          '</td><td>' +
          _0x568595 +
          '</td><td>' +
          _0x7b433 +
          '</td></tr>'
      }
    })
    _0x21b7c9 += '</tbody>'
    _0x3f7937.innerHTML =
      _0x53de2c > 0
        ? _0x21b7c9
        : "<tr><td colspan='7'>No trains found for this date.</td></tr>"
  } catch (_0x3be514) {
    _0x3f7937.innerHTML = '<tr><td>Error parsing results.</td></tr>'
  }
}
