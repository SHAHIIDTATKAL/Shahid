const container = document.getElementById("versionContainer");
fetch('https://shahiidtatkal.github.io/Shahid/accest/Version.json?nocache=' + new Date().getTime()).then(_0x1841ea => _0x1841ea.json()).then(_0x32b3ac => {
  const _0x4f1cdb = _0x32b3ac.latestVersion;
  const _0x275e15 = _0x32b3ac.oldVersionMessage;
  const _0x37b13e = document.createElement("div");
  const _0xd3bff3 = document.createElement('span');
  _0xd3bff3.textContent = "Version: V1.5.13 - ";
  _0xd3bff3.style.fontWeight = "bold";
  _0xd3bff3.style.fontSize = '15px';
  const _0x448ba3 = document.createElement("span");
  _0x448ba3.style.fontSize = "15px";
  if ("V1.5.13" === _0x4f1cdb) {
    _0x448ba3.textContent = "You are using the latest version.";
    _0x448ba3.style.color = "green";
  } else if (compareVersions("V1.5.13", _0x4f1cdb) < 0x0) {
    _0x448ba3.textContent = "Please update this extension.";
    _0x448ba3.style.color = "red";
    showUpdatePopup(_0x275e15, _0x4f1cdb);
  } else {
    _0x448ba3.textContent = "Invalid version.";
    _0x448ba3.style.color = "orange";
    showUpdatePopup("Your extension version is invalid. Please update now.", _0x4f1cdb);
  }
  _0x37b13e.appendChild(_0xd3bff3);
  _0x37b13e.appendChild(_0x448ba3);
  _0x37b13e.style.fontFamily = "Arial, sans-serif";
  _0x37b13e.style.paddingLeft = "10px";
  container.appendChild(_0x37b13e);
});
function compareVersions(_0x3a4b97, _0x32a0d7) {
  const _0x3816e0 = _0x3a4b97.replace(/[^\d.]/g, '').split('.').map(Number);
  const _0x4f6bcb = _0x32a0d7.replace(/[^\d.]/g, '').split('.').map(Number);
  const _0x4b4232 = Math.max(_0x3816e0.length, _0x4f6bcb.length);
  for (let _0x4c69f1 = 0x0; _0x4c69f1 < _0x4b4232; _0x4c69f1++) {
    const _0x289039 = _0x3816e0[_0x4c69f1] || 0x0;
    const _0x1974f6 = _0x4f6bcb[_0x4c69f1] || 0x0;
    if (_0x289039 > _0x1974f6) {
      return 0x1;
    }
    if (_0x289039 < _0x1974f6) {
      return -0x1;
    }
  }
  return 0x0;
}
function showUpdatePopup(_0x44200e, _0x30be86) {
  const _0x47c7a5 = document.createElement("div");
  _0x47c7a5.style.position = "fixed";
  _0x47c7a5.style.top = '0';
  _0x47c7a5.style.left = '0';
  _0x47c7a5.style.width = "100%";
  _0x47c7a5.style.height = "100%";
  _0x47c7a5.style.backgroundColor = "rgba(0, 0, 0, 0.6)";
  _0x47c7a5.style.zIndex = '9999';
  _0x47c7a5.style.display = "flex";
  _0x47c7a5.style.justifyContent = 'center';
  _0x47c7a5.style.alignItems = "center";
  const _0x577532 = document.createElement("div");
  _0x577532.style.backgroundColor = "#fff";
  _0x577532.style.padding = "20px";
  _0x577532.style.borderRadius = '8px';
  _0x577532.style.boxShadow = "0 0 20px rgba(0,0,0,0.3)";
  _0x577532.style.textAlign = 'center';
  _0x577532.style.maxWidth = '400px';
  _0x577532.style.width = "90%";
  const _0x213315 = document.createElement('h2');
  _0x213315.textContent = "Please update this extension";
  _0x213315.style.margin = "0px";
  const _0x243139 = document.createElement('p');
  _0x243139.textContent = "Latest Version: " + _0x30be86;
  _0x243139.style.fontWeight = "bold";
  _0x243139.style.marginBottom = '8px';
  _0x243139.style.color = "#007bff";
  const _0x123e39 = document.createElement("div");
  _0x123e39.innerHTML = _0x44200e;
  _0x123e39.style.marginBottom = "20px";
  _0x123e39.style.color = "#333";
  const _0x3e84f5 = document.createElement('a');
  _0x3e84f5.href = 'https://github.com/SHAHIIDTATKAL/Shahid/blob/main/RAJEBULL.zip';
  _0x3e84f5.textContent = "Update Now";
  _0x3e84f5.target = "_blank";
  _0x3e84f5.style.backgroundColor = "#007bff";
  _0x3e84f5.style.color = "#fff";
  _0x3e84f5.style.padding = "10px 20px";
  _0x3e84f5.style.borderRadius = "4px";
  _0x3e84f5.style.textDecoration = "none";
  _0x3e84f5.style.fontWeight = "bold";
  _0x577532.appendChild(_0x213315);
  _0x577532.appendChild(_0x243139);
  _0x577532.appendChild(_0x123e39);
  _0x577532.appendChild(_0x3e84f5);
  _0x47c7a5.appendChild(_0x577532);
  document.body.appendChild(_0x47c7a5);
}
document.getElementById("openPopupTab").addEventListener("click", () => {
  chrome.tabs.create({
    'url': chrome.runtime.getURL("popup.html")
  });
});
(function () {
  const _0x1f73dd = setInterval(() => {
    const _0x1a9dff = document.getElementById("clearCheckbox");
    const _0x3d0632 = document.getElementById("irctc-login");
    const _0x5d5305 = document.getElementById('irctc-password');
    if (!_0x1a9dff || !_0x3d0632 || !_0x5d5305) {
      return;
    }
    clearInterval(_0x1f73dd);
    const _0x464f42 = localStorage.getItem('irctcClearCheckbox');
    if (_0x464f42 === "checked") {
      _0x1a9dff.checked = true;
      _0x1a4ea3();
    }
    _0x1a9dff.addEventListener("change", function () {
      if (_0x1a9dff.checked) {
        _0x1a4ea3();
        localStorage.setItem('irctcClearCheckbox', "checked");
      } else {
        _0x3d0632.disabled = false;
        _0x5d5305.disabled = false;
        localStorage.setItem("irctcClearCheckbox", "unchecked");
      }
    });
    function _0x1a4ea3() {
      _0x2f9010(_0x3d0632);
      _0x2f9010(_0x5d5305);
      _0x3d0632.disabled = true;
      _0x5d5305.disabled = true;
    }
    function _0x2f9010(_0xea4239) {
      _0xea4239.value = '';
      _0xea4239.dispatchEvent(new Event("input", {
        'bubbles': true
      }));
      _0xea4239.dispatchEvent(new Event("change", {
        'bubbles': true
      }));
    }
  }, 0x12c);
})();
document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get(["plan_expiry"], _0x28c066 => {
    const _0x592fc5 = document.getElementById("UserPlanExpairy");
    if (_0x592fc5 && _0x28c066.plan_expiry !== undefined) {
      if (_0x28c066.plan_expiry) {
        _0x592fc5.textContent = _0x28c066.plan_expiry;
        const _0x557d21 = new Date(_0x28c066.plan_expiry);
        const _0x2569d1 = new Date();
        _0x592fc5.style.color = _0x2569d1 <= _0x557d21 ? "green" : "red";
      } else {
        _0x592fc5.textContent = "User Not Found";
        _0x592fc5.style.color = 'orange';
      }
    }
  });
});
document.addEventListener("DOMContentLoaded", function () {
  const _0x12c152 = document.getElementById("submitBtn2autoClickCheckbox");
  chrome.storage.sync.get(["submitBtn2autoClickEnabled"], function (_0x504930) {
    _0x12c152.checked = _0x504930.submitBtn2autoClickEnabled || false;
  });
  _0x12c152.addEventListener("change", function () {
    chrome.storage.sync.set({
      'submitBtn2autoClickEnabled': _0x12c152.checked
    }, function () {
      console.log("Setting saved:", _0x12c152.checked);
    });
  });
});
document.addEventListener('DOMContentLoaded', function () {
  var _0x453202 = document.getElementById("cardexpiry");
  if (_0x453202) {
    _0x453202.addEventListener("input", function (_0x128060) {
      var _0x34b9db = _0x128060.target.value.replace(/\D/g, '');
      if (_0x34b9db.length > 0x4) {
        _0x34b9db = _0x34b9db.slice(0x0, 0x4);
      }
      if (_0x34b9db.length >= 0x3) {
        _0x34b9db = _0x34b9db.slice(0x0, 0x2) + '/' + _0x34b9db.slice(0x2);
      }
      _0x128060.target.value = _0x34b9db;
    });
  }
});
async function loadNotice() {
  try {
    const _0x55c68a = await fetch('https://shahiidtatkal.github.io/Shahid/accest/notice.json?nocache=' + new Date().getTime());
    const _0x16a52f = await _0x55c68a.json();
    const _0x51c953 = _0x16a52f.notice;
    const _0x53e767 = document.getElementById("notice-container");
    if (_0x51c953 && _0x51c953.trim() !== '') {
      _0x53e767.innerHTML = _0x51c953;
      _0x53e767.style.display = 'block';
    } else {
      _0x53e767.innerHTML = '';
      _0x53e767.style.display = 'none';
    }
  } catch (_0x24937e) {
    console.error("Failed to fetch notice:", _0x24937e);
  }
}
loadNotice();
document.getElementById("openPopupTab").addEventListener("click", () => {
  chrome.tabs.create({
    'url': chrome.runtime.getURL("popup.html")
  });
});
(function () {
  const _0x2e460e = setInterval(() => {
    const _0x5a397e = document.getElementById("clearCheckbox");
    const _0x420517 = document.getElementById('irctc-login');
    const _0x1f43b3 = document.getElementById("irctc-password");
    if (!_0x5a397e || !_0x420517 || !_0x1f43b3) {
      return;
    }
    clearInterval(_0x2e460e);
    const _0x52dde0 = localStorage.getItem("irctcClearCheckbox");
    if (_0x52dde0 === "checked") {
      _0x5a397e.checked = true;
      _0x1a702();
    }
    _0x5a397e.addEventListener("change", function () {
      if (_0x5a397e.checked) {
        _0x1a702();
        localStorage.setItem('irctcClearCheckbox', "checked");
      } else {
        _0x420517.disabled = false;
        _0x1f43b3.disabled = false;
        localStorage.setItem("irctcClearCheckbox", "unchecked");
      }
    });
    function _0x1a702() {
      _0x383e04(_0x420517);
      _0x383e04(_0x1f43b3);
      _0x420517.disabled = true;
      _0x1f43b3.disabled = true;
    }
    function _0x383e04(_0x120081) {
      _0x120081.value = '';
      _0x120081.dispatchEvent(new Event("input", {
        'bubbles': true
      }));
      _0x120081.dispatchEvent(new Event('change', {
        'bubbles': true
      }));
    }
  }, 0x12c);
})();
document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get(["plan_expiry"], _0x27b786 => {
    const _0x32f852 = document.getElementById("UserPlanExpairy");
    if (_0x32f852 && _0x27b786.plan_expiry !== undefined) {
      if (_0x27b786.plan_expiry) {
        _0x32f852.textContent = _0x27b786.plan_expiry;
        const _0x2e021e = new Date(_0x27b786.plan_expiry);
        const _0x25e076 = new Date();
        _0x32f852.style.color = _0x25e076 <= _0x2e021e ? "green" : "red";
      } else {
        _0x32f852.textContent = "User Not Found";
        _0x32f852.style.color = 'orange';
      }
    }
  });
});
document.addEventListener("DOMContentLoaded", function () {
  const _0x1a6aa9 = document.getElementById("submitBtn2autoClickCheckbox");
  chrome.storage.sync.get(["submitBtn2autoClickEnabled"], function (_0x5cdfbd) {
    _0x1a6aa9.checked = _0x5cdfbd.submitBtn2autoClickEnabled || false;
  });
  _0x1a6aa9.addEventListener('change', function () {
    chrome.storage.sync.set({
      'submitBtn2autoClickEnabled': _0x1a6aa9.checked
    }, function () {
      console.log("Setting saved:", _0x1a6aa9.checked);
    });
  });
});
document.addEventListener('DOMContentLoaded', function () {
  var _0xb182e8 = document.getElementById("cardexpiry");
  if (_0xb182e8) {
    _0xb182e8.addEventListener('input', function (_0x26f1fa) {
      var _0x16149f = _0x26f1fa.target.value.replace(/\D/g, '');
      if (_0x16149f.length > 0x4) {
        _0x16149f = _0x16149f.slice(0x0, 0x4);
      }
      if (_0x16149f.length >= 0x3) {
        _0x16149f = _0x16149f.slice(0x0, 0x2) + '/' + _0x16149f.slice(0x2);
      }
      _0x26f1fa.target.value = _0x16149f;
    });
  }
});