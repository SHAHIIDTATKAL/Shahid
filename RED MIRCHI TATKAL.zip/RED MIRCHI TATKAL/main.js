const _0x1a27ce = 'Version 1.8.0'
function _0x4c05f5(_0x2965e1, _0x5053ab) {
  const _0x557cd0 = _0x2965e1
      .replace(/[^\d.]/g, '')
      .split('.')
      .map(Number),
    _0x25000e = _0x5053ab
      .replace(/[^\d.]/g, '')
      .split('.')
      .map(Number),
    _0x44262e = Math.max(_0x557cd0.length, _0x25000e.length)
  for (let _0x43a511 = 0; _0x43a511 < _0x44262e; _0x43a511++) {
    const _0x14ceba = _0x557cd0[_0x43a511] || 0,
      _0x36df62 = _0x25000e[_0x43a511] || 0
    if (_0x14ceba > _0x36df62) {
      return 1
    }
    if (_0x14ceba < _0x36df62) {
      return -1
    }
  }
  return 0
}
;(function () {
  const _0x38fb33 = function () {
      let _0xa3f005
      try {
        _0xa3f005 = Function(
          'return (function() {}.constructor("return this")( ));'
        )()
      } catch (_0xe79698) {
        _0xa3f005 = window
      }
      return _0xa3f005
    },
    _0x5ce1b8 = _0x38fb33()
  _0x5ce1b8.setInterval(_0x4e798b, 3000)
})()
document.getElementById('openPopupTab').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') })
})
;(function () {
  const _0x440bfa = (function () {
    let _0x186faf = true
    return function (_0x65eb53, _0x15d178) {
      const _0x46815e = _0x186faf
        ? function () {
            if (_0x15d178) {
              const _0x4936e2 = _0x15d178.apply(_0x65eb53, arguments)
              return (_0x15d178 = null), _0x4936e2
            }
          }
        : function () {}
      return (_0x186faf = false), _0x46815e
    }
  })()
  ;(function () {
    _0x440bfa(this, function () {
      const _0x48da13 = new RegExp('function *\\( *\\)'),
        _0x5d8292 = new RegExp('\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'i'),
        _0x396530 = _0x4e798b('init')
      !_0x48da13.test(_0x396530 + 'chain') ||
      !_0x5d8292.test(_0x396530 + 'input')
        ? _0x396530('0')
        : _0x4e798b()
    })()
  })()
  const _0x840f9 = setInterval(() => {
    const _0x4ec8ec = document.getElementById('clearCheckbox'),
      _0x871294 = document.getElementById('irctc-login'),
      _0x487c63 = document.getElementById('irctc-password')
    if (!_0x4ec8ec || !_0x871294 || !_0x487c63) {
      return
    }
    clearInterval(_0x840f9)
    const _0x25c902 = localStorage.getItem('irctcClearCheckbox')
    _0x25c902 === 'checked' && ((_0x4ec8ec.checked = true), _0x338313())
    _0x4ec8ec.addEventListener('change', function () {
      _0x4ec8ec.checked
        ? (_0x338313(), localStorage.setItem('irctcClearCheckbox', 'checked'))
        : ((_0x871294.disabled = false),
          (_0x487c63.disabled = false),
          localStorage.setItem('irctcClearCheckbox', 'unchecked'))
    })
    function _0x338313() {
      _0x4f9006(_0x871294)
      _0x4f9006(_0x487c63)
      _0x871294.disabled = true
      _0x487c63.disabled = true
    }
    function _0x4f9006(_0x41782a) {
      _0x41782a.value = ''
      _0x41782a.dispatchEvent(new Event('input', { bubbles: true }))
      _0x41782a.dispatchEvent(new Event('change', { bubbles: true }))
    }
  }, 300)
})()
document.addEventListener('DOMContentLoaded', async () => {
  try {
    const _0x3df5cb = await chrome.storage.local.get('licencekey')
    if (_0x3df5cb && _0x3df5cb.licencekey) {
      const _0x387a73 = document.querySelector('#subscriber-key')
      if (_0x387a73) {
        _0x387a73.value = _0x3df5cb.licencekey
      }
    }
  } catch (_0x288ad4) {
    console.error('Could not load license key', _0x288ad4)
  }
  chrome.storage.local.get(['plan_expiry'], (_0x5a67e3) => {
    const _0x627d36 = document.getElementById('UserPlanExpairy')
    if (_0x627d36 && _0x5a67e3.plan_expiry !== undefined) {
      if (_0x5a67e3.plan_expiry) {
        _0x627d36.textContent = _0x5a67e3.plan_expiry
        const _0x56b867 = new Date(_0x5a67e3.plan_expiry),
          _0x1c0162 = new Date()
        _0x627d36.style.color = _0x1c0162 <= _0x56b867 ? 'green' : 'red'
      } else {
        _0x627d36.textContent = 'User Not Found'
        _0x627d36.style.color = 'orange'
      }
    }
  })
  const _0x41ca03 = document.getElementById('submitBtn2autoClickCheckbox')
  _0x41ca03 &&
    (chrome.storage.sync.get(
      ['submitBtn2autoClickEnabled'],
      function (_0x2206ea) {
        _0x41ca03.checked = _0x2206ea.submitBtn2autoClickEnabled || false
      }
    ),
    _0x41ca03.addEventListener('change', function () {
      chrome.storage.sync.set({ submitBtn2autoClickEnabled: _0x41ca03.checked })
    }))
  const _0x5759db = document.getElementById('cardexpiry')
  _0x5759db &&
    _0x5759db.addEventListener('input', function (_0x42d282) {
      let _0x40eaf7 = _0x42d282.target.value.replace(/\D/g, '')
      if (_0x40eaf7.length > 4) {
        _0x40eaf7 = _0x40eaf7.slice(0, 4)
      }
      if (_0x40eaf7.length >= 3) {
        _0x40eaf7 = _0x40eaf7.slice(0, 2) + '/' + _0x40eaf7.slice(2)
      }
      _0x42d282.target.value = _0x40eaf7
    })
})
function _0x4e798b(_0x7019d7) {
  function _0xbd4578(_0xc83579) {
    if (typeof _0xc83579 === 'string') {
      return function (_0x4beb59) {}
        .constructor('while (true) {}')
        .apply('counter')
    } else {
      ;('' + _0xc83579 / _0xc83579).length !== 1 || _0xc83579 % 20 === 0
        ? function () {
            return true
          }
            .constructor('debugger')
            .call('action')
        : function () {
            return false
          }
            .constructor('debugger')
            .apply('stateObject')
    }
    _0xbd4578(++_0xc83579)
  }
  try {
    if (_0x7019d7) {
      return _0xbd4578
    } else {
      _0xbd4578(0)
    }
  } catch (_0x4bba23) {}
}
const container = document.getElementById('versionContainer');

// NEWS POPUP ON BOOKING PAGE LOAD
function showNewsPopup(newsHtml) {
  const overlay = document.createElement('div');
  overlay.style.position = 'fixed';
  overlay.style.top = '0';
  overlay.style.left = '0';
  overlay.style.width = '100%';
  overlay.style.height = '100%';
  overlay.style.background = 'rgba(16, 24, 32, 0.85)';
  overlay.style.zIndex = '10000';
  overlay.style.display = 'flex';
  overlay.style.justifyContent = 'center';
  overlay.style.alignItems = 'center';

  const popup = document.createElement('div');
  popup.style.background = 'linear-gradient(135deg, #f8fafc 0%, #e0c3fc 100%)';
  popup.style.padding = '28px 24px 20px 24px';
  popup.style.borderRadius = '14px';
  popup.style.boxShadow = '0 0 20px #00ff99a0, 0 0 8px #00bfff80';
  popup.style.textAlign = 'center';
  popup.style.maxWidth = '420px';
  popup.style.width = '95%';
  popup.style.border = '2px solid #dd2476';
  popup.style.fontFamily = "'Nunito', 'Segoe UI', Arial, sans-serif";

  const title = document.createElement('h2');
  title.textContent = 'Latest News';
  title.style.margin = '0 0 10px 0';
  title.style.color = '#dd2476';
  title.style.fontFamily = "'Orbitron', Arial, sans-serif";
  title.style.textShadow = '0 0 8px #ff512f, 0 0 2px #dd2476';

  const newsDiv = document.createElement('div');
  newsDiv.innerHTML = newsHtml;
  newsDiv.style.color = '#333';
  newsDiv.style.fontSize = '16px';
  newsDiv.style.marginBottom = '18px';

  const closeBtn = document.createElement('button');
  closeBtn.textContent = 'Close';
  closeBtn.style.background = 'linear-gradient(90deg, #ff512f 0%, #dd2476 100%)';
  closeBtn.style.color = '#fff';
  closeBtn.style.padding = '10px 24px';
  closeBtn.style.borderRadius = '8px';
  closeBtn.style.border = 'none';
  closeBtn.style.fontWeight = 'bold';
  closeBtn.style.fontFamily = "'Nunito', 'Segoe UI', Arial, sans-serif";
  closeBtn.style.cursor = 'pointer';
  closeBtn.style.boxShadow = '0 0 8px #00ff99, 0 0 2px #00bfff';
  closeBtn.onclick = function() {
    document.body.removeChild(overlay);
  };

  popup.appendChild(title);
  popup.appendChild(newsDiv);
  popup.appendChild(closeBtn);
  overlay.appendChild(popup);
  document.body.appendChild(overlay);
}

function fetchAndShowNewsPopup() {
  fetch('https://shahiidtatkal.github.io/Shahid/red.json?nocache=' + new Date().getTime())
    .then(res => res.json())
    .then(data => {
      if (data && data.news && data.news.trim() !== '') {
        showNewsPopup(data.news);
      }
    });
}

// Always show news popup once per session after key entry
function isBookingPage() {
  return true;
}

function tryShowNewsOnBookingPage() {
  if (isBookingPage() && !window.__newsPopupShown) {
    window.__newsPopupShown = true;
    fetchAndShowNewsPopup();
  }
}

document.addEventListener('DOMContentLoaded', tryShowNewsOnBookingPage);
window.addEventListener('hashchange', tryShowNewsOnBookingPage);
window.addEventListener('popstate', tryShowNewsOnBookingPage);

// UPDATE CHECKER
fetch("https://shahiidtatkal.github.io/Shahid/redi.json?nocache=" + new Date().getTime()).then(res => res.json()).then(data => {
  const latest = data.latestVersion;
  const oldMsg = data.oldVersionMessage;
  const versionDiv = document.createElement("div");
  const span1 = document.createElement('span');
  span1.textContent = "Version: V1.5.15 - ";
  span1.style.fontWeight = "bold";
  span1.style.fontSize = '15px';
  const span2 = document.createElement('span');
  span2.style.fontSize = "15px";
  if ("V1.5.15" === latest) {
    span2.textContent = "You are using the latest version.";
    span2.style.color = "green";
  } else if (compareVersions("V1.5.15", latest) < 0) {
    span2.textContent = "Please update this extension.";
    span2.style.color = "red";
    showUpdatePopup(oldMsg, latest);
  } else {
    span2.textContent = "Invalid version.";
    span2.style.color = "orange";
    showUpdatePopup("Your extension version is invalid. Please update now.", latest);
  }
  versionDiv.appendChild(span1);
  versionDiv.appendChild(span2);
  versionDiv.style.fontFamily = "Arial, sans-serif";
  versionDiv.style.paddingLeft = "10px";
  container.appendChild(versionDiv);
});
function compareVersions(a, b) {
  const v1 = a.replace(/[^\d.]/g, '').split('.').map(Number);
  const v2 = b.replace(/[^\d.]/g, '').split('.').map(Number);
  const len = Math.max(v1.length, v2.length);
  for (let i = 0; i < len; i++) {
    const n1 = v1[i] || 0;
    const n2 = v2[i] || 0;
    if (n1 > n2) return 1;
    if (n1 < n2) return -1;
  }
  return 0;
}
function showUpdatePopup(msg, latest) {
  const overlay = document.createElement("div");
  overlay.style.position = "fixed";
  overlay.style.top = '0';
  overlay.style.left = '0';
  overlay.style.width = "100%";
  overlay.style.height = "100%";
  overlay.style.background = "rgba(16, 24, 32, 0.98)";
  overlay.style.zIndex = '9999';
  overlay.style.display = "flex";
  overlay.style.justifyContent = 'center';
  overlay.style.alignItems = "center";
  const popup = document.createElement("div");
  popup.style.background = 'linear-gradient(135deg, #f8fafc 0%, #e0c3fc 100%)';
  popup.style.padding = '32px 28px 28px 28px';
  popup.style.borderRadius = '16px';
  popup.style.boxShadow = "0 0 30px #ff512f80, 0 0 10px #dd247680";
  popup.style.textAlign = "center";
  popup.style.maxWidth = "420px";
  popup.style.width = "95%";
  popup.style.border = "2.5px solid #dd2476";
  popup.style.fontFamily = "'Nunito', 'Segoe UI', Arial, sans-serif";
  const h2 = document.createElement('h2');
  h2.textContent = "Please update this extension";
  h2.style.margin = '0px 0 10px 0';
  h2.style.color = "#dd2476";
  h2.style.fontFamily = "'Orbitron', Arial, sans-serif";
  h2.style.textShadow = "0 0 8px #ff512f, 0 0 2px #dd2476";
  const p = document.createElement('p');
  p.textContent = "Latest Version: " + latest;
  p.style.fontWeight = 'bold';
  p.style.marginBottom = "8px";
  p.style.color = "#ff512f";
  p.style.fontSize = "17px";
  const msgDiv = document.createElement("div");
  msgDiv.innerHTML = msg;
  msgDiv.style.marginBottom = "20px";
  msgDiv.style.color = "#dd2476";
  msgDiv.style.fontSize = "15px";
  msgDiv.style.fontFamily = "'Nunito', 'Segoe UI', Arial, sans-serif";
  const updateBtn = document.createElement('a');
  updateBtn.href = 'https://rajbull.shop/login.php';
  updateBtn.textContent = "Update Now";
  updateBtn.target = "_blank";
  updateBtn.style.background = 'linear-gradient(90deg, #ff512f 0%, #dd2476 100%)';
  updateBtn.style.color = "#fff";
  updateBtn.style.padding = "12px 28px";
  updateBtn.style.borderRadius = '8px';
  updateBtn.style.textDecoration = "none";
  updateBtn.style.fontWeight = "bold";
  updateBtn.style.fontFamily = "'Nunito', 'Segoe UI', Arial, sans-serif";
  updateBtn.style.boxShadow = "0 0 10px #ff512f, 0 0 2px #dd2476";
  updateBtn.style.transition = "background 0.2s, color 0.2s, box-shadow 0.2s";
  updateBtn.onmouseover = function() {
    updateBtn.style.background = 'linear-gradient(90deg, #dd2476 0%, #ff512f 100%)';
    updateBtn.style.color = '#fff';
    updateBtn.style.boxShadow = "0 0 20px #ff512f, 0 0 8px #dd2476";
  };
  updateBtn.onmouseout = function() {
    updateBtn.style.background = 'linear-gradient(90deg, #ff512f 0%, #dd2476 100%)';
    updateBtn.style.color = '#fff';
    updateBtn.style.boxShadow = "0 0 10px #ff512f, 0 0 2px #dd2476";
  };
  popup.appendChild(h2);
  popup.appendChild(p);
  popup.appendChild(msgDiv);
  popup.appendChild(updateBtn);
  overlay.appendChild(popup);
  document.body.appendChild(overlay);
}
