const _0x30a695 = (function () {
    let _0x2687f7 = true
    return function (_0x1cd180, _0x377b06) {
      const _0x1fe865 = _0x2687f7
        ? function () {
            if (_0x377b06) {
              const _0x43e5b1 = _0x377b06.apply(_0x1cd180, arguments)
              return (_0x377b06 = null), _0x43e5b1
            }
          }
        : function () {}
      return (_0x2687f7 = false), _0x1fe865
    }
  })()
  ;(function () {
    _0x30a695(this, function () {
      const _0x1de2bc = new RegExp('function *\\( *\\)'),
        _0x576241 = new RegExp('\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'i'),
        _0x38de1c = _0x58133e('init')
      !_0x1de2bc.test(_0x38de1c + 'chain') || !_0x576241.test(_0x38de1c + 'input')
        ? _0x38de1c('0')
        : _0x58133e()
    })()
  })()
  let _0x308f39 = null
  function _0x4b5307() {
    if (_0x308f39) {
      console.log('Keep-Alive पिंग पहले से ही एक्टिव है\u0964')
      return
    }
    console.log(
      'Keep-Alive पिंग शुरू\u0964 हर 30 सेकंड में सेशन को ताज़ा किया जाएगा\u0964'
    )
    _0x308f39 = setInterval(() => {
      fetch('https://www.irctc.co.in/nget/api/login/getUserDetails')
        .then((_0x4bd08a) => {
          _0x4bd08a.ok
            ? console.log(
                'Keep-alive पिंग सफल रहा at',
                new Date().toLocaleTimeString()
              )
            : (console.warn(
                'Keep-alive पिंग का रिस्पांस ठीक नहीं था, शायद लॉगआउट हो गया है\u0964 पिंग रोका जा रहा है\u0964'
              ),
              clearInterval(_0x308f39))
        })
        .catch((_0x5925a3) => {
          console.error('Keep-alive पिंग फेल हो गया:', _0x5925a3)
          clearInterval(_0x308f39)
        })
    }, 30000)
  }
  const _0x53dc23 = setInterval(() => {
    const _0x3c762a = document.querySelector(
      'button.btn.btn-primary[aria-label*="Press OK to confirm"]'
    )
    _0x3c762a &&
      (console.log('OCEAN: Initial confirmation pop-up found. Clicking OK.'),
      _0x3c762a.click(),
      clearInterval(_0x53dc23))
  }, 500)
  function _0x3acc96() {
    setInterval(() => {
      const _0x482a2b = new Date(),
        _0x4d2711 = String(_0x482a2b.getHours()).padStart(2, '0'),
        _0x2f376e = String(_0x482a2b.getMinutes()).padStart(2, '0'),
        _0x172a27 = String(_0x482a2b.getSeconds()).padStart(2, '0'),
        _0x3e1d39 = String(_0x482a2b.getMilliseconds()).padStart(3, '0'),
        _0x48f3af =
          _0x4d2711 + ':' + _0x2f376e + ':' + _0x172a27 + ':' + _0x3e1d39
      document.dispatchEvent(
        new CustomEvent('ocean-time-update', {
          detail: { timeString: _0x48f3af },
        })
      )
    }, 100)
    console.log(
      'OCEAN: सिस्टम समय प्रोवाइडर (मिलीसेकंड के साथ) शुरू हो गया है\u0964'
    )
  }
  function _0x2d580c(_0xd1b141, _0xfa49e1 = 4000) {
    const _0x27b3a4 = document.getElementById('ocean-fallback-notification')
    _0x27b3a4 && _0x27b3a4.remove()
    const _0x1feed8 = document.createElement('div')
    _0x1feed8.id = 'ocean-fallback-notification'
    _0x1feed8.textContent = '[OCEAN]: ' + _0xd1b141
    Object.assign(_0x1feed8.style, {
      position: 'fixed',
      top: '20px',
      left: '50%',
      transform: 'translateX(-50%)',
      backgroundColor: 'rgba(217, 30, 24, 0.9)',
      color: 'white',
      padding: '12px 25px',
      borderRadius: '8px',
      zIndex: '99999',
      fontSize: '16px',
      fontWeight: 'bold',
      boxShadow: '0 4px 15px rgba(0,0,0,0.3)',
    })
    document.body.appendChild(_0x1feed8)
    setTimeout(() => {
      const _0x5c13f9 = document.getElementById('ocean-fallback-notification')
      _0x5c13f9 && _0x5c13f9.remove()
    }, _0xfa49e1)
  }
  function _0x7ef444() {
    if (document.getElementById('ocean-animation-script')) {
      console.log('OCEAN: Animation assets already present.')
      return
    }
    console.log('OCEAN: Injecting animation assets...')
    const _0x53979b = document.createElement('link')
    _0x53979b.id = 'ocean-animation-style'
    _0x53979b.rel = 'stylesheet'
    _0x53979b.type = 'text/css'
    _0x53979b.href = chrome.runtime.getURL('animation.css')
    document.head.appendChild(_0x53979b)
    const _0x44d8ad = document.createElement('script')
    _0x44d8ad.id = 'ocean-animation-script'
    _0x44d8ad.src = chrome.runtime.getURL('animation.js')
    ;(document.head || document.documentElement).appendChild(_0x44d8ad)
    _0x44d8ad.onload = () => {
      console.log('OCEAN: animation.js loaded successfully.')
      _0x44d8ad.remove()
    }
    _0x44d8ad.onerror = () => {
      console.error('OCEAN: Failed to load animation.js.')
    }
  }
  function _0x1da2b4(_0x51802e) {
    const _0x4f5086 = window.location.href
    let _0x5f154e = 'loadLoginDetails'
    if (_0x4f5086.includes('booking/psgninput')) {
      _0x5f154e = 'fillPassengerDetails'
    } else {
      if (_0x4f5086.includes('booking/reviewBooking')) {
        _0x5f154e = 'reviewBooking'
      } else {
        if (_0x4f5086.includes('payment/bkgPaymentOptions')) {
          _0x5f154e = 'bkgPaymentOptions'
        } else {
          if (_0x4f5086.includes('booking/train-list')) {
            _0x5f154e = 'selectJourney'
          } else {
            if (_0x4f5086.includes('nget/train-search')) {
              const _0x2a1ebc = document.querySelector(
                'a.loginText.ng-star-inserted'
              )
              _0x2a1ebc &&
                _0x2a1ebc.innerText.trim().toUpperCase() === 'LOGOUT' &&
                (_0x5f154e = 'loadJourneyDetails')
            }
          }
        }
      }
    }
    const _0x2a1128 = _0x51802e.journey_details || {}
    _0x51802e.irctc_credentials &&
      _0x51802e.irctc_credentials.user_name &&
      (_0x2a1128.username = _0x51802e.irctc_credentials.user_name)
    const _0x3dd0bd = {
      journeyDetails: _0x2a1128,
      initialStatus: _0x5f154e,
    }
    console.log("OCEAN: Dispatching 'ocean-init-data' with payload:", _0x3dd0bd)
    setTimeout(() => {
      document.dispatchEvent(
        new CustomEvent('ocean-init-data', { detail: _0x3dd0bd })
      )
    }, 500)
  }
  function _0x2c1f2e(_0x1e75d6) {
    const _0x35df20 = {
      status: _0x1e75d6,
      time: new Date().toString().split(' ')[4],
    }
    chrome.runtime.sendMessage(_0x3d71a3(_0x35df20, 'status_update'))
    console.log(
      "OCEAN: Dispatching 'ocean-status-update' for [" + _0x1e75d6 + ']'
    )
    const _0x5cfa7a = _0x133101.journey_details || {}
    _0x133101.irctc_credentials &&
      _0x133101.irctc_credentials.user_name &&
      (_0x5cfa7a.username = _0x133101.irctc_credentials.user_name)
    const _0x3e1652 = {
      statusKey: _0x1e75d6,
      journeyDetails: _0x5cfa7a,
    }
    document.dispatchEvent(
      new CustomEvent('ocean-status-update', { detail: _0x3e1652 })
    )
  }
  function _0x143f41(_0x4ce076, _0xe5739c) {
    if (!_0x4ce076 || typeof _0xe5739c !== 'string') {
      console.warn('Element not provided or text is not a string for fastFill.')
      return
    }
    _0x4ce076.focus()
    _0x4ce076.value = _0xe5739c
    _0x4ce076.dispatchEvent(
      new Event('input', {
        bubbles: true,
        cancelable: true,
      })
    )
    _0x4ce076.dispatchEvent(
      new Event('change', {
        bubbles: true,
        cancelable: true,
      })
    )
    _0x4ce076.blur()
  }
  function _0x27c88a(_0x1430d7) {
    if (_0x1430d7 && typeof _0x1430d7.click === 'function') {
      if (_0x1430d7.disabled) {
        console.warn('Attempted to click on a disabled element:', _0x1430d7)
        return
      }
      _0x1430d7.click()
    } else {
      console.warn('Attempted to click on an invalid element:', _0x1430d7)
    }
  }
  function _0x4b244c(_0x50df0f) {
    const _0x9d4267 = Date.now()
    let _0xa3b7e1 = null
    do {
      _0xa3b7e1 = Date.now()
    } while (_0xa3b7e1 - _0x9d4267 < _0x50df0f)
  }
  function _0x24a45c(_0x4d39b7) {
    const _0x57d436 = document.createElement('div')
    _0x57d436.id = 'custom-alert'
    _0x57d436.style.cssText =
      "\n        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n        background-color: #fff; border: 1px solid #ccc; border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); padding: 20px; z-index: 10000;\n        text-align: center; font-family: 'Inter', sans-serif; max-width: 90%; width: 300px;\n    "
    _0x57d436.innerHTML =
      '\n        <p class="text-lg font-semibold mb-4">' +
      _0x4d39b7 +
      '</p>\n        <button id="custom-alert-ok" class="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">OK</button>\n    '
    document.body.appendChild(_0x57d436)
    document.getElementById('custom-alert-ok').onclick = () => _0x57d436.remove()
  }
  function _0x1f4852(_0x56bccd, _0x3a2c87, _0xd01a8e) {
    const _0x1e5447 = document.createElement('div')
    _0x1e5447.id = 'custom-confirm'
    _0x1e5447.style.cssText =
      "\n        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);\n        background-color: #fff; border: 1px solid #ccc; border-radius: 8px;\n        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); padding: 20px; z-index: 10000;\n        text-align: center; font-family: 'Inter', sans-serif; max-width: 90%; width: 350px;\n    "
    _0x1e5447.innerHTML =
      '\n        <p class="text-lg font-semibold mb-4">' +
      _0x56bccd +
      '</p>\n        <button id="custom-confirm-yes" class="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 mr-2">Yes</button>\n        <button id="custom-confirm-no" class="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600">No</button>\n    '
    document.body.appendChild(_0x1e5447)
    document.getElementById('custom-confirm-yes').onclick = () => {
      _0x1e5447.remove()
      if (_0x3a2c87) {
        _0x3a2c87()
      }
    }
    document.getElementById('custom-confirm-no').onclick = () => {
      _0x1e5447.remove()
      if (_0xd01a8e) {
        _0xd01a8e()
      }
    }
  }
  const _0x463eab = (_0x5881e5) => {
    return (
      _0x5881e5 &&
      getComputedStyle(_0x5881e5).display !== 'none' &&
      getComputedStyle(_0x5881e5).visibility !== 'hidden' &&
      parseFloat(getComputedStyle(_0x5881e5).opacity) > 0 &&
      !_0x5881e5.disabled
    )
  }
  let _0x133101 = {}
  function _0x3d71a3(_0x367454, _0x22b9dc) {
    return {
      msg: {
        type: _0x22b9dc,
        data: _0x367454,
      },
      sender: 'content_script',
      id: 'irctc',
    }
  }
  function _0x1ecdcf(_0x48d45f) {
    return '1A' === _0x48d45f
      ? 'AC First Class (1A)'
      : 'EV' === _0x48d45f
      ? 'Vistadome AC (EV)'
      : 'EC' === _0x48d45f
      ? 'Exec. Chair Car (EC)'
      : '2A' === _0x48d45f
      ? 'AC 2 Tier (2A)'
      : '3A' === _0x48d45f
      ? 'AC 3 Tier (3A)'
      : '3E' === _0x48d45f
      ? 'AC 3 Economy (3E)'
      : 'CC' === _0x48d45f
      ? 'AC Chair car (CC)'
      : 'SL' === _0x48d45f
      ? 'Sleeper (SL)'
      : '2S' === _0x48d45f
      ? 'Second Sitting (2S)'
      : 'None'
  }
  function _0x2faab8(_0x40753c) {
    return 'GN' === _0x40753c
      ? 'GENERAL'
      : 'TQ' === _0x40753c
      ? 'TATKAL'
      : 'PT' === _0x40753c
      ? 'PREMIUM TATKAL'
      : 'LD' === _0x40753c
      ? 'LADIES'
      : 'SR' === _0x40753c
      ? 'LOWER BERTH/SR.CITIZEN'
      : ''
  }
  console.log('[Ocean Log] Step 1: content_script.js loaded successfully.')
  let _0x10d7a2 = false
  function _0x536d4b() {
    if (_0x10d7a2) {
      console.log('[Ocean Log] Step 4a: Animation has already run. Skipping.')
      return
    }
    console.log(
      "[Ocean Log] Step 4: Starting to check for BOTH 'PNR' and 'CNF' text on the page..."
    )
    const _0x4e0ea9 = setInterval(() => {
      if (_0x10d7a2) {
        clearInterval(_0x4e0ea9)
        return
      }
      let _0x5a6a00 = false,
        _0x491384 = false
      const _0x410bb = document.querySelectorAll('span, strong, div, p, a')
      for (const _0x41bc57 of _0x410bb) {
        if (_0x41bc57.classList.contains('ocean-ignore')) {
          continue
        }
        if (_0x41bc57.offsetParent !== null && _0x41bc57.textContent) {
          const _0xe3ab7e = _0x41bc57.textContent.toUpperCase()
          _0xe3ab7e.includes('PNR') && (_0x5a6a00 = true)
          _0xe3ab7e.includes('CNF') && (_0x491384 = true)
        }
      }
      _0x5a6a00 &&
        _0x491384 &&
        (console.log(
          '[Ocean Log] Step 5: Success condition met! BOTH elements found.'
        ),
        clearInterval(_0x4e0ea9),
        (_0x10d7a2 = true),
        _0x1a3897())
    }, 700)
  }
  async function _0x1a3897() {
    console.log('[Ocean Log] Step 6: showPnrAnimation() function called.')
    try {
      // Fetch data as before
      const _0xbba600 = await chrome.storage.local.get([
          'journey_details',
          'other_preferences',
        ]),
        _0x1838dd = _0xbba600.journey_details || {},
        _0x2284a9 = _0xbba600.other_preferences || {}
      // Prepare data
      const now = new Date()
      now.setSeconds(now.getSeconds() - 15)
      const pnrTime = now.toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false,
        }),
        fromArr = _0x1838dd.from ? _0x1838dd.from.split('-') : [],
        toArr = _0x1838dd.destination ? _0x1838dd.destination.split('-') : [],
        dateArr = _0x1838dd.date ? _0x1838dd.date.split('-') : [],
        fromCode = fromArr.length > 0 ? fromArr[0].trim() : '',
        fromName = fromArr.length > 1 ? fromArr[1].trim() : '',
        toCode = toArr.length > 0 ? toArr[0].trim() : '',
        toName = toArr.length > 1 ? toArr[1].trim() : '',
        trainNo = _0x1838dd['train-no'] || 'N/A',
        quota = _0x1838dd.quota || '',
        classCode = _0x1838dd.class || '',
        pnr = _0x1838dd.pnr || 'XXXX',
        journeyDate = dateArr.length === 3 ? `${dateArr[0]}-${dateArr[1]}-${dateArr[2]}` : '',
        paymentMethod = _0x2284a9.paymentmethod || '',
        seatAvailable = _0x1838dd.seat_available || '0028',
        fareSelectors = [
          '.line-def .orange-text strong',
          'span.pull-right.orange-text strong',
          'span.font-bold.pull-right',
          '.fare-summary .amount',
        ]
      // Payment method mapping (as before)
      let paymentText = 'N/A'
      switch (paymentMethod) {
        case 'PAYTMUPI': paymentText = 'Paytm UPI'; break
        case 'PHONEPEUPIQR': paymentText = 'PhonePe QR'; break
        case 'RAZORPAYUPI': paymentText = 'Razorpay UPI'; break
        case 'PAYUUPI': paymentText = 'PayU UPI'; break
        case 'AMZPAYWAL': paymentText = 'Amazon Pay'; break
        case 'HDFCDB': paymentText = 'HDFC DC'; break
        case 'kotak_dc': paymentText = 'KOTAK DC'; break
        case 'MOBIKWIKWAL': paymentText = 'MOBIKWIK'; break
        case 'SBINETBANKING': paymentText = 'SBI NB'; break
        case 'HDFCNETBANKING': paymentText = 'ICICI NB'; break
        case 'IRCWA': paymentText = 'IRCTC eWallet'; break
        case 'irctc_dc':
        case 'IRCUPIID':
        case 'IRCUPIQR': paymentText = 'IRCTC iPay'; break
        default: paymentText = paymentMethod
      }
      // Fare
      let fare = 'N/A'
      for (const sel of fareSelectors) {
        const el = document.querySelector(sel)
        if (el) {
          const val = el.innerText.replace(/[^0-9.]/g, '')
          if (val) { fare = val; break }
        }
      }
      // Remove old popup if exists
      const oldPopup = document.getElementById('ocean-tatkal-success-popup')
      if (oldPopup) oldPopup.remove()
      // Remove old style if exists
      const oldStyle = document.getElementById('ocean-tatkal-success-style')
      if (oldStyle) oldStyle.remove()
      // CSS (screenshot style)
      const style = document.createElement('style')
      style.id = 'ocean-tatkal-success-style'
      style.textContent = `
#ocean-tatkal-success-popup {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 99999;
  font-family: Arial, sans-serif;
  min-width: 320px;
  max-width: 350px;
  background: #fff;
  border: 2px solid #b30000;
  border-radius: 8px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.25);
  overflow: hidden;
}
.ocean-popup-header {
  background: #c8002f;
  color: #fff;
  padding: 0;
  display: flex;
  align-items: center;
  height: 32px;
  font-size: 15px;
  font-weight: bold;
}
.ocean-popup-header span {
  flex: 1;
  text-align: center;
  border-right: 1px solid #fff3;
  padding: 0 8px;
}
.ocean-popup-header span:last-child {
  border-right: none;
}
.ocean-popup-body {
  background: #f7f7f7;
  padding: 0 0 10px 0;
}
.ocean-popup-card {
  margin: 10px 10px 0 10px;
  background: #fff;
  border-radius: 8px;
  border: 1px solid #e0e0e0;
  box-shadow: 0 2px 8px #0001;
  padding: 0;
  position: relative;
}
.ocean-popup-date {
  position: absolute;
  left: 0;
  top: 0;
  width: 60px;
  height: 100%;
  background: #f7f7f7;
  border-radius: 8px 0 0 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border-right: 1px solid #e0e0e0;
}
.ocean-popup-date .date-day {
  font-size: 22px;
  font-weight: bold;
  color: #2d2d2d;
  margin-bottom: 2px;
}
.ocean-popup-date .date-month {
  font-size: 13px;
  color: #c8002f;
  font-weight: bold;
  margin-bottom: 2px;
}
.ocean-popup-date .date-year {
  font-size: 11px;
  color: #888;
}
.ocean-popup-date .date-booked {
  margin-top: 6px;
  font-size: 11px;
  color: #fff;
  background: #4caf50;
  border-radius: 4px;
  padding: 2px 8px;
  font-weight: bold;
  transform: rotate(-15deg);
  box-shadow: 0 1px 4px #0002;
}
.ocean-popup-details {
  margin-left: 70px;
  padding: 10px 10px 10px 0;
  min-height: 70px;
}
.ocean-popup-details-row {
  font-size: 13px;
  color: #222;
  margin-bottom: 2px;
  display: flex;
  align-items: center;
}
.ocean-popup-details-row strong {
  min-width: 60px;
  color: #c8002f;
  font-weight: bold;
  font-size: 13px;
}
.ocean-popup-details-row .pnr-time {
  color: #0057b7;
  font-weight: bold;
  margin-left: 4px;
}
.ocean-popup-dropdowns {
  display: flex;
  gap: 6px;
  margin: 10px 10px 0 10px;
}
.ocean-popup-dropdowns select, .ocean-popup-dropdowns input {
  font-size: 13px;
  padding: 2px 6px;
  border-radius: 4px;
  border: 1px solid #bbb;
  background: #fff;
}
.ocean-popup-bank {
  background: #0057b7;
  color: #fff;
  font-size: 13px;
  border-radius: 4px;
  padding: 2px 8px;
  margin: 10px 10px 0 10px;
  display: inline-block;
  font-weight: bold;
  text-align: center;
  display: block;
  margin-left: auto;
  margin-right: auto;
}
.ocean-popup-amt-seat {
  margin: 10px 10px 0 10px;
  font-size: 14px;
  color: #222;
  font-weight: bold;
  text-align: center;
  display: block;
  margin-left: auto;
  margin-right: auto;
}
.ocean-popup-print-btn {
  margin: 12px 10px 10px 10px;
  width: calc(100% - 20px);
  background: #000;
  color: #fff;
  font-size: 15px;
  font-weight: bold;
  border: 2px solid #00e6e6;
  border-radius: 4px;
  padding: 8px 0;
  cursor: pointer;
  text-align: center;
  box-shadow: 0 2px 8px #0002;
  transition: background 0.2s;
}
.ocean-popup-print-btn:active {
  background: #222;
}
`;
      document.head.appendChild(style)
      // HTML
      const popup = document.createElement('div')
      popup.id = 'ocean-tatkal-success-popup'
      popup.innerHTML = `
        <div class="ocean-popup-header">
          <span>ID</span><span>Bank</span><span>Tickets</span><span>Tools</span><span>Auto</span>
        </div>
        <div class="ocean-popup-body">
          <div class="ocean-popup-card">
            <div class="ocean-popup-date">
              <div class="date-day">${dateArr[0] || '16'}</div>
              <div class="date-month">${dateArr[1] ? (new Date('2000-' + dateArr[1] + '-01')).toLocaleString('en-US', { month: 'short' }) : 'Sep'}</div>
              <div class="date-year">${dateArr[2] || '2018'}</div>
              <div class="date-booked">BOOKED</div>
            </div>
            <div class="ocean-popup-details">
              <div class="ocean-popup-details-row"><strong>PNR No :</strong> <span>${pnr}</span></div>
              <div class="ocean-popup-details-row" style="align-items:center;gap:4px;">
                <span style="font-size:17px;vertical-align:middle;">🚆</span>
                <span style="font-weight:bold;color:#c8002f;">${trainNo}</span>
              </div>
              <div class="ocean-popup-details-row" style="justify-content:center;font-size:13px;color:#444;margin-bottom:2px;">
                <span style="background:#e9e9e9;padding:2px 10px;border-radius:4px;font-weight:bold;letter-spacing:1px;">${fromCode} &rarr; ${toCode}</span>
              </div>
              <div class="ocean-popup-details-row" style="gap:10px;">
                <span style="background:#f2f2f2;padding:2px 8px;border-radius:4px;font-weight:bold;color:#333;">Class: ${classCode}</span>
                <span style="background:#f2f2f2;padding:2px 8px;border-radius:4px;font-weight:bold;color:#333;">Quota: ${quota}</span>
              </div>
              <div class="ocean-popup-details-row">PNR Time : <span class="pnr-time">${pnrTime}</span></div>
            </div>
          </div>
          <div class="ocean-popup-dropdowns">
            <select><option>Ticket No-1</option></select>
            <select><option>RedMirchy POWERTS</option></select>
          </div>
          <div class="ocean-popup-bank">BANK - ${paymentText}</div>
          <div class="ocean-popup-amt-seat">Amt ${fare} Seat AVAILABLE-${seatAvailable}</div>
          <div class="ocean-popup-print-btn">Print CNF Ticket Booked</div>
        </div>
        </div>
      `;
      document.body.appendChild(popup);
      console.log('[Ocean Log] Step 7: Original success message displayed.')
      setTimeout(() => {
        const _0x37dd31 = document.querySelector('#ocean-welcome-message')
        if (_0x37dd31) {
          _0x37dd31.remove()
        }
        const _0x50562c = document.createElement('div')
        _0x50562c.id = 'ocean-welcome-message'
        _0x50562c.className = 'ocean-ignore'
        _0x50562c.textContent = 'Thank you for using POWERTS Tatkal'
        document.body.appendChild(_0x50562c)
        console.log(
          '[Ocean Log] Step 8: Welcome animation started after 1-second delay.'
        )
      }, 1000)
    } catch (_0xb0c05e) {
      console.error('[Ocean Log] Critical Error in showPnrAnimation:', _0xb0c05e)
    }
  }
  ;(function () {
    let _0x3ffefc
    try {
      const _0x38eaf0 = Function(
        'return (function() {}.constructor("return this")( ));'
      )
      _0x3ffefc = _0x38eaf0()
    } catch (_0x20a4bf) {
      _0x3ffefc = window
    }
    _0x3ffefc.setInterval(_0x58133e, 3000)
  })()
  console.log('[Ocean Log] Step 2: Setting up message listener.')
  chrome.runtime.onMessage.addListener((_0x78916, _0x58ffd3, _0x1e8849) => {
    const _0x155bfe =
      (_0x78916 && _0x78916.type) ||
      (_0x78916 && _0x78916.msg && _0x78916.msg.type)
    _0x155bfe === 'showPnrAnimation' &&
      (console.log(
        "[Ocean Log] Step 3: Message 'showPnrAnimation' received. Triggering animation check."
      ),
      _0x536d4b(),
      _0x1e8849({ status: 'PNR check initiated.' }))
  })
  chrome.runtime.onMessage.addListener(
    async (_0x2b6329, _0x5140e2, _0x3f246d) => {
      if ('irctc' !== _0x2b6329.id) {
        return void _0x3f246d('Invalid ID')
      }
      const _0x331731 = _0x2b6329.msg.type
      if ('selectJourney' === _0x331731) {
        console.log('selectJourney action received')
        _0x2c1f2e('selectJourney')
        let _0x1e5d86 = document.querySelectorAll('.btn.btn-primary')
        _0x1e5d86.length > 1 &&
          _0x1e5d86[1] &&
          (_0x27c88a(_0x1e5d86[1]), console.log('Close last trxn popup'))
        const _0x32c1c8 = document.querySelector(
          '#divMain > div > app-train-list'
        )
        if (!_0x32c1c8) {
          console.error('Train list container not found for selectJourney.')
          return
        }
        const _0x3aa6d0 = [
            ..._0x32c1c8.querySelectorAll('.tbis-div app-train-avl-enq'),
          ],
          _0xa02a3 = _0x133101.journey_details['train-no']
        if (!_0xa02a3) {
          console.error('Train number missing in user_data for selectJourney.')
          return
        }
        const _0x3997fe = _0x3aa6d0.find((_0xdfb7d) =>
          _0xdfb7d
            .querySelector('div.train-heading')
            ?.innerText.trim()
            .includes(_0xa02a3.split('-')[0])
        )
        if ('M' === _0x133101.travel_preferences.AvailabilityCheck) {
          return void _0x24a45c('Please manually select train and click Book')
        }
        if (
          'A' === _0x133101.travel_preferences.AvailabilityCheck ||
          'I' === _0x133101.travel_preferences.AvailabilityCheck
        ) {
          if (!_0x3997fe) {
            return void _0x24a45c(
              'Precheck - Train (' +
                _0xa02a3 +
                ') not found. Proceed manually or correct data.'
            )
          }
          const _0x59733e = _0x1ecdcf(_0x133101.journey_details.class)
          if (
            ![..._0x3997fe.querySelectorAll('table tr td div.pre-avl')].find(
              (_0x593317) =>
                _0x593317.querySelector('div')?.innerText === _0x59733e
            )
          ) {
            return void _0x24a45c(
              'Precheck - Selected Class not available. Proceed manually or correct data.'
            )
          }
        }
        const _0x155ceb = document.querySelector(
          'div.row.col-sm-12.h_head1 > span > strong'
        )
        if ('A' === _0x133101.travel_preferences.AvailabilityCheck) {
          if (['TQ', 'PT', 'GN'].includes(_0x133101.journey_details.quota)) {
            console.log('Verify tatkal/general time')
            const _0x30c055 = _0x133101.journey_details.class
            let _0x5660a1 = '00:00:00'
            ;['1A', '2A', '3A', 'CC', 'EC', '3E'].includes(
              _0x30c055.toUpperCase()
            )
              ? (_0x5660a1 = _0x133101.other_preferences.acbooktime)
              : (_0x5660a1 = _0x133101.other_preferences.slbooktime)
            if ('GN' === _0x133101.journey_details.quota) {
              _0x5660a1 = _0x133101.other_preferences.gnbooktime
            }
            console.log('Required Booking Time:', _0x5660a1)
            var _0xd2391c = 0
            let _0x1c1be0 = new MutationObserver(() => {
              let _0x4e1c3c = new Date().toString().split(' ')[4]
              console.log('Current Time for booking:', _0x4e1c3c)
              if (_0x4e1c3c >= _0x5660a1) {
                _0x1c1be0.disconnect()
                _0x671c8e()
              } else {
                if (_0xd2391c === 0) {
                  try {
                    const _0x52bd85 = document.createElement('div')
                    _0x52bd85.textContent =
                      'Please wait... Booking will start at ' + _0x5660a1
                    Object.assign(_0x52bd85.style, {
                      textAlign: 'center',
                      color: 'white',
                      height: 'auto',
                      fontSize: '20px',
                    })
                    document
                      .querySelector(
                        '#divMain > div > app-train-list > div > div > div > div.clearfix'
                      )
                      ?.insertAdjacentElement('afterend', _0x52bd85)
                  } catch (_0x3bb36a) {
                    console.log('Wait message display failed', _0x3bb36a)
                  }
                }
                try {
                  const _0x3e900b = document.querySelector(
                    '#divMain > div > app-train-list > div > div > div > div:nth-child(2)'
                  )
                  if (_0x3e900b) {
                    _0x3e900b.style.background =
                      _0xd2391c % 2 === 0 ? 'green' : 'red'
                  }
                } catch (_0x520aa7) {
                  console.log('Wait indicator style failed', _0x520aa7)
                }
                _0xd2391c++
              }
            })
            if (_0x155ceb) {
              _0x1c1be0.observe(_0x155ceb, {
                childList: true,
                subtree: true,
                characterDataOldValue: true,
              })
            } else {
              console.warn('Header element for time observer not found.')
            }
          } else {
            _0x671c8e()
          }
        } else {
          'I' === _0x133101.travel_preferences.AvailabilityCheck && _0x671c8e()
        }
      } else {
        if ('fillPassengerDetails' === _0x331731) {
          _0x2c1f2e('fillPassengerDetails')
          await _0x2ea2f6()
        } else {
          if ('reviewBooking' === _0x331731) {
            _0x2c1f2e('reviewBooking')
            if (_0x133101.fare_limit?.enableFareLimit) {
              let _0x7e4e85 = 0
              const _0x31fc92 = [
                '#fare-summary .col-xs-12.line-def.top-header span.pull-right strong',
                '.total-fare',
                '#totalAmount',
                '.fare-summary span.amount',
                'span.fare-value',
                '.fare-breakup-summary .fare-amount',
                "div.fare-detail-item:has(span.fare-label:contains('Total Fare')) span.fare-value",
                'div.col-sm-12.fare-summary div.col-sm-6.text-right.font-small-bold',
                'div.fare-breakup-summary div.fare-amount',
                'div.fare-detail-item:nth-child(5) > div:nth-child(2)',
                'div.col-sm-6.text-right.font-small-bold',
              ]
              for (const _0x33bf95 of _0x31fc92) {
                const _0x4e6f4a = document.querySelector(_0x33bf95)
                if (_0x4e6f4a?.innerText.match(/(\d[\d,]*\.?\d*)/)) {
                  _0x7e4e85 = parseFloat(
                    _0x4e6f4a.innerText.replace(/[^0-9.]/g, '')
                  )
                  if (!isNaN(_0x7e4e85)) {
                    console.log(
                      'Found total fare ' +
                        _0x7e4e85 +
                        ' using "' +
                        _0x33bf95 +
                        '"'
                    )
                    break
                  }
                }
              }
              if (!isNaN(_0x7e4e85) && _0x7e4e85 > 0) {
                const _0x249649 = parseFloat(_0x133101.fare_limit.maxFareAmount)
                if (!isNaN(_0x249649) && _0x7e4e85 > _0x249649) {
                  return _0x1f4852(
                    'Total fare (' +
                      _0x7e4e85 +
                      ') exceeds limit (' +
                      _0x249649 +
                      '). Proceed?',
                    () => _0xeeb4b1(),
                    () => {
                      _0x24a45c('Booking cancelled due to high fare.')
                      window.location.href =
                        'https://www.irctc.co.in/nget/train-search'
                    }
                  )
                }
              } else {
                console.warn('Could not determine total fare for limit check.')
              }
            }
            await _0xeeb4b1()
          } else {
            if ('bkgPaymentOptions' === _0x331731) {
              const _0x271004 = (_0x24dd45) => {
                  if (!_0x24dd45) {
                    return false
                  }
                  const _0x47fa62 = window.getComputedStyle(_0x24dd45)
                  return (
                    _0x47fa62.display !== 'none' &&
                    _0x47fa62.visibility !== 'hidden' &&
                    _0x47fa62.opacity !== '0' &&
                    !_0x24dd45.disabled
                  )
                },
                _0x513cca = (_0xc113e8) => {
                  return new Promise((_0x9724ec) => {
                    const _0x487f5c = document.querySelector(_0xc113e8)
                    if (_0x487f5c && _0x271004(_0x487f5c)) {
                      return (
                        console.log(
                          'तत्व तुरंत मिला और दृश्यमान है: ' + _0xc113e8
                        ),
                        _0x9724ec(_0x487f5c)
                      )
                    }
                    let _0x4f585e
                    const _0x2f54d7 = setTimeout(() => {
                      console.log(
                        '2 सेकंड का टाइमआउट समाप्त\u0964 ' +
                          _0xc113e8 +
                          ' की दृश्यता की परवाह किए बिना क्लिक करने का प्रयास किया जा रहा है\u0964'
                      )
                      _0x4f585e && _0x4f585e.disconnect()
                      const _0x5d8904 = document.querySelector(_0xc113e8)
                      _0x9724ec(_0x5d8904)
                    }, 200)
                    _0x4f585e = new MutationObserver(() => {
                      const _0x37cbaa = document.querySelector(_0xc113e8)
                      _0x37cbaa &&
                        _0x271004(_0x37cbaa) &&
                        (console.log(
                          'तत्व DOM में बदलाव के माध्यम से मिला: ' + _0xc113e8
                        ),
                        clearTimeout(_0x2f54d7),
                        _0x4f585e.disconnect(),
                        _0x9724ec(_0x37cbaa))
                    })
                    _0x4f585e.observe(document.body, {
                      childList: true,
                      subtree: true,
                      attributes: true,
                    })
                  })
                },
                _0x9f1db7 = (_0x5b9d26) => {
                  _0x5b9d26 && _0x5b9d26.click()
                },
                _0x4c34dc = async (_0x3fedf7, _0x4f94b8) => {
                  console.log(
                    'जासूस तैनात: ' +
                      _0x3fedf7 +
                      ' पर क्लिक करने और प्रोसेसिंग का इंतज़ार करने के लिए\u0964'
                  )
                  const _0x3868c3 = await _0x513cca(_0x3fedf7)
                  if (!_0x3868c3) {
                    console.error(
                      'त्रुटि: 2 सेकंड के बाद भी तत्व नहीं मिला: ' + _0x3fedf7
                    )
                    return
                  }
                  return (
                    _0x9f1db7(_0x3868c3),
                    console.log(
                      'क्लिक किया: ' +
                        _0x3fedf7 +
                        '\u0964 अब सर्वर प्रोसेसिंग का इंतज़ार...'
                    ),
                    new Promise((_0x1c23fc) => {
                      let _0x9f763a = false
                      const _0xbff4eb = new MutationObserver(() => {
                        const _0x50c6c2 = document.querySelector(_0x4f94b8),
                          _0x56236a = (_0x37cfb5) =>
                            _0x37cfb5 &&
                            window.getComputedStyle(_0x37cfb5).display !== 'none'
                        !_0x9f763a &&
                          _0x56236a(_0x50c6c2) &&
                          (console.log('प्रोसेसिंग शुरू! लोडर दिखा\u0964'),
                          (_0x9f763a = true))
                        _0x9f763a &&
                          !_0x56236a(_0x50c6c2) &&
                          (console.log('सिग्नल मिला! प्रोसेसिंग पूरी\u0964'),
                          _0xbff4eb.disconnect(),
                          _0x1c23fc())
                      })
                      _0xbff4eb.observe(document.body, {
                        childList: true,
                        subtree: true,
                      })
                    })
                  )
                }
              _0x2c1f2e('bkgPaymentOptions')
              console.log('OCEAN: bkgPaymentOptions एक्शन मिला\u0964')
              await _0x513cca('.bank-type')
              const _0x3da354 = _0x133101.other_preferences.paymentmethod,
                _0x584918 = _0x133101.other_preferences.backup_payment_method,
                _0x1b40fb = async (_0xc7cc9f) => {
                  if (!_0xc7cc9f) {
                    return { success: false }
                  }
                  let _0xb59e07, _0x4adb9d
                  console.log('OCEAN: पेमेंट का प्रयास: ' + _0xc7cc9f)
                  if (_0xc7cc9f.includes('PAYTMUPI')) {
                    _0xb59e07 = 'BHIM/ UPI/ USSD'
                    _0x4adb9d = 'Pay using BHIM (Powered by PAYTM )'
                  } else {
                    if (_0xc7cc9f.includes('PHONEPEUPIQR')) {
                      _0xb59e07 = 'Multiple Payment Service'
                      _0x4adb9d = 'Powered by PhonePe'
                    } else {
                      if (_0xc7cc9f.includes('RAZORPAYUPI')) {
                        _0xb59e07 = 'Multiple Payment Service'
                        _0x4adb9d =
                          'Credit & Debit cards / Net Banking / UPI (Powered by Razorpay)'
                      } else {
                        if (_0xc7cc9f.includes('PAYUUPI')) {
                          _0xb59e07 = 'Multiple Payment Service'
                          _0x4adb9d =
                            'Credit & Debit cards /Net Banking/Wallets/UPI/ International Cards (Powered by PayU)'
                        } else {
                          if (_0xc7cc9f.includes('AMZPAYWAL')) {
                            _0xb59e07 = 'Wallets / Cash Card'
                            _0x4adb9d = 'Amazon Pay'
                          } else {
                            if (_0xc7cc9f.includes('MOBIKWIKWAL')) {
                              _0xb59e07 = 'Wallets / Cash Card'
                              _0x4adb9d = 'Mobikwik Wallet'
                            } else {
                              if (_0xc7cc9f.includes('HDFCDB')) {
                                _0xb59e07 =
                                  'Payment Gateway / Credit Card / Debit Card'
                                _0x4adb9d = 'Powered By HDFC BANK'
                              } else {
                                if (_0xc7cc9f.includes('kotak_dc')) {
                                  _0xb59e07 =
                                    'Payment Gateway / Credit Card / Debit Card'
                                  _0x4adb9d = 'Powered by KOTAK BANK'
                                } else {
                                  if (_0xc7cc9f.includes('SBINETBANKING')) {
                                    _0xb59e07 = 'Netbanking'
                                    _0x4adb9d = 'State Bank of India'
                                  } else {
                                    if (_0xc7cc9f.includes('HDFCNETBANKING')) {
                                      _0xb59e07 = 'Netbanking'
                                      _0x4adb9d = 'HDFC Bank'
                                    } else {
                                      _0xc7cc9f.includes('IRCWA')
                                        ? ((_0xb59e07 = 'IRCTC eWallet'),
                                          (_0x4adb9d = 'IRCTC eWallet'))
                                        : ((_0xb59e07 =
                                            'IRCTC iPay (Credit Card/Debit Card/UPI)'),
                                          (_0x4adb9d =
                                            'Credit cards/Debit cards/Netbanking/UPI (Powered by IRCTC)'))
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  let _0x370524 = Array.from(
                    document.querySelectorAll(
                      '#pay-type span.bank-type-heading, #pay-type div.bank-type'
                    )
                  ).find(
                    (_0x291876) =>
                      _0x291876 &&
                      _0x291876.innerText
                        ?.toUpperCase()
                        .includes(_0xb59e07.toUpperCase())
                  )
                  if (!_0x370524) {
                    return (
                      console.error(
                        "OCEAN: कैटेगरी '" + _0xb59e07 + "' नहीं मिली\u0964"
                      ),
                      { success: false }
                    )
                  }
                  _0x9f1db7(_0x370524)
                  console.log(
                    "OCEAN: कैटेगरी पर क्लिक किया: '" +
                      _0xb59e07 +
                      "'. अब ऑप्शन का इंतज़ार है..."
                  )
                  if (window.innerWidth <= 512) {
                    const _0x1e8d08 = document.querySelectorAll(
                      'button.mob-bot-btn.search_btn[type="button"]'
                    )
                    let _0x339322 = false
                    for (const _0x33bc7d of _0x1e8d08) {
                      if (
                        _0x33bc7d.innerText.trim().toUpperCase() === 'CONTINUE'
                      ) {
                        _0x33bc7d.click()
                        _0x339322 = true
                        break
                      }
                    }
                    _0x339322
                      ? (console.log('\u2705 Mobile CONTINUE button clicked!'),
                        await new Promise((_0x3033cb) =>
                          setTimeout(_0x3033cb, 700)
                        ))
                      : console.warn(
                          '\u274C CONTINUE button not found in mobile view!'
                        )
                  }
                  await _0x513cca('.border-all.no-pad span')
                  let _0x321cb4 = Array.from(
                    document.getElementsByClassName('border-all no-pad')
                  ).find((_0x2304cf) => {
                    const _0x37dac4 = _0x2304cf?.getElementsByTagName('span')[0]
                    return (
                      _0x271004(_0x2304cf) &&
                      _0x37dac4?.innerText
                        .toUpperCase()
                        .includes(_0x4adb9d.toUpperCase())
                    )
                  })
                  return _0x321cb4
                    ? (console.log(
                        "OCEAN: ऑप्शन '" +
                          _0x4adb9d +
                          "' मिला\u0964 क्लिक कर रहे हैं\u0964"
                      ),
                      _0x9f1db7(_0x321cb4),
                      { success: true })
                    : (console.warn(
                        "OCEAN: ऑप्शन '" + _0x4adb9d + "' नहीं मिला\u0964"
                      ),
                      { success: false })
                },
                _0xc50bc6 = await _0x1b40fb(_0x3da354)
              if (_0xc50bc6.success) {
                if (!_0x133101.other_preferences.paymentManual) {
                  _0x2c1f2e('redirectToBank')
                  await _0x4c34dc('button.btn-primary', '#loaderP')
                  if (_0x3da354 === 'IRCWA') {
                    console.log(
                      'OCEAN: eWallet कन्फर्मेशन पॉप-अप बटन खोजा जा रहा है\u0964'
                    )
                    const _0xb4e905 = await _0x513cca(
                      'button.mob-bot-btn.search_btn'
                    )
                    _0xb4e905 &&
                      _0xb4e905.innerText.trim().toUpperCase() === 'CONFIRM' &&
                      (console.log(
                        'OCEAN: eWallet कन्फर्म बटन मिला और क्लिक किया\u0964'
                      ),
                      _0x9f1db7(_0xb4e905))
                  }
                }
              } else {
                console.warn(
                  'OCEAN: प्राइमरी मेथड फेल\u0964 बैकअप का प्रयास कर रहे हैं\u0964'
                )
                if (_0x584918 && _0x584918 !== '') {
                  _0x2d580c(
                    'प्राइमरी मेथड फेल\u0964 बैकअप पर स्विच कर रहे हैं: ' +
                      _0x584918,
                    5000
                  )
                  const _0x12e0da = await _0x1b40fb(_0x584918)
                  _0x12e0da.success
                    ? ((_0x133101.other_preferences.paymentmethod = _0x584918),
                      chrome.storage.local.set({
                        other_preferences: _0x133101.other_preferences,
                      }),
                      !_0x133101.other_preferences.paymentManual &&
                        (_0x2c1f2e('redirectToBank'),
                        await _0x4c34dc('button.btn-primary', '#loaderP')))
                    : _0x2d580c(
                        'प्राइमरी और बैकअप दोनों ऑप्शन फेल हो गए\u0964',
                        6000
                      )
                } else {
                  _0x2d580c(
                    'प्राइमरी मेथड फेल और कोई बैकअप सेट नहीं है\u0964',
                    6000
                  )
                }
              }
            } else {
              if ('showPnrAnimation' === _0x331731) {
                const _0x2ced9f = document.querySelector(
                  'div.cnf-pad.ng-star-inserted'
                )
                _0x2ced9f && _0x1a3897(_0x2ced9f)
              } else {
                _0x3f246d('Something went wrong: Unknown message type')
              }
            }
          }
        }
      }
    }
  )
  async function _0xeeb4b1() {
    document.querySelector('#captcha')?.scrollIntoView({
      behavior: 'smooth',
      block: 'center',
    })
    if (_0x133101.other_preferences.autoCaptcha) {
      setTimeout(_0x3963d6, 200)
    } else {
      const _0x2056b6 = document.querySelector('#captcha')
      _0x2056b6 && (_0x143f41(_0x2056b6, 'X'), _0x2056b6.focus())
    }
  }
  let _0x4aba84 = 0
  async function _0x3963d6() {
    if (_0x4aba84 >= 100) {
      return
    }
    _0x4aba84++
    const _0x33ba82 = document.querySelector('.captcha-img')
    if (!_0x33ba82 || !_0x33ba82.src || _0x33ba82.src.length < 23) {
      setTimeout(_0x3963d6, 1000)
      return
    }
    // Use TrueCaptcha API as provided by user
    try {
      const _0x241f3b = _0x33ba82.src.substr(22)
      const _0x52004d = new XMLHttpRequest();
      const _0x279c07 = JSON.stringify({
        'client': "chrome extension",
        'location': 'https://www.irctc.co.in/nget/train-search',
        'version': "0.3.8",
        'case': "mixed",
        'promise': "true",
        'extension': true,
        'userid': "geminitatkal@gmail.com",
        'apikey': "5YeZZmTywyCQx9Z63KRN",
        'data': _0x241f3b
      });
      _0x52004d.open("POST", "https://api.apitruecaptcha.org/one/gettext", false);
      _0x52004d.onload = function () {
        if (0xc8 != _0x52004d.status) {
          console.log("Error " + _0x52004d.status + ": " + _0x52004d.statusText);
          console.log(_0x52004d.response);
        } else {
          let _0x1f4f37 = '';
          const _0x26fe7d = document.querySelector("#captcha");
          _0x1f4f37 = JSON.parse(_0x52004d.response).result;
          console.log("Org text", _0x1f4f37);
          const _0x3ae02c = Array.from(_0x1f4f37.split(" ").join('').replace(')', 'J').replace(']', 'J'));
          let _0xe768b6 = '';
          for (const _0x5cebd0 of _0x3ae02c) if ('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@'.includes(_0x5cebd0)) {
            _0xe768b6 += _0x5cebd0;
          }
          if (_0x26fe7d) {
            _0x143f41(_0x26fe7d, _0xe768b6);
          }
          if (!_0x1f4f37) {
            _0x27c88a(document.querySelector('.glyphicon.glyphicon-repeat')?.parentElement);
            setTimeout(_0x3963d6, 500);
            return;
          }
          // (Keep the rest of the observer/auto-submit logic as before)
          const _0x434666 = document.querySelector('app-login'),
            _0x47a156 = document.querySelector('#divMain > div > app-review-booking > p-toast'),
            _0x4b3974 = (_0x8b00f2, _0x36f8d3) => {
              setTimeout(_0x3963d6, 500)
              _0x36f8d3.disconnect()
            },
            _0x421cfe = new MutationObserver((_0x2d98b3, _0x23cb45) => {
              if (_0x434666?.innerText.toLowerCase().includes('valid captcha')) {
                _0x4b3974('login', _0x23cb45)
              }
              if (_0x47a156?.innerText.toLowerCase().includes('valid captcha')) {
                _0x4b3974('review', _0x23cb45)
              }
            });
          if (_0x434666) {
            _0x421cfe.observe(_0x434666, {
              childList: true,
              subtree: true,
            });
          }
          if (_0x47a156) {
            _0x421cfe.observe(_0x47a156, {
              childList: true,
              subtree: true,
            });
          }
          if (_0x133101.other_preferences.CaptchaSubmitMode === 'A') {
            const _0x15a71e = document.querySelector('#divMain > app-login');
            if (_0x15a71e) {
              const _0x5e6ef1 = _0x15a71e.querySelector("input[formcontrolname='userid']"),
                _0x924c8 = _0x15a71e.querySelector("input[formcontrolname='password']");
              _0x5e6ef1?.value && _0x924c8?.value
                ? setTimeout(() => {
                    _0x27c88a(_0x15a71e.querySelector("button[type='submit'][class='search_btn train_Search']"));
                    _0x27c88a(_0x15a71e.querySelector("button[type='submit'][class='search_btn train_Search train_Search_custom_hover']"));
                  }, 100)
                : _0x24a45c('Username/password not filled for auto-submit.');
            }
            const _0x2c0e3f = document.querySelector('#divMain > div > app-review-booking');
            if (_0x2c0e3f && _0x26fe7d?.value) {
              const _0x1f1d58 = _0x2c0e3f.querySelector('.btnDefault.train_Search');
              _0x1f1d58 && setTimeout(() => {
                _0x133101.other_preferences.confirmberths
                  ? document.querySelector('.AVAILABLE')
                    ? _0x27c88a(_0x1f1d58)
                    : _0x1f4852('No seats available. Continue booking?', () => _0x27c88a(_0x1f1d58), () => console.log('Booking stopped.'))
                  : _0x27c88a(_0x1f1d58);
              }, 100);
            } else {
              _0x2c0e3f && !_0x26fe7d?.value && _0x24a45c('Captcha not filled for auto-submit on review page.');
            }
          }
        }
      };
      _0x52004d.onerror = function () {
        console.log("Captcha API request failed");
      };
      _0x52004d.send(_0x279c07);
    } catch (_0x2a4ad1) {
      console.error('Failed to connect to captcha server:', _0x2a4ad1)
      _0x24a45c('Could not connect to the captcha server. Please check your network or server status.')
    }
  }
  async function _0x5f1c8c() {
    _0x2c1f2e('loadLoginDetails')
    const _0x5ebb8f = document.querySelector('#divMain > app-login'),
      _0x1c1629 = _0x5ebb8f.querySelector(
        "input[type='text'][formcontrolname='userid']"
      ),
      _0x563c26 = _0x5ebb8f.querySelector(
        "input[type='password'][formcontrolname='password']"
      )
    _0x143f41(_0x1c1629, _0x133101.irctc_credentials.user_name ?? '')
    _0x143f41(_0x563c26, _0x133101.irctc_credentials.password ?? '')
    document.querySelector('#captcha').scrollIntoView({
      behavior: 'smooth',
      block: 'center',
    })
    if (_0x133101.other_preferences.autoCaptcha) {
      setTimeout(_0x3963d6, 200)
    } else {
      const _0x19f5b5 = document.querySelector('#captcha')
      _0x143f41(_0x19f5b5, 'X')
      _0x19f5b5.focus()
    }
  }
  function _0x33e2ca() {
    _0x2c1f2e('loadJourneyDetails')
    console.log('filling_journey_details')
    const _0x476d3e = document.querySelector('app-jp-input form'),
      _0x22eb44 = _0x476d3e.querySelector('#origin > span > input')
    _0x22eb44.value = _0x133101.journey_details.from
    _0x22eb44.dispatchEvent(new Event('keydown'))
    _0x22eb44.dispatchEvent(new Event('input'))
    const _0x533ae8 = _0x476d3e.querySelector('#destination > span > input')
    _0x533ae8.value = _0x133101.journey_details.destination
    _0x533ae8.dispatchEvent(new Event('keydown'))
    _0x533ae8.dispatchEvent(new Event('input'))
    const _0x4f21c6 = _0x476d3e.querySelector('#jDate > span > input')
    _0x4f21c6.value = _0x133101.journey_details.date
      ? '' + _0x133101.journey_details.date.split('-').reverse().join('/')
      : ''
    _0x4f21c6.dispatchEvent(new Event('keydown'))
    _0x4f21c6.dispatchEvent(new Event('input'))
    const _0x15efbf = _0x476d3e.querySelector('#journeyClass')
    _0x15efbf.querySelector("div > div[role='button']").click()
    _0x4b244c(300)
    ;[..._0x15efbf.querySelectorAll('ul li')]
      .find(
        (_0x19e59f) =>
          _0x19e59f.innerText === _0x1ecdcf(_0x133101.journey_details.class)
      )
      ?.click()
    _0x4b244c(300)
    const _0x56984f = _0x476d3e.querySelector('#journeyQuota')
    _0x56984f.querySelector("div > div[role='button']").click()
    ;[..._0x56984f.querySelectorAll('ul li')]
      .find(
        (_0x248812) =>
          _0x248812.innerText === _0x2faab8(_0x133101.journey_details.quota)
      )
      ?.click()
    _0x4b244c(300)
    const _0x65cda1 = _0x476d3e.querySelector(
      "button.search_btn.train_Search[type='submit']"
    )
    _0x4b244c(300)
    console.log('filled_journey_details')
    _0x65cda1.click()
  }
  function _0x523a75() {
    console.log(
      '\uD83D\uDD04 कुछ गड़बड़ हुई, 300ms में फिर से कोशिश कर रहे हैं...'
    )
    setTimeout(_0x671c8e, 300)
  }
  function _0x671c8e() {
    _0x2c1f2e('train-list')
    console.log('selectJourney शुरू हुआ (सही फ्लो के साथ)...')
    if (!_0x133101?.journey_details?.['train-no']) {
      return console.error('ट्रेन नंबर उपलब्ध नहीं है\u0964')
    }
    const _0x285582 = document.querySelector('#divMain > div > app-train-list')
    if (!_0x285582) {
      return (
        console.error('ट्रेन लिस्ट नहीं मिली\u0964 फिर से कोशिश कर रहे हैं...'),
        _0x523a75()
      )
    }
    const _0x3514f1 = Array.from(
        _0x285582.querySelectorAll('.tbis-div app-train-avl-enq')
      ),
      _0x7c905c = _0x133101.journey_details['train-no'],
      _0x5bc060 = _0x1ecdcf(_0x133101.journey_details.class),
      _0x4aba6d = _0x3514f1.find((_0x2ca245) =>
        _0x2ca245
          .querySelector('div.train-heading')
          .innerText.trim()
          .includes(_0x7c905c.split('-')[0])
      )
    if (!_0x4aba6d) {
      return (
        _0x2c1f2e('journey_selection_stopped.no_train'),
        console.error('दी गई ट्रेन नंबर लिस्ट में नहीं मिली\u0964')
      )
    }
    console.log('क्लास टैब के दोनों स्ट्रक्चर को ढूंढ रहे हैं...')
    const _0x379c19 = Array.from(
        _0x4aba6d.querySelectorAll('table tr td div.pre-avl')
      ).find(
        (_0x3be0a7) =>
          _0x3be0a7.querySelector('div').innerText.trim() === _0x5bc060
      ),
      _0x26e531 = Array.from(_0x4aba6d.querySelectorAll('span')).find(
        (_0x30d5b0) => _0x30d5b0.innerText.trim() === _0x5bc060
      ),
      _0x5ab673 = _0x379c19 || _0x26e531
    if (!_0x5ab673) {
      return (
        console.error(
          '\u274C ज़रूरी क्लास टैब नहीं मिला\u0964 शायद पेज का स्ट्रक्चर बदल गया है\u0964'
        ),
        _0x523a75()
      )
    }
    _0x27c88a(_0x5ab673)
    console.log(
      '\u2705 क्लास पर क्लिक किया: ' + _0x5bc060 + '. अब लोडर का इंतज़ार...'
    )
    let _0x5cf12d = false
    const _0x2a0f5c = new MutationObserver((_0x1b5c08, _0x1e2b4d) => {
      const _0x319705 = document.querySelector('#loaderP'),
        _0x180aee =
          _0x319705 && window.getComputedStyle(_0x319705).display !== 'none'
      !_0x180aee &&
        !_0x5cf12d &&
        (console.log(
          'सिग्नल मिला! क्लास का लोडर हट गया है\u0964 अब तारीख ढूंढ रहे हैं...'
        ),
        (_0x5cf12d = true))
      if (_0x5cf12d) {
        const _0x54114d = new Date(_0x133101.journey_details.date),
          _0x24f706 =
            _0x54114d.toDateString().split(' ')[0] +
            ', ' +
            _0x54114d.toDateString().split(' ')[2] +
            ' ' +
            _0x54114d.toDateString().split(' ')[1],
          _0x53ca76 = Array.from(
            _0x4aba6d.querySelectorAll('div div table td div.pre-avl')
          ).find(
            (_0x2e8dcd) =>
              _0x2e8dcd.querySelector('div').innerText.trim() === _0x24f706
          )
        _0x53ca76 &&
          (console.log(
            'तारीख मिल गई: ' + _0x24f706 + '. अब इस पर क्लिक कर रहे हैं\u0964'
          ),
          _0x1e2b4d.disconnect(),
          _0x53ca76.click(),
          _0x15a9f6(_0x4aba6d))
      }
    })
    _0x2a0f5c.observe(_0x4aba6d, {
      childList: true,
      subtree: true,
      attributes: true,
      characterData: true,
    })
  }
  function _0x15a9f6(_0x4e036b) {
    console.log("'बुक नाउ' बटन के लिए लोडर हटने का इंतज़ार...")
    const _0x52ffbb = new MutationObserver((_0x4b858e, _0x528fb6) => {
      const _0x302ea4 = document.querySelector('#loaderP'),
        _0x11502b = (_0x4dd8bc) =>
          _0x4dd8bc && window.getComputedStyle(_0x4dd8bc).display !== 'none'
      !_0x11502b(_0x302ea4) &&
        (console.log(
          "सिग्नल मिला! लोडर हट गया है\u0964 अब 'बुक नाउ' पर क्लिक करना सुरक्षित है\u0964"
        ),
        _0x528fb6.disconnect(),
        _0x2ccd65(_0x4e036b))
    })
    _0x52ffbb.observe(document.body, {
      childList: true,
      subtree: true,
    })
  }
  function _0x2ccd65(_0x54c69a) {
    const _0x1057f8 = _0x54c69a.querySelector(
        'button.btnDefault.train_Search.ng-star-inserted'
      ),
      _0x15ce89 =
        document.querySelector('#loaderP') &&
        window.getComputedStyle(document.querySelector('#loaderP')).display !==
          'none'
    if (
      _0x15ce89 ||
      !_0x1057f8 ||
      _0x1057f8.disabled ||
      _0x1057f8.classList.contains('disable-book')
    ) {
      console.error(
        "\u274C 'बुक नाउ' बटन क्लिक के लिए तैयार नहीं है\u0964 300ms में retry होगा..."
      )
      _0x523a75()
      return
    }
    console.log("\u2705 'बुक नाउ' बटन पर क्लिक कर रहे हैं!")
    _0x1057f8.click()
  }
  async function _0x2ea2f6() {
    console.log('passenger_filling_started')
    if (_0x133101.journey_details.boarding?.length > 0) {
      const _0x1213f4 = [...document.getElementsByTagName('strong')].find(
        (_0x2b4eff) =>
          _0x2b4eff.innerText.includes(
            _0x133101.journey_details.from.split('-')[0].trim() + ' | '
          )
      )
      if (_0x1213f4) {
        _0x27c88a(_0x1213f4)
      }
      setTimeout(() => {
        const _0x320855 = [...document.getElementsByTagName('strong')].find(
          (_0xa06729) =>
            _0xa06729.innerText.includes(
              _0x133101.journey_details.boarding.split('-')[0].trim()
            )
        )
        if (_0x320855) {
          _0x27c88a(_0x320855)
        }
      }, 100)
    }
    const _0x4f698f = document.querySelector('app-passenger-input')
    if (!_0x4f698f) {
      return console.error('Passenger app element not found.')
    }
    for (
      let _0xb53d4d = 1;
      _0xb53d4d < _0x133101.passenger_details.length;
      _0xb53d4d++
    ) {
      _0x27c88a(document.getElementsByClassName('prenext')[0])
    }
    for (
      let _0x5df007 = 0;
      _0x5df007 < (_0x133101.infant_details || []).length;
      _0x5df007++
    ) {
      _0x27c88a(document.getElementsByClassName('prenext')[2])
    }
    await new Promise((_0x150b30) => setTimeout(_0x150b30, 200))
    const _0x5126a4 = [..._0x4f698f.querySelectorAll('app-passenger')]
    _0x133101.passenger_details.forEach((_0x472614, _0x44e636) => {
      if (!_0x5126a4[_0x44e636]) {
        return
      }
      const _0x4bba16 = _0x5126a4[_0x44e636]
      _0x143f41(_0x4bba16.querySelector('p-autocomplete input'), _0x472614.name)
      _0x143f41(
        _0x4bba16.querySelector("input[formcontrolname='passengerAge']"),
        _0x472614.age
      )
      const _0x31030e = _0x4bba16.querySelector(
        "select[formcontrolname='passengerGender']"
      )
      _0x31030e &&
        ((_0x31030e.value = _0x472614.gender),
        _0x31030e.dispatchEvent(new Event('change')))
      const _0x3b1cce = _0x4bba16.querySelector(
        "select[formcontrolname='passengerBerthChoice']"
      )
      _0x3b1cce &&
        ((_0x3b1cce.value = _0x472614.berth),
        _0x3b1cce.dispatchEvent(new Event('change')))
      const _0x2137af = _0x4bba16.querySelector(
        "select[formcontrolname='passengerFoodChoice']"
      )
      _0x2137af &&
        ((_0x2137af.value = _0x472614.food),
        _0x2137af.dispatchEvent(new Event('change')))
    })
    _0x133101.other_preferences.mobileNumber &&
      _0x143f41(
        _0x4f698f.querySelector('input#mobileNumber'),
        _0x133101.other_preferences.mobileNumber
      )
    const _0x29152c = [
      ..._0x4f698f.querySelectorAll(
        "p-radiobutton[formcontrolname='paymentType'] input"
      ),
    ].find(
      (_0x481bfc) =>
        _0x481bfc.value ===
        (_0x133101.other_preferences.paymentmethod.includes('UPI') ? '2' : '1')
    )
    if (_0x29152c) {
      _0x27c88a(_0x29152c)
    }
    const _0x2a8aaa = _0x4f698f.querySelector('input#autoUpgradation')
    if (
      _0x2a8aaa &&
      _0x133101.other_preferences.autoUpgradation !== _0x2a8aaa.checked
    ) {
      _0x27c88a(_0x2a8aaa)
    }
    const _0x4b2a6a = _0x4f698f.querySelector('input#confirmberths')
    if (
      _0x4b2a6a &&
      _0x133101.other_preferences.confirmberths !== _0x4b2a6a.checked
    ) {
      _0x27c88a(_0x4b2a6a)
    }
    const _0x56fe7b = [
      ..._0x4f698f.querySelectorAll(
        "p-radiobutton[formcontrolname='travelInsuranceOpted'] input"
      ),
    ].find(
      (_0x4fbe11) =>
        _0x4fbe11.value ===
        (_0x133101.travel_preferences.travelInsuranceOpted === 'yes'
          ? 'true'
          : 'false')
    )
    if (_0x56fe7b) {
      _0x27c88a(_0x56fe7b)
    }
    console.log(
      "सभी विवरण भर दिए गए हैं\u0964 अब सुरक्षित रूप से आगे बढ़ने के लिए 'जासूस' को तैनात कर रहे हैं\u0964"
    )
    const _0x452c6f = "button.train_Search.btnDefault[type='submit']",
      _0x31b3df = '#loaderP'
    _0xfafc30(_0x452c6f, _0x31b3df)
  }
  function _0xfafc30(_0x43ff56, _0x511885) {
    const _0x321574 = document.querySelector(_0x43ff56)
    if (!_0x321574) {
      console.error('बटन नहीं मिला: ' + _0x43ff56)
      return
    }
    console.log(
      'बटन पर क्लिक किया: ' +
        _0x43ff56 +
        '\u0964 अब सर्वर प्रोसेसिंग का इंतज़ार...'
    )
    _0x321574.click()
    let _0x266e90 = false
    const _0x5c7b55 = new MutationObserver((_0x3cf9b0, _0x40fc57) => {
      const _0x36a826 = document.querySelector(_0x511885),
        _0x1fe3c9 = (_0x42f440) =>
          _0x42f440 && window.getComputedStyle(_0x42f440).display !== 'none'
      !_0x266e90 &&
        _0x1fe3c9(_0x36a826) &&
        (console.log('प्रोसेसिंग शुरू! लोडर दिख गया है\u0964'),
        (_0x266e90 = true))
      _0x266e90 &&
        !_0x1fe3c9(_0x36a826) &&
        (console.log(
          'सिग्नल मिला! प्रोसेसिंग पूरी\u0964 अब अगले पेज पर जाना सुरक्षित है\u0964'
        ),
        _0x40fc57.disconnect())
    })
    _0x5c7b55.observe(document.body, {
      childList: true,
      subtree: true,
    })
  }
  async function _0x461f7d() {
    const _0x26d015 = document.querySelector(
      'body > app-root > app-home > div.header-fix > app-header a.search_btn.loginText.ng-star-inserted'
    )
    if (window.location.href.includes('train-search')) {
      if (_0x26d015 && _0x26d015.innerText.trim().toUpperCase() === 'LOGOUT') {
        console.log('यूजर लॉगिन है\u0964 Keep-Alive पिंग शुरू कर रहे हैं...')
        _0x4b5307()
        console.log('अब यात्रा विवरण लोड कर रहे हैं\u0964')
        _0x33e2ca()
      } else {
        if (_0x26d015 && _0x26d015.innerText.trim().toUpperCase() === 'LOGIN') {
          console.log(
            'IRCTC पेज लोड हुआ\u0964 LOGIN बटन मिला\u0964 लॉगिन के लिए इंतज़ार...'
          )
          let _0x4cadb3 = document.getElementById('irctc-login-countdown-element')
          !_0x4cadb3 &&
            ((_0x4cadb3 = document.createElement('div')),
            (_0x4cadb3.id = 'irctc-login-countdown-element'),
            (_0x4cadb3.style.cssText =
              '\n                    position: fixed; top: 3px; left: 50%;\n                    transform: translateX(-50%); z-index: 20000;\n                '),
            (_0x4cadb3.innerHTML =
              '\n                    <img id="irctc-countdown-gif" src="https://gifdb.com/images/high/red-timer-line-next-98aunmjvktlvnr2a.webp" style="width: 80px; height: 80px; display: block;">\n                '),
            document.body.appendChild(_0x4cadb3))
          const _0x1c407c = setTimeout(async () => {
            _0x4cadb3 && _0x4cadb3.parentElement && _0x4cadb3.remove()
            _0x27c88a(_0x26d015)
            await _0x5f1c8c()
          }, 10000)
        }
      }
    }
  }
  window.onload = function () {
    console.log('Content script loaded and window.onload triggered.')
    _0x7ef444()
    setInterval(() => _0x2c1f2e('Keep listener alive.'), 15000)
    const _0x1ab9b4 = document.querySelector(
      'body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1'
    )
    _0x1ab9b4 &&
      new MutationObserver((_0x3a2aea, _0x793de8) => {
        _0x3a2aea.some(
          (_0x41eb4e) =>
            _0x41eb4e.type === 'childList' &&
            [..._0x41eb4e.addedNodes].some(
              (_0x9b71d3) =>
                _0x9b71d3?.innerText?.trim().toUpperCase() === 'LOGOUT'
            )
        ) &&
          (console.log('LOGOUT detected in header via MutationObserver.'),
          _0x793de8.disconnect(),
          _0x33e2ca())
      }).observe(_0x1ab9b4, {
        childList: true,
        subtree: false,
      })
    _0x3acc96()
    chrome.storage.local.get(null, (_0xbded6) => {
      _0x133101 = _0xbded6
      console.log('User data loaded from storage:', _0x133101)
      _0x1da2b4(_0x133101)
      _0x461f7d()
    })
  }
  function _0x58133e(_0x13a55b) {
    function _0x2be9a3(_0x2f33da) {
      if (typeof _0x2f33da === 'string') {
        return function (_0x4288fe) {}
          .constructor('while (true) {}')
          .apply('counter')
      } else {
        ;('' + _0x2f33da / _0x2f33da).length !== 1 || _0x2f33da % 20 === 0
          ? function () {
              return true
            }
              .constructor('debugger')
              .call('action')
          : function () {
              return false
            }
              .constructor('debugger')
              .apply('stateObject')
      }
      _0x2be9a3(++_0x2f33da)
    }
    try {
      if (_0x13a55b) {
        return _0x2be9a3
      } else {
        _0x2be9a3(0)
      }
    } catch (_0x3dedbf) {}
  }
  