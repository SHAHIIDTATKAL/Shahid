<?php
// login.php - Master Panel Login Page
session_start();

// Brute force protection: Limit login attempts
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
}
if (!isset($_SESSION['last_login_attempt'])) {
    $_SESSION['last_login_attempt'] = time();
}
if ($_SESSION['login_attempts'] >= 5 && (time() - $_SESSION['last_login_attempt']) < 900) { // 15 min lock
    die('<div class="error-message">Too many failed login attempts. Please try again after 15 minutes.</div>');
}

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Check if the user is already logged in, if yes then redirect to their respective panel
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    switch ($_SESSION['account_type']) {
        case 'Master':
            header("location: Master.php");
            break;
        case 'Admin':
            header("location: Admin.php");
            break;
        case 'Super':
            header("location: Super.php");
            break;
        default:
            header("location: welcome.php");
            break;
    }
    exit;
}

require_once 'config.php';

$username = $password = $account_type = "";
$username_err = $password_err = $login_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('<div class="error-message">Invalid request. Please refresh the page and try again.</div>');
    }
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter your username.";
    } else {
        $username = trim($_POST["username"]);
    }
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }
    $account_type = $_POST["account_type"] ?? '';
    if (empty($username_err) && empty($password_err)) {
        $sql = "SELECT id, username, password, account_type FROM users WHERE username = ? AND account_type = ?";
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_account_type);
            $param_username = $username;
            $param_account_type = $account_type;
            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);
                if (mysqli_stmt_num_rows($stmt) == 1) {
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password, $fetched_account_type);
                    if (mysqli_stmt_fetch($stmt)) {
                        if (password_verify($password, $hashed_password)) {
                            $_SESSION['login_attempts'] = 0;
                            session_start();
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;
                            $_SESSION["account_type"] = $fetched_account_type;
                            switch ($fetched_account_type) {
                                case 'Master':
                                    header("location: Master.php");
                                    break;
                                case 'Admin':
                                    header("location: Admin.php");
                                    break;
                                case 'Super':
                                    header("location: Super.php");
                                    break;
                                default:
                                    header("location: welcome.php");
                                    break;
                            }
                            exit;
                        } else {
                            $login_err = "Invalid username or password.";
                            $_SESSION['login_attempts'] += 1;
                            $_SESSION['last_login_attempt'] = time();
                        }
                    }
                } else {
                    $login_err = "Invalid username or password.";
                    $_SESSION['login_attempts'] += 1;
                    $_SESSION['last_login_attempt'] = time();
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            mysqli_stmt_close($stmt);
        }
    }
    mysqli_close($link);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rajbull Login</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
        body {
            font-family: 'Inter', 'Segoe UI', 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            background: #101415;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        #vanta-background {
            position: absolute;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            z-index: 0;
        }
        .ext-card {
            position: relative;
            z-index: 1;
            background: rgba(16, 20, 21, 0.92);
            border-radius: 18px;
            box-shadow: 0 8px 32px rgba(0,255,90,0.10), 0 1.5px 6px rgba(0,255,90,0.08);
            padding: 32px 28px 22px 28px;
            width: 100%;
            max-width: 340px;
            display: flex;
            flex-direction: column;
            align-items: center;
            animation: fadeInScale 0.6s cubic-bezier(.4,1.4,.6,1) forwards;
            border-top: 2px solid #39ff14;
            border: 1.5px solid #39ff14;
            backdrop-filter: blur(6px);
            -webkit-backdrop-filter: blur(6px);
        }
        .ext-label {
            color: #39ff14;
            font-size: 1em;
            font-weight: 600;
            margin-bottom: 2px;
            letter-spacing: 0.2px;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        @keyframes fadeInScale {
            from { opacity: 0; transform: scale(0.92); }
            to { opacity: 1; transform: scale(1); }
        }
        .ext-logo {
            width: 64px;
            height: 64px;
            margin-bottom: 10px;
        }
        .ext-logo img {
            width: 100%;
            height: 100%;
            border-radius: 12px;
            box-shadow: 0 2px 8px #39ff14;
            border: 2px solid #39ff14;
            background: #101415;
        }
        .ext-title {
            font-size: 1.45em;
            font-weight: 700;
            color: #39ff14;
            margin-bottom: 18px;
            letter-spacing: 0.5px;
            text-align: center;
            text-shadow: 0 2px 8px #39ff14;
        }
        .ext-form {
            width: 100%;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .ext-group {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .ext-group input,
        .ext-group select {
            padding: 10px 13px;
            border: 1.5px solid #39ff14;
            border-radius: 7px;
            font-size: 1em;
            font-family: inherit;
            background: #181f1b;
            color: #39ff14;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .ext-group input:focus,
        .ext-group select:focus {
            border-color: #39ff14;
            box-shadow: 0 0 0 2px #39ff14;
            outline: none;
        }
        .error-message {
            color: #ff4d4f;
            font-size: 0.92em;
            margin-top: 2px;
            min-height: 18px;
        }
        .ext-btn {
            display: block;
            width: 100%;
            padding: 11px 0;
            border: none;
            border-radius: 7px;
            font-size: 1.08em;
            font-weight: 600;
            background: linear-gradient(90deg, #39ff14 60%, #1aeb3b 100%);
            color: #101415;
            margin-top: 8px;
            margin-bottom: 0;
            cursor: pointer;
            box-shadow: 0 2px 8px #39ff14;
            transition: background 0.2s, transform 0.15s;
            text-decoration: none;
            text-align: center;
        }
        .ext-btn:hover {
            background: linear-gradient(90deg, #1aeb3b 60%, #39ff14 100%);
            color: #fff;
            transform: translateY(-1.5px) scale(1.01);
        }
        .ext-login {
            margin-bottom: 6px;
        }
        .ext-actions {
            width: 100%;
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-top: 10px;
            margin-bottom: 6px;
        }
        .ext-footer {
            margin-top: 10px;
            font-size: 0.93em;
            color: #39ff14;
            text-align: center;
            letter-spacing: 0.2px;
            text-shadow: 0 1px 2px #101415;
        }
        @media (max-width: 400px) {
            .ext-card {
                padding: 18px 4vw 12px 4vw;
                max-width: 98vw;
            }
        }
    </style>
</head>
<body>
    <div id="vanta-background"></div>
    <div class="ext-card">
        <div class="ext-logo">
            <img src="lib/rail_128.png" alt="Rajbull Logo" />
        </div>
        <div class="ext-title">Rajbull Login</div>
        <?php
        if (!empty($login_err)) {
            echo '<div class="error-message">' . $login_err . '</div>';
        }
        ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="ext-form">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="ext-group">
                <label for="username" class="ext-label">👤 Username</label>
                <input type="text" name="username" id="username" placeholder="Enter username" value="<?php echo htmlspecialchars($username); ?>" required autocomplete="username">
                <span class="error-message"><?php echo $username_err; ?></span>
            </div>
            <div class="ext-group">
                <label for="password" class="ext-label">🔒 Password</label>
                <input type="password" name="password" id="password" placeholder="Enter password" required autocomplete="current-password">
                <span class="error-message"><?php echo $password_err; ?></span>
            </div>
            <div class="ext-group">
                <label for="account_type" class="ext-label">🛡️ Panel</label>
                <select name="account_type" id="account_type" class="select-panel" required>
                    <option value="" disabled <?php echo empty($account_type) ? 'selected' : ''; ?>>Select Panel</option>
                    <option value="Super" <?php echo ($account_type == 'Super') ? 'selected' : ''; ?>>Super Panel</option>
                    <option value="Admin" <?php echo ($account_type == 'Admin') ? 'selected' : ''; ?>>Admin Panel</option>
                    <option value="Master" <?php echo ($account_type == 'Master') ? 'selected' : ''; ?>>Developer Panel</option>
                </select>
            </div>
            <button type="submit" class="ext-btn ext-login">🚀 Sign In</button>
        </form>
        <div class="ext-actions">
            <a href="https://github.com/SHAHIIDTATKAL/Shahid/raw/refs/heads/main/LATEST%20V1.5.15.zip" download class="ext-btn ext-download">
                Download Latest V1.5.15
            </a>
            <a href="https://github.com/SHAHIIDTATKAL/Shahid/raw/refs/heads/main/BraveBrowserSetup-BRV011.exe" download class="ext-btn ext-download">
                Download IRCTC Browser
            </a>
        </div>
        <div class="ext-footer">© 2025 Admin Rajebull</div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r121/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vanta@latest/dist/vanta.birds.min.js"></script>
    <script>
        VANTA.BIRDS({
            el: "#vanta-background",
            mouseControls: true,
            touchControls: true,
            gyroControls: false,
            minHeight: 200.00,
            minWidth: 200.00,
            scale: 1.00,
            scaleMobile: 1.00,
            backgroundColor: 0x101415,
            color1: 0x39ff14, // neon green
            color2: 0x181f1b, // dark green/black
            birdSize: 1.50,
            wingSpan: 20.00,
            speedLimit: 5.00,
            separation: 20.00,
            alignment: 20.00,
            cohesion: 20.00,
            quantity: 3.00
        })
    </script>
</body>
</html>
