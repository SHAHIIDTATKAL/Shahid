<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}

$user_id = $_POST['user_id'] ?? '';
$credits = $_POST['credits'] ?? '';

if (!$user_id || !is_numeric($credits)) {
    header("location: " . $_SERVER['HTTP_REFERER'] . "?error=Invalid input");
    exit;
}

// Get target user's account type
$sql = "SELECT account_type FROM users WHERE id = ?";
$stmt = mysqli_prepare($link, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $target_type);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);

// Allow Master to Admin/Super, and Admin to Super
if (
    ($_SESSION['account_type'] === 'Master' && ($target_type === 'Admin' || $target_type === 'Super')) ||
    ($_SESSION['account_type'] === 'Admin' && $target_type === 'Super')
) {
    // Get old credits
    $sql_old = "SELECT credits FROM users WHERE id = ?";
    $stmt_old = mysqli_prepare($link, $sql_old);
    mysqli_stmt_bind_param($stmt_old, "i", $user_id);
    mysqli_stmt_execute($stmt_old);
    mysqli_stmt_bind_result($stmt_old, $old_credits);
    mysqli_stmt_fetch($stmt_old);
    mysqli_stmt_close($stmt_old);

    $diff = $credits - $old_credits;

    // If Admin is transferring to Super, check Admin's own credits
    if ($_SESSION['account_type'] === 'Admin' && $target_type === 'Super' && $diff > 0) {
        $sql_admin_credits = "SELECT credits FROM users WHERE id = ?";
        $stmt_admin_credits = mysqli_prepare($link, $sql_admin_credits);
        mysqli_stmt_bind_param($stmt_admin_credits, "i", $_SESSION['id']);
        mysqli_stmt_execute($stmt_admin_credits);
        mysqli_stmt_bind_result($stmt_admin_credits, $admin_credits);
        mysqli_stmt_fetch($stmt_admin_credits);
        mysqli_stmt_close($stmt_admin_credits);

        if ($admin_credits < $diff) {
            header("location: " . $_SERVER['HTTP_REFERER'] . "?error=Not enough credits to transfer!");
            exit;
        }
    }

    if ($diff > 0) {
        // Deduct from wallet (Master or Admin)
        $sql_wallet = "UPDATE users SET wallet = wallet - ? WHERE id = ?";
        if ($stmt_wallet = mysqli_prepare($link, $sql_wallet)) {
            mysqli_stmt_bind_param($stmt_wallet, "ii", $diff, $_SESSION['id']);
            mysqli_stmt_execute($stmt_wallet);
            mysqli_stmt_close($stmt_wallet);
        }
        // If Admin is transferring to Super, also deduct from Admin's credits
        if ($_SESSION['account_type'] === 'Admin' && $target_type === 'Super') {
            $sql_deduct_admin = "UPDATE users SET credits = credits - ? WHERE id = ?";
            if ($stmt_deduct_admin = mysqli_prepare($link, $sql_deduct_admin)) {
                mysqli_stmt_bind_param($stmt_deduct_admin, "ii", $diff, $_SESSION['id']);
                mysqli_stmt_execute($stmt_deduct_admin);
                mysqli_stmt_close($stmt_deduct_admin);
            }
        }
    }

    // Update credits for target user
    $sql_update = "UPDATE users SET credits = ? WHERE id = ?";
    $stmt_update = mysqli_prepare($link, $sql_update);
    mysqli_stmt_bind_param($stmt_update, "ii", $credits, $user_id);
    mysqli_stmt_execute($stmt_update);
    mysqli_stmt_close($stmt_update);

    header("location: " . $_SERVER['HTTP_REFERER'] . "?msg=Credits updated!");
    exit;
}

header("location: " . $_SERVER['HTTP_REFERER'] . "?error=Not allowed or failed.");
exit;
?>