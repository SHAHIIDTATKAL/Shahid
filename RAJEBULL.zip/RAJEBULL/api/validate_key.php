<?php
// api/validate_key.php - Validates license key and device ID (acting as MAC ID)

header('Content-Type: application/json'); // Send JSON response
header('Access-Control-Allow-Origin: *'); // CORS: IMPORTANT! Restrict this to your Chrome Extension's origin in production
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../config.php'; // Include the database connection (note: .. to go up one directory)

// Handle pre-flight OPTIONS requests (for CORS)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only accept POST requests
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check incoming POST data
    $data = json_decode(file_get_contents('php://input'), true);
    file_put_contents('php://stderr', print_r($data, true)); // Debug

    $key = $data['key'] ?? '';
    $deviceId = $data['deviceId'] ?? ''; // Device ID coming from the Chrome extension

    if (empty($key)) {
        echo json_encode([
            'success' => false,
            'status' => 400,
            'message' => 'License key is required.'
        ]);
        exit();
    }

    $sql = "SELECT id, license_key, expiry_date, mac_address, is_active FROM licenses WHERE license_key = ?";
    if ($stmt = mysqli_prepare($link, $sql)) {
        mysqli_stmt_bind_param($stmt, "s", $key);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($license = mysqli_fetch_assoc($result)) {
            // Check if license is inactive
            if (!$license['is_active']) {
                echo json_encode([
                    'success' => false,
                    'status' => 403,
                    'message' => 'License key is inactive.'
                ]);
                exit();
            }

            // Check expiry date
            $expiryDate = new DateTime($license['expiry_date']);
            $currentDate = new DateTime();
            if ($currentDate > $expiryDate) {
                echo json_encode([
                    'success' => false,
                    'status' => 403,
                    'message' => 'License key has expired.'
                ]);
                exit();
            }

            // Calculate difference for 31-day check
            $interval = $currentDate->diff($expiryDate);
            $days_until_expiry = (int)$interval->format('%R%a'); // Get signed number of days

            // Determine if it's a "long term" key (more than 31 days remaining)
            // This flag will be consumed by your extension.
            $is_long_term_expired_for_extension = ($days_until_expiry > 31);


            // MAC ID/Device ID Logic
            if (empty($license['mac_address'])) {
                // If MAC ID is empty, assign the current device ID
                $update_sql = "UPDATE licenses SET mac_address = ? WHERE id = ?";
                if ($update_stmt = mysqli_prepare($link, $update_sql)) {
                    mysqli_stmt_bind_param($update_stmt, "si", $deviceId, $license['id']);
                    if (mysqli_stmt_execute($update_stmt)) {
                        echo json_encode([
                            'success' => true,
                            'status' => 200,
                            'message' => 'License validated and assigned to this device.',
                            'is_long_term_expired' => $is_long_term_expired_for_extension // New field for extension
                        ]);
                    } else {
                        echo json_encode([
                            'success' => false,
                            'status' => 500,
                            'message' => 'Failed to assign device.'
                        ]);
                    }
                    mysqli_stmt_close($update_stmt);
                } else {
                    echo json_encode([
                        'success' => false,
                        'status' => 500,
                        'message' => 'Failed to prepare update statement.'
                    ]);
                }
            } elseif ($license['mac_address'] === $deviceId) {
                // If MAC ID is already set and matches the current device
                echo json_encode([
                    'success' => true,
                    'status' => 200,
                    'message' => 'License validated.',
                    'is_long_term_expired' => $is_long_term_expired_for_extension // New field for extension
                ]);
            } else {
                // If MAC ID is set but does not match the current device
                echo json_encode([
                    'success' => false,
                    'status' => 403,
                    'message' => 'License already active on another device. Please reset MAC ID from your panel.'
                ]);
            }

        } else {
            // License key not found
            echo json_encode([
                'success' => false,
                'status' => 403,
                'message' => 'Invalid license key.'
            ]);
        }
        mysqli_stmt_close($stmt);
    } else {
        echo json_encode([
            'success' => false,
            'status' => 500,
            'message' => 'Failed to prepare database statement.'
        ]);
    }
} else {
    // Not a POST request
    echo json_encode([
        'success' => false,
        'status' => 405,
        'message' => 'Only POST requests are allowed.'
    ]);
}

// Close database connection
mysqli_close($link);
?>