console.log("DRAGON Cosmetic Ad Blocker: Script Injected (v8 - Final Cleanup).");
function removeAllUnwantedElements() {
  const _0x34142d = ["app-ads", "app-banner", ".ads-container", "img[src*=\"cdn.jsdelivr.net/gh/corover/assets\"]", "a[href*=\"corover.ai\"]", "div[id^=\"div-gpt-ad-\"]", "#disha-image", "img[src*=\"adgebra.net\"]", "#chatbot", "#disha-placeholder-card", "#splash-scrollable"];
  if (window.location.hostname.includes("askdisha.irctc.co.in")) {
    const _0x293724 = document.getElementById("root");
    if (_0x293724 && _0x293724.isConnected) {
      console.log("DRAGON Blocker: Removing entire chatbot root (#root) inside its iframe.");
      _0x293724.remove();
      return;
    }
  }
  _0x34142d.forEach(_0xfdb55d => {
    try {
      document.querySelectorAll(_0xfdb55d).forEach(_0x4b73ec => {
        if (_0x4b73ec && _0x4b73ec.isConnected) {
          console.log("DRAGON Blocker: Removing element -> " + _0xfdb55d);
          _0x4b73ec.remove();
        }
      });
    } catch (_0x1be636) {
      console.error("DRAGON Blocker: Error with selector \"" + _0xfdb55d + "\":", _0x1be636);
    }
  });
}
function initializeDefinitiveFilter() {
  removeAllUnwantedElements();
  const _0x54778f = new MutationObserver(_0x4d7afa => {
    removeAllUnwantedElements();
  });
  _0x54778f.observe(document.documentElement, {
    'childList': true,
    'subtree': true
  });
}
initializeDefinitiveFilter();