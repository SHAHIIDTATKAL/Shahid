<?php
// create_user.php - Handles user creation by Master/Admin
session_start();

// Check if the user is logged in and authorized
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}

$allowed_to_create = [];
if ($_SESSION['account_type'] === 'Master') {
    $allowed_to_create = ['Admin', 'Super'];
} elseif ($_SESSION['account_type'] === 'Admin') {
    $allowed_to_create = ['Super'];
} else {
    // Super users or other types cannot create users
    header("location: " . $_SESSION['account_type'] . ".php?error=" . urlencode("You are not authorized to create users."));
    exit();
}

require_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $account_type = $_POST['account_type'] ?? '';

    // Validate inputs
    if (empty($username) || empty($password) || empty($account_type)) {
        $error = "All fields are required.";
    } elseif (!in_array($account_type, $allowed_to_create)) {
        $error = "You are not authorized to create a user of type '" . htmlspecialchars($account_type) . "'.";
    } else {
        // Check if username already exists
        $sql_check = "SELECT id FROM users WHERE username = ?";
        if ($stmt_check = mysqli_prepare($link, $sql_check)) {
            mysqli_stmt_bind_param($stmt_check, "s", $username);
            mysqli_stmt_execute($stmt_check);
            mysqli_stmt_store_result($stmt_check);
            if (mysqli_stmt_num_rows($stmt_check) > 0) {
                $error = "Username already exists.";
            }
            mysqli_stmt_close($stmt_check);
        } else {
            $error = "ERROR: Could not prepare username check statement.";
        }
    }

    if (empty($error)) {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert new user into the database
        $sql_insert = "INSERT INTO users (username, password, account_type) VALUES (?, ?, ?)";
        if ($stmt_insert = mysqli_prepare($link, $sql_insert)) {
            mysqli_stmt_bind_param($stmt_insert, "sss", $username, $hashed_password, $account_type);
            if (mysqli_stmt_execute($stmt_insert)) {
                $message = "User '" . htmlspecialchars($username) . "' (" . htmlspecialchars($account_type) . ") created successfully!";
                header("location: " . $_SESSION['account_type'] . ".php?msg=user_created_success");
                exit();
            } else {
                $error = "ERROR: Could not create user: " . mysqli_error($link);
            }
            mysqli_stmt_close($stmt_insert);
        } else {
            $error = "ERROR: Could not prepare user insertion statement.";
        }
    }

    // If there's an error, redirect back to the appropriate panel with the error message
    if (!empty($error)) {
        header("location: " . $_SESSION['account_type'] . ".php?error=" . urlencode($error));
        exit();
    }
} else {
    // If accessed directly without POST, redirect
    header("location: " . $_SESSION['account_type'] . ".php");
    exit();
}

mysqli_close($link);
?>