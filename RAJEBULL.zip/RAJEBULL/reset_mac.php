<?php
// reset_mac.php - Resets the MAC ID for a given license key
session_start();

function get_dashboard_redirect($type) {
    if ($type === 'Master') return 'Master.php';
    if ($type === 'Admin') return 'Admin.php';
    if ($type === 'Super') return 'Super.php';
    return 'login.php';
}

// Check if the user is logged in, if not then redirect to login page
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}

require_once 'config.php'; // Include the database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") { //
    $license_id = $_POST['license_id']; //

    // Reset the MAC ID by setting it to NULL
    $sql = "UPDATE licenses SET mac_address = NULL WHERE id = ?"; //
    if ($stmt = mysqli_prepare($link, $sql)) { //
        mysqli_stmt_bind_param($stmt, "i", $license_id); //
        if (mysqli_stmt_execute($stmt)) { //
            // Redirect back to master_dashboard.php on success
            header("location: " . get_dashboard_redirect($_SESSION['account_type']) . "?msg=" . urlencode("MAC ID successfully reset!"));
            exit();
        } else {
            // Redirect back to master_dashboard.php with error on failure
            header("location: master_dashboard.php?error=" . urlencode("Failed to reset MAC ID: " . mysqli_error($link))); // Redirect to master_dashboard.php
            exit();
        }
        mysqli_stmt_close($stmt); //
    } else {
        header("location: master_dashboard.php?error=" . urlencode("Failed to prepare statement: " . mysqli_error($link))); // Redirect to master_dashboard.php
        exit();
    }
} else {
    // If accessed directly, redirect to master_dashboard.php
    header("location: master_dashboard.php"); // Redirect to master_dashboard.php
    exit();
}

// Close database connection
mysqli_close($link); //
?>