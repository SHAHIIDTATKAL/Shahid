<?php
// Super.php - Super User Panel UI
session_start();

// Check if the user is logged in and is a Super user
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['account_type'] !== 'Super') {
    header("location: login.php");
    exit;
}

// Include database connection
require_once 'config.php';

// Variables for messages and errors
$message = '';
$error = '';

// Fetch all license keys (Super user can view only their own licenses)
$licenses = [];
$sql_licenses = "SELECT * FROM licenses WHERE created_by = ? ORDER BY created_at DESC";
if ($stmt = mysqli_prepare($link, $sql_licenses)) {
    mysqli_stmt_bind_param($stmt, "s", $_SESSION['username']);
    mysqli_stmt_execute($stmt);
    $result_licenses = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($result_licenses)) {
        $row['status'] = (strtotime($row['expiry_date']) < strtotime(date('Y-m-d'))) ? 'Expired' : 'Active';
        $licenses[] = $row;
    }
    mysqli_stmt_close($stmt);
} else {
    $error = "Failed to retrieve license keys: " . mysqli_error($link);
}

// Display messages (e.g., from toggle_status.php)
if (isset($_GET['msg'])) {
    $message = htmlspecialchars($_GET['msg']);
} elseif (isset($_GET['error'])) {
    $error = htmlspecialchars($_GET['error']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(135deg, #e0f2f7 0%, #c1e4f4 100%);
            font-family: 'Poppins', 'Inter', sans-serif;
            position: relative;
            z-index: 1;
            flex-direction: column;
            overflow-x: hidden;
        }
        .dashboard-container {
            max-width: 1300px;
            width: 95%;
            background: rgba(255,255,255,0.9);
            border-radius: 30px;
            padding: 40px 50px;
            border: 1px solid rgba(220,220,220,0.5);
            box-shadow: 0 15px 45px rgba(0,0,0,0.1), 0 8px 20px rgba(0,0,0,0.05);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            position: relative;
            z-index: 10;
            box-sizing: border-box;
            display: flex;
            gap: 40px;
            overflow: hidden;
        }
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, #f0f8ff 0%, #e0f2f7 100%);
            color: #333;
            padding: 30px 25px;
            border-radius: 25px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            flex-shrink: 0;
            position: sticky;
            top: 20px;
            height: calc(100vh - 40px);
            max-height: 750px;
            overflow-y: auto;
            border: 1px solid rgba(220,220,220,0.5);
        }
        .sidebar h2 {
            color: #007bff;
            text-align: center;
            margin-bottom: 50px;
            font-size: 2.2em;
            font-weight: 800;
            letter-spacing: 1px;
            text-shadow: 0 0 5px rgba(0,123,255,0.2);
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin-bottom: 30px;
            flex-grow: 1;
        }
        .sidebar ul li {
            margin-bottom: 10px;
        }
        .sidebar ul li a {
            display: flex;
            align-items: center;
            padding: 12px 18px;
            color: #555;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
            gap: 15px;
        }
        .sidebar ul li a .icon {
            font-size: 1.3em;
            color: #888;
        }
        .sidebar ul li a:hover {
            background: rgba(0, 123, 255, 0.1);
            color: #007bff;
            transform: translateX(5px);
        }
        .sidebar ul li a.active {
            background: linear-gradient(45deg, #007bff, #0056b3);
            color: #fff;
            box-shadow: 0 4px 15px rgba(0, 123, 255, 0.3);
            transform: translateX(5px);
        }
        .sidebar ul li a.active .icon {
            color: #fff;
        }
        .sidebar .logout-section {
            padding-top: 20px;
            border-top: 1px solid rgba(0,0,0,0.05);
        }
        .sidebar .logout-section a {
            background: #dc3545;
            color: #fff;
            justify-content: center;
            padding: 12px 0;
            border-radius: 12px;
            transition: background 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            font-weight: 600;
        }
        .sidebar .logout-section a:hover {
            background: #c82333;
            transform: none;
        }
        .main-content {
            flex-grow: 1;
            padding: 0px;
            overflow-y: auto;
            max-height: 750px;
        }
        .info-header {
            background: linear-gradient(45deg, #007bff, #0056b3);
            color: #fff;
            padding: 30px 40px;
            border-radius: 20px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 123, 255, 0.2);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .info-header h1 {
            margin: 0;
            font-size: 2.5em;
            font-weight: 700;
        }
        .info-header p {
            margin: 5px 0 0;
            font-size: 1.1em;
            opacity: 0.9;
        }
        .info-header .profile-info {
            text-align: right;
        }
        .info-header .profile-info span {
            display: block;
            font-size: 1.2em;
            font-weight: 600;
        }
        .info-header .profile-info small {
            font-size: 0.9em;
            opacity: 0.8;
        }
        .dashboard-section {
            background: #ffffff;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.08);
            margin-bottom: 30px;
            border: 1px solid rgba(220, 220, 220, 0.5);
            animation: fadeIn 0.5s ease-out forwards;
        }
        .dashboard-section h3 {
            color: #333;
            font-size: 1.8em;
            margin-bottom: 25px;
            border-bottom: 2px solid #eee;
            padding-bottom: 15px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
        }
        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group input[type="password"],
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 1em;
            box-sizing: border-box;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .form-group input[type="text"]:focus,
        .form-group input[type="date"]:focus,
        .form-group input[type="password"]:focus,
        .form-group select:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.2);
            outline: none;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.1em;
            font-weight: 600;
            transition: background-color 0.3s ease, transform 0.2s ease;
            display: inline-block;
            margin-top: 10px;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }
        .btn-danger {
            background-color: #dc3545;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1em;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
        .btn-toggle-active {
            background-color: #17a2b8; /* Info blue */
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1em;
            font-weight: 600;
            transition: background-color 0.3s ease;
            margin-left: 5px; /* Add some spacing */
        }
        .btn-toggle-active:hover {
            background-color: #138496;
        }
        .message-success {
            color: #28a745;
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 500;
        }
        .message-error {
            color: #dc3545;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 500;
        }
        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-top: 20px;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        thead th {
            background-color: #f8f9fa;
            color: #666;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.9em;
        }
        tbody tr:last-child td {
            border-bottom: none;
        }
        tbody tr:hover {
            background-color: #f0f8ff;
        }
        .status-expired {
            background-color: #fbd7da;
            color: #8c0000;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
        }
        .status-active {
            background-color: #d4edda;
            color: #155724;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
        }
        .status-inactive {
            background-color: #e2e6ea;
            color: #495057;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <aside class="sidebar">
        <div>
            <h2>Super Panel</h2>
            <ul>
                <li><a href="#" class="active" onclick="showSection('licenseSection'); return false;"><i class="fas fa-key icon"></i> View Licenses </a></li>
            </ul>
        </div>
        <div class="logout-section">
            <a href="logout.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
        </div>
    </aside>
    <main class="main-content">
        <div class="info-header">
            <div>
                <h1>Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?>!</h1>
                <p><?php echo htmlspecialchars($_SESSION["account_type"]); ?> Panel </p>
            </div>
            <div class="profile-info">
                <span><?php echo htmlspecialchars($_SESSION["account_type"]); ?> Account</span>
                <?php
                    // Fetch Super's own credits
                    $my_credits = 0;
                    $sql_credits = "SELECT credits FROM users WHERE id = ?";
                    if ($stmt_credits = mysqli_prepare($link, $sql_credits)) {
                        mysqli_stmt_bind_param($stmt_credits, "i", $_SESSION['id']);
                        mysqli_stmt_execute($stmt_credits);
                        mysqli_stmt_bind_result($stmt_credits, $my_credits);
                        mysqli_stmt_fetch($stmt_credits);
                        mysqli_stmt_close($stmt_credits);
                    }
                ?>
                <small style="display:block;margin-top:8px;">
                    <strong>Credits:</strong> <?php echo (int)$my_credits; ?>
                </small>
            </div>
        </div>

        <section id="licenseSection" class="dashboard-section">
            <h3>Licensed Products</h3>

            <!-- लाइसेंस की बनाने का फॉर्म (Expiry Date फील्ड नहीं है) -->
            <form action="generate_key.php" method="POST" style="margin-bottom:30px;">
                <div class="form-group">
                    <label for="new_license_key">Enter License Key:</label>
                    <input type="text" id="new_license_key" name="new_license_key" placeholder="KEY" required>
                </div>
                <button type="submit" class="btn-primary">Create Key</button>
            </form>

            <?php if ($message): ?>
                <div class="message-success"><?php echo $message; ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="message-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <?php if (empty($licenses)): ?>
                <p>No license keys found.</p>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table>
    <thead>
        <tr>
            <th>Key</th>
            <th>Expiry Date</th>
            <th>MAC ID</th>
            <th>Expiry Status</th>
            <th>Active Status</th>
            <th>Created At</th>
            <th>Actions</th> <!-- नया कॉलम -->
        </tr>
    </thead>
    <tbody>
        <?php foreach ($licenses as $license): ?>
            <tr>
                <td class="font-mono text-sm"><?php echo htmlspecialchars($license['license_key']); ?></td>
                <td><?php echo htmlspecialchars($license['expiry_date']); ?></td>
                <td><?php echo $license['mac_address'] ? htmlspecialchars($license['mac_address']) : 'N/A'; ?></td>
                <td>
                    <span class="<?php echo ($license['status'] == 'Expired') ? 'status-expired' : 'status-active'; ?>">
                        <?php echo htmlspecialchars($license['status']); ?>
                    </span>
                </td>
                <td>
                    <span class="<?php echo ($license['is_active'] ? 'status-active' : 'status-inactive'); ?>">
                        <?php echo $license['is_active'] ? 'Active' : 'Inactive'; ?>
                    </span>
                </td>
                <td><?php echo htmlspecialchars($license['created_at']); ?></td>
                <td>
                    <!-- Reset MAC ID -->
                    <form action="reset_mac.php" method="POST" style="display:inline;">
                        <input type="hidden" name="license_id" value="<?php echo $license['id']; ?>">
                        <button type="submit" class="btn-toggle-active" onclick="return confirm('Are you sure you want to reset MAC ID?');">Reset</button>
                    </form>
                    <!-- Activate/Deactivate -->
                    <form action="toggle_status.php" method="POST" style="display:inline;">
                        <input type="hidden" name="license_id" value="<?php echo $license['id']; ?>">
                        <input type="hidden" name="current_status" value="<?php echo $license['is_active'] ? 'active' : 'inactive'; ?>">
                        <button type="submit" class="btn-danger" onclick="return confirm('Are you sure you want to <?php echo $license['is_active'] ? 'deactivate' : 'activate'; ?> this key?');">
                            <?php echo $license['is_active'] ? 'Deactivate' : 'Activate'; ?>
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
                </div>
            <?php endif; ?>
        </section>
    </main>
</div>

<script>
    function showSection(sectionId) {
        document.getElementById('licenseSection').style.display = 'none';
        // Add other section hiding if you add more to Super.php
        document.getElementById(sectionId).style.display = 'block';

        document.querySelectorAll('.sidebar ul li a').forEach(item => {
            item.classList.remove('active');
        });
        if (sectionId === 'licenseSection') {
            document.querySelector('.sidebar ul li:nth-child(1) a').classList.add('active');
        }
    }
    document.addEventListener('DOMContentLoaded', () => {
        showSection('licenseSection');
    });
</script>

</body>
</html>

<?php
mysqli_close($link);
?>