<?php
// config.php - Database Configuration

// Database Credentials
define('DB_SERVER', 'localhost'); // Your database server address (usually 'localhost')
define('DB_USERNAME', 'u101269903_Avinash');   // Your database username
define('DB_PASSWORD', 'Avinash@9026407292');       // Your database user's password
define('DB_NAME', 'u101269903_Avinash'); // The name of your database

// Attempt to connect to the MySQL database
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if ($link === false) {
    die("ERROR: Could not connect to the database. " . mysqli_connect_error());
}

// --- Initial Database and Table Setup (Run once or ensure they exist) ---
// This part attempts to create the database and table if they don't exist.
// In a production environment, you might prefer to create these manually or via a separate setup script.

// Attempt to create the database if it doesn't exist
$conn_no_db = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD);
if ($conn_no_db) {
    $sql_create_db = "CREATE DATABASE IF NOT EXISTS " . DB_NAME;
    if (mysqli_query($conn_no_db, $sql_create_db)) {
        // Database created successfully or already existed
    } else {
        error_log("ERROR: Failed to create database " . mysqli_error($conn_no_db));
    }
    mysqli_close($conn_no_db);
}

// Attempt to create the 'licenses' table if it doesn't exist
$sql_create_licenses_table = "
CREATE TABLE IF NOT EXISTS licenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    license_key VARCHAR(255) UNIQUE NOT NULL,
    expiry_date DATE NOT NULL,
    mac_address VARCHAR(255) NULL, -- Stores the device ID or \"MAC ID\" (from extension)
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
";
if (!mysqli_query($link, $sql_create_licenses_table)) {
    error_log("ERROR: Failed to create licenses table: " . mysqli_error($link));
}


// --- NEW: Create 'users' table if it doesn't exist ---
$sql_create_users_table = "
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL, -- Storing hashed passwords
    account_type ENUM('Super', 'Admin', 'Master') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
";
if (!mysqli_query($link, $sql_create_users_table)) {
    error_log("ERROR: Failed to create users table: " . mysqli_error($link));
}

// --- Optional: Insert a default Master user if the table is empty (for first time setup) ---
// IMPORTANT: Change default password for production!
$check_master_sql = "SELECT COUNT(*) FROM users WHERE account_type = 'Master'";
$check_master_result = mysqli_query($link, $check_master_sql);
$row = mysqli_fetch_array($check_master_result);
if ($row[0] == 0) {
    $default_master_username = 'masteradmin';
    $default_master_password = password_hash('admin@123', PASSWORD_DEFAULT); // Hash the password
    $insert_master_sql = "INSERT INTO users (username, password, account_type) VALUES (?, ?, 'Master')";
    if ($stmt = mysqli_prepare($link, $insert_master_sql)) {
        mysqli_stmt_bind_param($stmt, "ss", $default_master_username, $default_master_password);
        if (mysqli_stmt_execute($stmt)) {
            // echo "Default Master user 'masteradmin' created successfully.<br>";
        } else {
            error_log("ERROR: Could not insert default Master user: " . mysqli_error($link));
        }
        mysqli_stmt_close($stmt);
    }
}
// End of optional default user insertion
?>