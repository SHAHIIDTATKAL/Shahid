<?php
// generate_key.php - नई लाइसेंस की उत्पन्न करता है (आपके नाम से)
session_start(); // Start the session

// --- ADD THIS BLOCK ---
if (
    !isset($_SESSION['account_type']) ||
    (
        $_SESSION['account_type'] !== 'Master' &&
        $_SESSION['account_type'] !== 'Admin' &&
        $_SESSION['account_type'] !== 'Super'
    )
) {
    header("location: login.php?error=" . urlencode("आपको अनुमति नहीं है।"));
    exit;
}
// --- END BLOCK ---

// Check if the user is logged in, if not then redirect to login page
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}

require_once 'config.php'; // डेटाबेस कनेक्शन शामिल करें

// Helper: Redirect to correct dashboard based on account type
function get_dashboard_redirect($type) {
    if ($type === 'Master') return 'Master.php';
    if ($type === 'Admin') return 'Admin.php';
    return 'login.php';
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $created_by = $_SESSION['username'];
    $account_type = $_SESSION['account_type'];

    // Admin, Super, या Seller के लिए क्रेडिट चेक करें
    if ($account_type === 'Admin' || $account_type === 'Super' || $account_type === 'Seller') {
        $sql_credits = "SELECT credits FROM users WHERE username = ?";
        if ($stmt_credits = mysqli_prepare($link, $sql_credits)) {
            mysqli_stmt_bind_param($stmt_credits, "s", $created_by);
            mysqli_stmt_execute($stmt_credits);
            mysqli_stmt_bind_result($stmt_credits, $credits);
            mysqli_stmt_fetch($stmt_credits);
            mysqli_stmt_close($stmt_credits);
            if ($credits < 1) {
                header("location: " . get_dashboard_redirect($account_type) . "?error=" . urlencode("Not enough credits to create a license key."));
                exit();
            }
        }
    }

    $new_license_key = $_POST['new_license_key'] ?? '';
    $expiry_date = date('Y-m-d', strtotime('+1 month'));

    // की खाली न हो इसकी जाँच करें
    if (empty($new_license_key)) { //
        header("location: " . get_dashboard_redirect($_SESSION['account_type']) . "?error=" . urlencode("लाइसेंस की दर्ज करना आवश्यक है।")); // Redirect to master_dashboard.php
        exit();
    }
    // समाप्ति तिथि खाली न हो इसकी जाँच करें
    if (empty($expiry_date)) { //
        header("location: " . get_dashboard_redirect($_SESSION['account_type']) . "?error=" . urlencode("समाप्ति तिथि आवश्यक है।")); // Redirect to master_dashboard.php
        exit();
    }


    // की पहले से मौजूद है या नहीं, इसकी जाँच करें
    $check_sql = "SELECT COUNT(*) FROM licenses WHERE license_key = ?"; //
    if ($check_stmt = mysqli_prepare($link, $check_sql)) { //
        mysqli_stmt_bind_param($check_stmt, "s", $new_license_key); //
        mysqli_stmt_execute($check_stmt); //
        mysqli_stmt_bind_result($check_stmt, $count); //
        mysqli_stmt_fetch($check_stmt); //
        mysqli_stmt_close($check_stmt); //

        if ($count > 0) { //
            header("location: " . get_dashboard_redirect($_SESSION['account_type']) . "?error=" . urlencode("यह लाइसेंस की पहले से मौजूद है। कृपया एक अलग की चुनें।")); // Redirect to master_dashboard.php
            exit();
        }
    } else {
        header("location: " . get_dashboard_redirect($_SESSION['account_type']) . "?error=" . urlencode("की डुप्लीकेसी जांचने में विफल रहा: " . mysqli_error($link))); // Redirect to master_dashboard.php
        exit();
    }


    // डेटाबेस में नई की डालें
    $sql = "INSERT INTO licenses (license_key, expiry_date, created_by) VALUES (?, ?, ?)"; //
    if ($stmt = mysqli_prepare($link, $sql)) { //
        mysqli_stmt_bind_param($stmt, "sss", $new_license_key, $expiry_date, $created_by); //
        // लाइसेंस सफलतापूर्वक बन जाए तो क्रेडिट घटाएं
        if (mysqli_stmt_execute($stmt)) {
            if ($account_type === 'Admin' || $account_type === 'Super' || $account_type === 'Seller') {
                $sql_dec = "UPDATE users SET credits = credits - 1 WHERE username = ?";
                if ($stmt_dec = mysqli_prepare($link, $sql_dec)) {
                    mysqli_stmt_bind_param($stmt_dec, "s", $created_by);
                    mysqli_stmt_execute($stmt_dec);
                    mysqli_stmt_close($stmt_dec);
                }
            }
            header("location: " . get_dashboard_redirect($account_type) . "?msg=key_created_success&new_key=" . urlencode($new_license_key));
            exit();
        } else {
            // विफलता पर त्रुटि के साथ master_dashboard.php पर रीडायरेक्ट करें
            header("location: " . get_dashboard_redirect($_SESSION['account_type']) . "?error=" . urlencode("की बनाने में विफल रहा: " . mysqli_error($link))); // Redirect to master_dashboard.php
            exit();
        }
        mysqli_stmt_close($stmt); //
    } else {
        header("location: " . get_dashboard_redirect($_SESSION['account_type']) . "?error=" . urlencode("तैयारी स्टेटमेंट विफल रहा: " . mysqli_error($link))); // Redirect to master_dashboard.php
        exit();
    }
} else {
    // यदि सीधे एक्सेस किया गया है, तो master_dashboard.php पर रीडायरेक्ट करें
    header("location: " . get_dashboard_redirect($_SESSION['account_type']));
    exit();
}

// लाइसेंसों को प्राप्त करने के लिए कोड ब्लॉक
$sql_licenses = "SELECT * FROM licenses WHERE created_by = ? ORDER BY created_at DESC";
if ($stmt = mysqli_prepare($link, $sql_licenses)) {
    mysqli_stmt_bind_param($stmt, "s", $_SESSION['username']);
    // ...बाकी कोड...
}

// डेटाबेस कनेक्शन बंद करें
mysqli_close($link); //
?>