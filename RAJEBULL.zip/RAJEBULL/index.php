<?php
// index.php - Redirect to the login page

header("location: login.php");
exit;
?>