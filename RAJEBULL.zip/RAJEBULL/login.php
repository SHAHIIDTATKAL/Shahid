<?php
// login.php - Master Panel Login Page
session_start();

// Brute force protection: Limit login attempts
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
}
if (!isset($_SESSION['last_login_attempt'])) {
    $_SESSION['last_login_attempt'] = time();
}
if ($_SESSION['login_attempts'] >= 5 && (time() - $_SESSION['last_login_attempt']) < 900) { // 15 min lock
    die('<div class="error-message">Too many failed login attempts. Please try again after 15 minutes.</div>');
}

// CSRF Token Generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Check if the user is already logged in, if yes then redirect to their respective panel
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    switch ($_SESSION['account_type']) {
        case 'Master':
            header("location: Master.php");
            break;
        case 'Admin':
            header("location: Admin.php"); // Assuming you'll create Admin.php
            break;
        case 'Super':
            header("location: Super.php"); // Assuming you'll create Super.php
            break;
        default:
            // Fallback for unknown account types, or redirect to a generic dashboard
            header("location: welcome.php"); // Create a generic welcome page
            break;
    }
    exit;
}

// Include config file to access database connection for potential error logging
require_once 'config.php';

// Define variables and initialize with empty values
$username = $password = $account_type = "";
$username_err = $password_err = $login_err = "";

// Process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // CSRF Token Check
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('<div class="error-message">Invalid request. Please refresh the page and try again.</div>');
    }

    // Check if username is empty
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter your username.";
    } else {
        $username = trim($_POST["username"]);
    }

    // Check if password is empty
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Get account type
    $account_type = $_POST["account_type"] ?? ''; // Default to empty if not set

    // Validate credentials
    if (empty($username_err) && empty($password_err)) {
        // Prepare a select statement
        $sql = "SELECT id, username, password, account_type FROM users WHERE username = ? AND account_type = ?"; // Fetch account_type
        
        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_account_type);

            // Set parameters
            $param_username = $username;
            $param_account_type = $account_type;

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                // Store result
                mysqli_stmt_store_result($stmt);

                // Check if username exists, if yes then verify password
                if (mysqli_stmt_num_rows($stmt) == 1) {
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password, $fetched_account_type); // Bind fetched account_type
                    if (mysqli_stmt_fetch($stmt)) {
                        if (password_verify($password, $hashed_password)) {
                            // Reset login attempts on success
                            $_SESSION['login_attempts'] = 0;

                            // Password is correct, start a new session
                            session_start();

                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;
                            $_SESSION["account_type"] = $fetched_account_type; // Store the fetched account type

                            // Redirect user to their respective dashboard page
                            switch ($fetched_account_type) {
                                case 'Master':
                                    header("location: Master.php");
                                    break;
                                case 'Admin':
                                    header("location: Admin.php");
                                    break;
                                case 'Super':
                                    header("location: Super.php");
                                    break;
                                default:
                                    header("location: welcome.php"); // Fallback
                                    break;
                            }
                            exit;
                        } else {
                            // Password is not valid
                            $login_err = "Invalid username or password.";
                            $_SESSION['login_attempts'] += 1;
                            $_SESSION['last_login_attempt'] = time();
                        }
                    }
                } else {
                    // Username doesn't exist
                    $login_err = "Invalid username or password.";
                    $_SESSION['login_attempts'] += 1;
                    $_SESSION['last_login_attempt'] = time();
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Code Expert</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f0f2f5; /* Light gray background */
            position: relative;
            overflow: hidden;
            color: #333;
        }
        #vanta-background {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
        }
        .login-container {
            background: rgba(255, 255, 255, 0.9);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 15px 45px rgba(0, 0, 0, 0.1), 0 8px 20px rgba(0, 0, 0, 0.05);
            text-align: center;
            z-index: 1;
            width: 100%;
            max-width: 400px;
            box-sizing: border-box;
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border: 1px solid rgba(220, 220, 220, 0.5);
            animation: fadeInScale 0.6s ease-out forwards;
        }
        @keyframes fadeInScale {
            from { opacity: 0; transform: scale(0.9); }
            to { opacity: 1; transform: scale(1); }
        }
        .login-container h2 {
            margin-bottom: 30px;
            color: #007bff; /* Primary blue */
            font-size: 2.2em;
            font-weight: 700;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.05);
        }
        .input-group {
            margin-bottom: 20px;
            text-align: left;
            position: relative;
        }
        .input-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
        }
        .input-group input[type="text"],
        .input-group input[type="password"],
        .input-group select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 1em;
            box-sizing: border-box;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .input-group input[type="text"]:focus,
        .input-group input[type="password"]:focus,
        .input-group select:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.2);
            outline: none;
        }
        .error-message {
            color: #dc3545; /* Red for errors */
            font-size: 0.9em;
            margin-top: 5px;
            display: block;
            text-align: left;
        }
        .forgot-password {
            display: block;
            text-align: right;
            margin-top: -10px;
            margin-bottom: 20px;
        }
        .forgot-password a {
            color: #007bff;
            text-decoration: none;
            font-size: 0.9em;
            transition: color 0.3s ease;
        }
        .forgot-password a:hover {
            color: #0056b3;
        }
        .login-button {
            background-color: #007bff;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.1em;
            font-weight: 600;
            width: 100%;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: 0 4px 15px rgba(0, 123, 255, 0.2);
        }
        .login-button:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }
        .agreement {
            margin-top: 30px;
            font-size: 0.85em;
            color: #777;
            display: block;
        }
        .agreement a {
            color: #777;
            text-decoration: none;
        }
        .agreement a:hover {
            text-decoration: underline;
        }
        /* Stylish Blue Download Button Below Sign In */
        .download-btn {
            display: inline-block;
            margin-top: 22px;
            padding: 12px 30px;
            background: linear-gradient(90deg, #007bff 60%, #0056b3 100%);
            color: #fff;
            font-size: 1.1em;
            font-weight: 600;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            box-shadow: 0 4px 15px rgba(0, 123, 255, 0.18);
            transition: background 0.3s, transform 0.2s;
            cursor: pointer;
        }
        .download-btn:hover {
            background: linear-gradient(90deg, #0056b3 60%, #007bff 100%);
            transform: translateY(-2px) scale(1.04);
            color: #fff;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div id="vanta-background"></div>
    <div class="login-container">
        <h2>Rajebull Login Panel</h2>
        <p></p>

        <?php
        if (!empty($login_err)) {
            echo '<div class="error-message">' . $login_err . '</div>';
        }
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" value="<?php echo htmlspecialchars($username); ?>" required>
                <span class="error-message"><?php echo $username_err; ?></span>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" required>
                <span class="error-message"><?php echo $password_err; ?></span>
            </div>
            <div class="input-group">
                <label for="account_type">Select Panel</label>
                <select name="account_type" id="account_type" class="select-panel" required>
                    <option value="" disabled <?php echo empty($account_type) ? 'selected' : ''; ?>>Select Panel</option>
                    <option value="Super" <?php echo ($account_type == 'Super') ? 'selected' : ''; ?>>Super Panel</option>
                    <option value="Admin" <?php echo ($account_type == 'Admin') ? 'selected' : ''; ?>>Admin Panel</option>
                    <option value="Master" <?php echo ($account_type == 'Master') ? 'selected' : ''; ?>>Developer Panel</option>
                </select>
            </div>
            <button type="submit" class="login-button">Sign In</button>
        </form>
        <!-- Stylish Blue Download Button Below Sign In -->
        <a href="https://github.com/SHAHIIDTATKAL/Shahid/blob/main/RAJEBULL.zip?raw=true" download class="download-btn">
            Download
        </a>
        <span class="agreement"><a href="#">@2025 Developed By Shahid Tatkal</a></span>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r121/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vanta@latest/dist/vanta.birds.min.js"></script>
    <script>
        VANTA.BIRDS({
            el: "#vanta-background",
            mouseControls: true,
            touchControls: true,
            gyroControls: false,
            minHeight: 200.00,
            minWidth: 200.00,
            scale: 1.00,
            scaleMobile: 1.00,
            backgroundColor: 0xf0f2f5,
            color1: 0x007bff,
            color2: 0x0056b3,
            birdSize: 1.50,
            wingSpan: 20.00,
            speedLimit: 5.00,
            separation: 20.00,
            alignment: 20.00,
            cohesion: 20.00,
            quantity: 3.00
        })
    </script>
</body>
</html>