<?php
// toggle_status.php - Handles activation/deactivation of a license key
session_start();

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}

require_once 'config.php';

// Helper function to get redirect page
function get_dashboard_redirect($type) {
    if ($type === 'Master') return 'Master.php';
    if ($type === 'Admin') return 'Admin.php';
    if ($type === 'Super') return 'Super.php';
    return 'login.php';
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $license_id = $_POST['license_id'] ?? '';
    $current_status = $_POST['current_status'] ?? ''; // 'active' or 'inactive'

    if (empty($license_id) || !in_array($current_status, ['active', 'inactive'])) {
        header("location: " . get_dashboard_redirect($_SESSION['account_type']) . "?error=" . urlencode("Invalid request for status toggle."));
        exit();
    }

    $new_status = ($current_status === 'active') ? 0 : 1; // 0 for inactive, 1 for active

    $sql = "UPDATE licenses SET is_active = ? WHERE id = ?";
    if ($stmt = mysqli_prepare($link, $sql)) {
        mysqli_stmt_bind_param($stmt, "ii", $new_status, $license_id);
        if (mysqli_stmt_execute($stmt)) {
            $message = "License key status successfully changed!";
            header("location: " . get_dashboard_redirect($_SESSION['account_type']) . "?msg=" . urlencode($message));
            exit();
        } else {
            $error = "ERROR: Could not update status: " . mysqli_error($link);
            header("location: " . get_dashboard_redirect($_SESSION['account_type']) . "?error=" . urlencode($error));
            exit();
        }
        mysqli_stmt_close($stmt);
    } else {
        $error = "ERROR: Could not prepare statement: " . mysqli_error($link);
        header("location: " . get_dashboard_redirect($_SESSION['account_type']) . "?error=" . urlencode($error));
        exit();
    }
} else {
    header("location: " . get_dashboard_redirect($_SESSION['account_type']) . "?error=" . urlencode("Invalid request method."));
    exit();
}

mysqli_close($link);
?>