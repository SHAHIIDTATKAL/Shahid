<?php
// delete_user.php - Handles user deletion by Master/Admin
session_start();

// Check if the user is logged in and authorized to delete
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}

// Only Master can delete any user (except self or other Masters)
// Admin can delete Super users (except self if an Admin tries to delete self)
if ($_SESSION['account_type'] !== 'Master' && $_SESSION['account_type'] !== 'Admin') {
    header("location: " . $_SESSION['account_type'] . ".php?error=" . urlencode("You are not authorized to delete users."));
    exit();
}

require_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'] ?? '';

    if (empty($user_id)) {
        $error = "User ID is required.";
    } else {
        // Fetch user details to ensure authorization
        $sql_fetch_user = "SELECT id, account_type FROM users WHERE id = ?";
        if ($stmt_fetch_user = mysqli_prepare($link, $sql_fetch_user)) {
            mysqli_stmt_bind_param($stmt_fetch_user, "i", $user_id);
            mysqli_stmt_execute($stmt_fetch_user);
            $result_fetch_user = mysqli_stmt_get_result($stmt_fetch_user);
            $target_user = mysqli_fetch_assoc($result_fetch_user);
            mysqli_stmt_close($stmt_fetch_user);

            if ($target_user) {
                // Prevent deleting self
                if ($target_user['id'] == $_SESSION['id']) {
                    $error = "You cannot delete your own account.";
                }
                // Prevent Master from deleting other Master accounts
                elseif ($target_user['account_type'] === 'Master') {
                    $error = "You cannot delete Master accounts.";
                }
                // Admin can only delete Super accounts
                elseif ($_SESSION['account_type'] === 'Admin' && $target_user['account_type'] !== 'Super') {
                    $error = "As an Admin, you can only delete Super accounts.";
                }
            } else {
                $error = "User not found.";
            }
        } else {
            $error = "ERROR: Could not prepare user fetch statement.";
        }
    }

    if (empty($error)) {
        $sql_delete = "DELETE FROM users WHERE id = ?";
        if ($stmt_delete = mysqli_prepare($link, $sql_delete)) {
            mysqli_stmt_bind_param($stmt_delete, "i", $user_id);
            if (mysqli_stmt_execute($stmt_delete)) {
                $message = "User deleted successfully!";
                header("location: " . $_SESSION['account_type'] . ".php?msg=" . urlencode($message));
                exit();
            } else {
                $error = "ERROR: Could not delete user: " . mysqli_error($link);
            }
            mysqli_stmt_close($stmt_delete);
        } else {
            $error = "ERROR: Could not prepare delete statement.";
        }
    }

    // If there's an error, redirect back to the appropriate panel with the error message
    if (!empty($error)) {
        header("location: " . $_SESSION['account_type'] . ".php?error=" . urlencode($error));
        exit();
    }
} else {
    // If accessed directly without POST, redirect
    header("location: " . $_SESSION['account_type'] . ".php");
    exit();
}

mysqli_close($link);
?>