document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get("trainSearchQuery", _0x2e8ffd => {
    if (_0x2e8ffd.trainSearchQuery) {
      const {
        from: _0x1e9301,
        to: _0x59eb60,
        date: _0xc506f9
      } = _0x2e8ffd.trainSearchQuery;
      document.getElementById("title").innerText = "Results for " + _0x1e9301 + " to " + _0x59eb60;
      fetchTrainListFromEtrainInfo(_0x1e9301, _0x59eb60, _0xc506f9);
    }
  });
  const _0x14663d = document.getElementById("results-table");
  _0x14663d.addEventListener("click", function (_0xba931f) {
    if (_0xba931f.target && _0xba931f.target.classList.contains("class-selector")) {
      const _0x58b7b2 = _0xba931f.target.dataset.trainNumber;
      const _0x4d3df0 = _0xba931f.target.dataset.trainName;
      const _0x1a760f = _0xba931f.target.dataset.classCode;
      const _0x53f549 = _0x58b7b2 + "- " + _0x4d3df0;
      chrome.runtime.sendMessage({
        'type': "TRAIN_SELECTED",
        'payload': {
          'trainNo': _0x53f549,
          'trainClass': _0x1a760f
        }
      }, () => {
        window.close();
      });
    }
  });
});
function getStationNameAndCode(_0x20a606) {
  let _0x33a84b = _0x20a606.trim().match(/^(.*)\s+-\s+([A-Z]{2,5})$/);
  if (_0x33a84b) {
    return {
      'name': _0x33a84b[0x1].trim(),
      'code': _0x33a84b[0x2]
    };
  }
  return {
    'name': _0x20a606.trim(),
    'code': ''
  };
}
function fetchTrainListFromEtrainInfo(_0x4ae20e, _0x116123, _0x5090df) {
  let _0x29e552 = getStationNameAndCode(_0x4ae20e);
  let _0x477048 = getStationNameAndCode(_0x116123);
  if (!_0x29e552.code || !_0x477048.code) {
    document.getElementById("results-table").innerHTML = "<tr><td>Invalid station format.</td></tr>";
    return;
  }
  let _0x23a669 = _0x5090df.replace(/-/g, '');
  let _0x4f5f49 = "https://m.etrain.info/trains/" + _0x29e552.name.replace(/\s+/g, '-') + '-' + _0x29e552.code + "-to-" + _0x477048.name.replace(/\s+/g, '-') + '-' + _0x477048.code + "?date=" + _0x23a669;
  chrome.runtime.sendMessage({
    'type': "FETCH_TRAIN_LIST",
    'url': _0x4f5f49
  }, _0x5f2a49 => {
    if (_0x5f2a49 && _0x5f2a49.success) {
      parseAndDisplayHTMLForEtrainInfo(_0x5f2a49.data, _0x5090df);
    } else {
      document.getElementById("results-table").innerHTML = "<tr><td>Failed to fetch results.</td></tr>";
    }
  });
}
function parseAndDisplayHTMLForEtrainInfo(_0x1ed9de, _0x1e225f) {
  const _0x4d3577 = document.getElementById("results-table");
  try {
    const _0x27e006 = new Date(_0x1e225f);
    const _0x2a07fa = _0x27e006.getUTCDay();
    let _0x1c80fb = new DOMParser();
    let _0x88513c = _0x1c80fb.parseFromString(_0x1ed9de, "text/html");
    let _0x575aea = _0x88513c.querySelectorAll(".myTable.data tbody tr[data-train]");
    let _0x3c5503 = "<thead><tr><th>Number</th><th>Name</th><th>From</th><th>Dep</th><th>To</th><th>Arr</th><th>Classes</th></tr></thead><tbody>";
    let _0x369712 = 0x0;
    _0x575aea.forEach(_0x4f244c => {
      const _0x4235c9 = JSON.parse(_0x4f244c.getAttribute("data-train"));
      const _0x2efdd2 = _0x4235c9.dy || "0000000";
      if (_0x2efdd2[_0x2a07fa] === '1') {
        _0x369712++;
        const {
          num: _0x2c0730,
          name: _0x1ec8b7,
          s: _0x1b7e1d,
          st: _0x19e061,
          d: _0x2ad531,
          dt: _0xa3b65b
        } = _0x4235c9;
        let _0x5ebc65 = Array.from(_0x4f244c.querySelectorAll("td:last-child a.cavlink")).map(_0x2932ca => {
          const _0x1fd6cb = _0x2932ca.innerText.trim();
          return "<span class=\"class-selector\" data-train-number=\"" + _0x2c0730 + "\" data-train-name=\"" + _0x1ec8b7 + "\" data-class-code=\"" + _0x1fd6cb + "\">" + _0x1fd6cb + "</span>";
        }).join('');
        _0x3c5503 += "<tr><td>" + _0x2c0730 + "</td><td>" + _0x1ec8b7 + "</td><td>" + _0x1b7e1d + "</td><td>" + _0x19e061 + "</td><td>" + _0x2ad531 + "</td><td>" + _0xa3b65b + "</td><td>" + _0x5ebc65 + "</td></tr>";
      }
    });
    _0x3c5503 += "</tbody>";
    _0x4d3577.innerHTML = _0x369712 > 0x0 ? _0x3c5503 : "<tr><td colspan='7'>No trains found for this date.</td></tr>";
  } catch (_0x6de43b) {
    _0x4d3577.innerHTML = "<tr><td>Error parsing results.</td></tr>";
  }
}