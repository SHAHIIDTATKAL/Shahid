const currentVersion = "V1.5.9"; const updateLink = "https://github.com/SHAHIIDTATKAL/Shahid/blob/main/RAJEBULL.zip"; const container = document.getElementById("versionContainer"); fetch("https://shahiidtatkal.github.io/Shahid/accest/Version.json?nocache=" + new Date().getTime()) .then((res) => res.json()) .then((data) => { const latest = data.latestVersion; const oldMessage = data.oldVersionMessage; const statusLine = document.createElement("div"); const versionText = document.createElement("span"); versionText.textContent = `Version: ${currentVersion} - `; versionText.style.fontWeight = "bold"; versionText.style.fontSize = "15px"; const statusSpan = document.createElement("span"); statusSpan.style.fontSize = "15px"; if (currentVersion === latest) { statusSpan.textContent = "You are using the latest version."; statusSpan.style.color = "green"; } else if (compareVersions(currentVersion, latest) < 0) { statusSpan.textContent = "Please update this extension."; statusSpan.style.color = "red"; showUpdatePopup(oldMessage, latest); } else { statusSpan.textContent = "Invalid version."; statusSpan.style.color = "orange"; showUpdatePopup("Your extension version is invalid. Please update now.", latest); } statusLine.appendChild(versionText); statusLine.appendChild(statusSpan); statusLine.style.fontFamily = "Arial, sans-serif"; statusLine.style.paddingLeft = "10px"; container.appendChild(statusLine); }); function compareVersions(v1, v2) { const parts1 = v1.replace(/[^\d.]/g, "").split('.').map(Number); const parts2 = v2.replace(/[^\d.]/g, "").split('.').map(Number); const maxLen = Math.max(parts1.length, parts2.length); for (let i = 0; i < maxLen; i++) { const a = parts1[i] || 0; const b = parts2[i] || 0; if (a > b) return 1; if (a < b) return -1; } return 0; } function showUpdatePopup(message, latestVersion) { const popup = document.createElement("div"); popup.style.position = "fixed"; popup.style.top = "0"; popup.style.left = "0"; popup.style.width = "100%"; popup.style.height = "100%"; popup.style.backgroundColor = "rgba(0, 0, 0, 0.6)"; popup.style.zIndex = "9999"; popup.style.display = "flex"; popup.style.justifyContent = "center"; popup.style.alignItems = "center"; const box = document.createElement("div"); box.style.backgroundColor = "#fff"; box.style.padding = "20px"; box.style.borderRadius = "8px"; box.style.boxShadow = "0 0 20px rgba(0,0,0,0.3)"; box.style.textAlign = "center"; box.style.maxWidth = "400px"; box.style.width = "90%"; const title = document.createElement("h2"); title.textContent = "Please update this extension"; title.style.margin = "0px"; const versionInfo = document.createElement("p"); versionInfo.textContent = `Latest Version: ${latestVersion}`; versionInfo.style.fontWeight = "bold"; versionInfo.style.marginBottom = "8px"; versionInfo.style.color = "#007bff"; const msg = document.createElement("div"); msg.innerHTML = message; msg.style.marginBottom = "20px"; msg.style.color = "#333"; const btn = document.createElement("a"); btn.href = updateLink; btn.textContent = "Update Now"; btn.target = "_blank"; btn.style.backgroundColor = "#007bff"; btn.style.color = "#fff"; btn.style.padding = "10px 20px"; btn.style.borderRadius = "4px"; btn.style.textDecoration = "none"; btn.style.fontWeight = "bold"; box.appendChild(title); box.appendChild(versionInfo); box.appendChild(msg); box.appendChild(btn); popup.appendChild(box); document.body.appendChild(popup); } document.getElementById("openPopupTab").addEventListener("click", () => { chrome.tabs.create({ url: chrome.runtime.getURL("popup.html") }); }); (function () { const interval = setInterval(() => { const checkbox = document.getElementById('clearCheckbox'); const input1 = document.getElementById('irctc-login'); const input2 = document.getElementById('irctc-password'); if (!checkbox || !input1 || !input2) return; clearInterval(interval); const savedState = localStorage.getItem('irctcClearCheckbox'); if (savedState === 'checked') { checkbox.checked = true; clearAndDisableInputs(); } checkbox.addEventListener('change', function () { if (checkbox.checked) { clearAndDisableInputs(); localStorage.setItem('irctcClearCheckbox', 'checked'); } else { input1.disabled = false; input2.disabled = false; localStorage.setItem('irctcClearCheckbox', 'unchecked'); } }); function clearAndDisableInputs() { manuallyClear(input1); manuallyClear(input2); input1.disabled = true; input2.disabled = true; } function manuallyClear(input) { input.value = ''; input.dispatchEvent(new Event('input', { bubbles: true })); input.dispatchEvent(new Event('change', { bubbles: true })); } }, 300); })(); document.addEventListener("DOMContentLoaded", () => { chrome.storage.local.get(["plan_expiry"], (result) => { const expiryElement = document.getElementById("UserPlanExpairy"); if (expiryElement && result.plan_expiry !== undefined) { if (result.plan_expiry) { expiryElement.textContent = result.plan_expiry; const expiryDate = new Date(result.plan_expiry); const today = new Date(); expiryElement.style.color = today <= expiryDate ? "green" : "red"; } else { expiryElement.textContent = "User Not Found"; expiryElement.style.color = "orange"; } } }); }); document.addEventListener('DOMContentLoaded', function () { const checkbox = document.getElementById('submitBtn2autoClickCheckbox'); chrome.storage.sync.get(['submitBtn2autoClickEnabled'], function (result) { checkbox.checked = result.submitBtn2autoClickEnabled || false; }); checkbox.addEventListener('change', function () { chrome.storage.sync.set({ submitBtn2autoClickEnabled: checkbox.checked }, function () { console.log('Setting saved:', checkbox.checked); }); }); }); document.addEventListener("DOMContentLoaded", function () { var input = document.getElementById("cardexpiry"); if (input) { input.addEventListener("input", function (e) { var val = e.target.value.replace(/\D/g, ""); if (val.length > 4) val = val.slice(0, 4); if (val.length >= 3) { val = val.slice(0, 2) + "/" + val.slice(2); } e.target.value = val; }); } }); async function loadNotice() { try { const response = await fetch("https://shahidtatkal.github.io/accest/notice.json?nocache=" + new Date().getTime()); const data = await response.json(); const notice = data.notice; const container = document.getElementById('notice-container'); if (notice && notice.trim() !== "") { container.innerHTML = notice; container.style.display = "block"; } else { container.innerHTML = ""; container.style.display = "none"; } } catch (error) { console.error('Failed to fetch notice:', error); } } loadNotice();

document.getElementById('openPopupTab').addEventListener("click", () => {
  chrome.tabs.create({
    'url': chrome.runtime.getURL("popup.html")
  });
});
(function () {
  const _0x5999a9 = setInterval(() => {
    const _0x3281e6 = document.getElementById("clearCheckbox");
    const _0xcd0e5d = document.getElementById("irctc-login");
    const _0x521748 = document.getElementById("irctc-password");
    if (!_0x3281e6 || !_0xcd0e5d || !_0x521748) {
      return;
    }
    clearInterval(_0x5999a9);
    const _0x32c310 = localStorage.getItem("irctcClearCheckbox");
    if (_0x32c310 === "checked") {
      _0x3281e6.checked = true;
      _0x1e918e();
    }
    _0x3281e6.addEventListener('change', function () {
      if (_0x3281e6.checked) {
        _0x1e918e();
        localStorage.setItem("irctcClearCheckbox", "checked");
      } else {
        _0xcd0e5d.disabled = false;
        _0x521748.disabled = false;
        localStorage.setItem("irctcClearCheckbox", "unchecked");
      }
    });
    function _0x1e918e() {
      _0x3d1685(_0xcd0e5d);
      _0x3d1685(_0x521748);
      _0xcd0e5d.disabled = true;
      _0x521748.disabled = true;
    }
    function _0x3d1685(_0x55e019) {
      _0x55e019.value = '';
      _0x55e019.dispatchEvent(new Event('input', {
        'bubbles': true
      }));
      _0x55e019.dispatchEvent(new Event("change", {
        'bubbles': true
      }));
    }
  }, 0x12c);
})();
document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get(["plan_expiry"], _0x407aef => {
    const _0x2176cc = document.getElementById("UserPlanExpairy");
    if (_0x2176cc && _0x407aef.plan_expiry !== undefined) {
      if (_0x407aef.plan_expiry) {
        _0x2176cc.textContent = _0x407aef.plan_expiry;
        const _0x534afb = new Date(_0x407aef.plan_expiry);
        const _0x18a2f0 = new Date();
        _0x2176cc.style.color = _0x18a2f0 <= _0x534afb ? "green" : "red";
      } else {
        _0x2176cc.textContent = "User Not Found";
        _0x2176cc.style.color = "orange";
      }
    }
  });
});
document.addEventListener('DOMContentLoaded', function () {
  const _0x2cfa5e = document.getElementById("submitBtn2autoClickCheckbox");
  chrome.storage.sync.get(["submitBtn2autoClickEnabled"], function (_0x2d5f52) {
    _0x2cfa5e.checked = _0x2d5f52.submitBtn2autoClickEnabled || false;
  });
  _0x2cfa5e.addEventListener("change", function () {
    chrome.storage.sync.set({
      'submitBtn2autoClickEnabled': _0x2cfa5e.checked
    }, function () {
      console.log("Setting saved:", _0x2cfa5e.checked);
    });
  });
});
document.addEventListener('DOMContentLoaded', function () {
  var _0x4e15bf = document.getElementById("cardexpiry");
  if (_0x4e15bf) {
    _0x4e15bf.addEventListener("input", function (_0x314f5a) {
      var _0x59ff38 = _0x314f5a.target.value.replace(/\D/g, '');
      if (_0x59ff38.length > 0x4) {
        _0x59ff38 = _0x59ff38.slice(0x0, 0x4);
      }
      if (_0x59ff38.length >= 0x3) {
        _0x59ff38 = _0x59ff38.slice(0x0, 0x2) + '/' + _0x59ff38.slice(0x2);
      }
      _0x314f5a.target.value = _0x59ff38;
    });
  }
});