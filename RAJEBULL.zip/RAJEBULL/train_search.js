document.addEventListener("DOMContentLoaded", () => {
  const _0xbb3e10 = document.getElementById("search-trains-btn");
  if (_0xbb3e10) {
    _0xbb3e10.onclick = () => {
      console.log("Search button clicked. Preparing to open new window.");
      const _0x22c2da = document.getElementById("from-station-input").value;
      const _0x33d92a = document.getElementById("destination-station-input").value;
      const _0x1f4290 = document.getElementById("journey-date").value;
      if (!_0x22c2da || !_0x33d92a || !_0x1f4290) {
        alert("Please fill From, To, and Date fields first.");
        return;
      }
      const _0x6e2d0c = {
        'from': _0x22c2da,
        'to': _0x33d92a,
        'date': _0x1f4290
      };
      chrome.storage.local.set({
        'trainSearchQuery': _0x6e2d0c
      }, () => {
        chrome.windows.create({
          'url': "results.html",
          'type': 'popup',
          'width': 0x384,
          'height': 0x258
        });
      });
    };
  }
});