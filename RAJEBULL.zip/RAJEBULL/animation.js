let pageLoadTime = performance.now();
let statusTimerInterval;
function initOceanAnimation(_0x3210b1) {
  console.log("Initializing RAJEBULL Animation UI with data...", _0x3210b1);
  document.body.style.paddingBottom = "60px";
  createBottomBar(_0x3210b1.journeyDetails || {});
  createDynamicStatusBox();
  startPageTimer();
  if (_0x3210b1.initialStatus) {
    updateStatusBox(_0x3210b1.initialStatus);
  }
}
function createBottomBar(_0x2958e2) {
  if (document.getElementById("ocean-ui-container")) {
    document.getElementById("ocean-ui-container").remove();
  }
  const _0x2b99d1 = document.createElement('div');
  _0x2b99d1.id = "ocean-ui-container";
  let _0xf24926 = "N/A";
  if (_0x2958e2.from) {
    const _0x5111a4 = _0x2958e2.from.split('-');
    _0xf24926 = _0x5111a4.length > 0x1 ? _0x5111a4[0x1].trim() : _0x5111a4[0x0].trim();
  }
  let _0x28dfcb = 'N/A';
  if (_0x2958e2.destination) {
    const _0x313c0e = _0x2958e2.destination.split('-');
    _0x28dfcb = _0x313c0e.length > 0x1 ? _0x313c0e[0x1].trim() : _0x313c0e[0x0].trim();
  }
  const _0x262817 = _0x2958e2["train-no"]?.["split"]('-')[0x0]['trim']() || 'N/A';
  const _0x1d14c2 = _0x2958e2["class"] || "N/A";
  const _0xee023f = _0x2958e2.quota || 'N/A';
  const _0x2d6092 = _0x2958e2.username || "N/A";
  const _0x1e5b7c = [_0xf24926 + " - " + _0x28dfcb, _0x262817, _0xee023f, _0x1d14c2, _0x2d6092];
  const _0x3732b5 = _0x1e5b7c.join(" | ");
  _0x2b99d1.innerHTML = "\n        <div id=\"ocean-timer-wrapper\">\n            <span id=\"ocean-page-timer\">0s</span>\n        </div>\n        <div id=\"ocean-status-bar\">\n            " + _0x3732b5 + "\n        </div>\n    ";
  document.body.appendChild(_0x2b99d1);
}
function createDynamicStatusBox() {
  if (document.getElementById("ocean-dynamic-status-box")) {
    return;
  }
  const _0x5458f5 = document.createElement("div");
  _0x5458f5.id = "ocean-dynamic-status-box";
  _0x5458f5.innerText = "Initializing Automation...";
  document.body.appendChild(_0x5458f5);
}
function startPageTimer() {
  pageLoadTime = performance.now();
  if (statusTimerInterval) {
    clearInterval(statusTimerInterval);
  }
  statusTimerInterval = setInterval(() => {
    const _0x3a688f = document.getElementById("ocean-page-timer");
    if (_0x3a688f) {
      const _0x175bf9 = Math.round((performance.now() - pageLoadTime) / 0x3e8);
      _0x3a688f.textContent = _0x175bf9 + 's';
    }
  }, 0x3e8);
}
function updateStatusBox(_0x5c4dda) {
  const _0x2e61a1 = document.getElementById("ocean-dynamic-status-box");
  if (!_0x2e61a1) {
    console.warn("RAJEBULL Animation: Status box not found.");
    return;
  }
  const _0x250c19 = {
    'loadLoginDetails': "LOGIN PROCESS...",
    'loadJourneyDetails': "SUBMIT TRAIN INFO",
    'selectJourney': "FATCHING TRAIN INFO",
    'train-list': "TRAIN FILLUP",
    'fillPassengerDetails': "SUBMIT PAX DATA",
    'reviewBooking': "CAPTCHA AUTOFILL ",
    'bkgPaymentOptions': "REDIRECT TO BANK",
    'redirectToBank': "COLECTING PAYMENT INFO"
  };
  const _0x1f09b8 = _0x250c19[_0x5c4dda];
  if (_0x1f09b8) {
    _0x2e61a1.innerText = _0x1f09b8;
    _0x2e61a1.classList.add("active");
  } else {
    _0x2e61a1.classList.remove("active");
    if (_0x5c4dda !== "Keep listener alive.") {
      console.warn("REDBULL Animation: No display text found for status: " + _0x5c4dda);
    }
  }
}
document.addEventListener("ocean-init-data", _0x59c4c0 => {
  initOceanAnimation(_0x59c4c0.detail);
});
document.addEventListener("ocean-status-update", _0x207b41 => {
  if (_0x207b41.detail.statusKey === "Keep listener alive.") {
    return;
  }
  if (_0x207b41.detail?.["journeyDetails"]) {
    createBottomBar(_0x207b41.detail.journeyDetails);
  }
  startPageTimer();
  updateStatusBox(_0x207b41.detail.statusKey);
});