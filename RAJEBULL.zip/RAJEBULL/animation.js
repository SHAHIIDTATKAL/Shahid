let pageLoadTime = performance.now();
let statusTimerInterval;
function initOceanAnimation(_0x423ec1) {
  console.log("Initializing RAJEBULL TATKAL Animation UI with data...", _0x423ec1);
  document.body.style.paddingBottom = "60px";
  createBottomBar(_0x423ec1.journeyDetails || {});
  createDynamicStatusBox();
  startPageTimer();
  if (_0x423ec1.initialStatus) {
    updateStatusBox(_0x423ec1.initialStatus);
  }
}
function createBottomBar(_0x3f40a9) {
  if (document.getElementById("ocean-ui-container")) {
    document.getElementById("ocean-ui-container").remove();
  }
  const _0x2854a8 = document.createElement("div");
  _0x2854a8.id = "ocean-ui-container";
  let _0x297e8c = "N/A";
  if (_0x3f40a9.from) {
    const _0x408974 = _0x3f40a9.from.split('-');
    _0x297e8c = _0x408974.length > 0x1 ? _0x408974[0x1].trim() : _0x408974[0x0].trim();
  }
  let _0x2e4394 = 'N/A';
  if (_0x3f40a9.destination) {
    const _0x11fe4f = _0x3f40a9.destination.split('-');
    _0x2e4394 = _0x11fe4f.length > 0x1 ? _0x11fe4f[0x1].trim() : _0x11fe4f[0x0].trim();
  }
  const _0x2a0894 = _0x3f40a9["train-no"]?.['split']('-')[0x0]['trim']() || "N/A";
  const _0x3046ca = _0x3f40a9["class"] || "N/A";
  const _0x2ee5b1 = _0x3f40a9.quota || "N/A";
  const _0x5c85b8 = _0x3f40a9.username || "N/A";
  const _0x512225 = [_0x297e8c + " - " + _0x2e4394, _0x2a0894, _0x2ee5b1, _0x3046ca, _0x5c85b8];
  const _0x19cc00 = _0x512225.join(" | ");
  _0x2854a8.innerHTML = "\n        <div id=\"ocean-timer-wrapper\">\n            <span id=\"ocean-page-timer\">0s</span>\n        </div>\n        <div id=\"ocean-status-bar\">\n            " + _0x19cc00 + "\n        </div>\n    ";
  document.body.appendChild(_0x2854a8);
}
function createDynamicStatusBox() {
  if (document.getElementById("ocean-dynamic-status-box")) {
    return;
  }
  const _0x117256 = document.createElement("div");
  _0x117256.id = "ocean-dynamic-status-box";
  _0x117256.innerText = "Initializing Automation...";
  document.body.appendChild(_0x117256);
}
function startPageTimer() {
  pageLoadTime = performance.now();
  if (statusTimerInterval) {
    clearInterval(statusTimerInterval);
  }
  statusTimerInterval = setInterval(() => {
    const _0x47bb4a = document.getElementById('ocean-page-timer');
    if (_0x47bb4a) {
      const _0x458ef7 = Math.round((performance.now() - pageLoadTime) / 0x3e8);
      _0x47bb4a.textContent = _0x458ef7 + 's';
    }
  }, 0x3e8);
}
function updateStatusBox(_0x30fb82) {
  const _0x3334bf = document.getElementById("ocean-dynamic-status-box");
  if (!_0x3334bf) {
    console.warn("RAJEBULL TATKAL Animation: Status box not found.");
    return;
  }
  const _0x31e5af = {
    'loadLoginDetails': "LOGIN DETAILS FILL...",
    'loadJourneyDetails': "JOURNEY DETAILS FILL...",
    'selectJourney': "TRAIN FATCHING...",
    'train-list': "TRAIN PROCESS...",
    'fillPassengerDetails': "SUBMIT PAX DATA...",
    'reviewBooking': "CVERIFY FINAL CAPTCHA...",
    'bkgPaymentOptions': "REDIRECT TO BANK...",
    'redirectToBank': "REDIRECT TO BANK ..."
  };
  const _0xf0b65d = _0x31e5af[_0x30fb82];
  if (_0xf0b65d) {
    _0x3334bf.innerText = _0xf0b65d;
    _0x3334bf.classList.add("active");
  } else {
    _0x3334bf.classList.remove("active");
    if (_0x30fb82 !== "Keep listener alive.") {
      console.warn("RAJEBULL TATKAL Animation: No display text found for status: " + _0x30fb82);
    }
  }
}
document.addEventListener("ocean-init-data", _0x5d2db4 => {
  initOceanAnimation(_0x5d2db4.detail);
});
document.addEventListener('ocean-status-update', _0xabe75c => {
  if (_0xabe75c.detail.statusKey === "Keep listener alive.") {
    return;
  }
  if (_0xabe75c.detail?.["journeyDetails"]) {
    createBottomBar(_0xabe75c.detail.journeyDetails);
  }
  startPageTimer();
  updateStatusBox(_0xabe75c.detail.statusKey);
});