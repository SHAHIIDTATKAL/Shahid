function applyProxyFromSettings(settings) {
  const _0x461cd4 = parseInt(settings.activeProxy, 0xa) - 0x1;
  if (isNaN(_0x461cd4) || !settings.proxies || !settings.proxies[_0x461cd4]) {
    console.error("❌ Invalid proxy configuration", {
      'activeIndex': _0x461cd4,
      'hasProxies': !!settings.proxies,
      'proxiesLength': settings.proxies?.["length"] || 0x0
    });
    chrome.proxy.settings.clear({
      'scope': "regular"
    });
    return;
  }
  const _0x2518bb = settings.proxies[_0x461cd4];
  if (!_0x2518bb.ip || !_0x2518bb.port) {
    console.warn("⚠️ Active proxy missing IP or Port - clearing proxy", {
      'proxyIndex': _0x461cd4,
      'hasIp': !!_0x2518bb.ip,
      'hasPort': !!_0x2518bb.port
    });
    chrome.proxy.settings.clear({
      'scope': "regular"
    });
    return;
  }
  const _0x19405f = {
    'mode': "fixed_servers",
    'rules': {
      'singleProxy': {
        'scheme': 'http',
        'host': _0x2518bb.ip,
        'port': parseInt(_0x2518bb.port, 0xa)
      },
      'bypassList': ["<local>"]
    }
  };
  chrome.proxy.settings.set({
    'value': _0x19405f,
    'scope': "regular"
  }, () => {
    if (chrome.runtime.lastError) {
      console.error("❌ Failed to set proxy settings", {
        'error': chrome.runtime.lastError.message,
        'proxyConfig': {
          'ip': _0x2518bb.ip,
          'port': _0x2518bb.port
        }
      });
    } else {
      console.info("🌐 Proxy settings applied successfully", {
        'proxyHost': _0x2518bb.ip + ':' + _0x2518bb.port,
        'proxyIndex': _0x461cd4
      });
    }
  });
}
function applyProxyFromConfig(proxyConfig) {
  if (!proxyConfig.proxyIp || !proxyConfig.proxyPort) {
    console.warn("⚠️ Proxy config missing IP or Port - clearing proxy", {
      'hasIp': !!proxyConfig.proxyIp,
      'hasPort': !!proxyConfig.proxyPort
    });
    chrome.proxy.settings.clear({
      'scope': "regular"
    });
    return;
  }
  const _0x3afd2d = {
    'mode': "fixed_servers",
    'rules': {
      'singleProxy': {
        'scheme': "http",
        'host': proxyConfig.proxyIp,
        'port': parseInt(proxyConfig.proxyPort, 0xa)
      },
      'bypassList': ["<local>"]
    }
  };
  chrome.proxy.settings.set({
    'value': _0x3afd2d,
    'scope': "regular"
  }, () => {
    if (chrome.runtime.lastError) {
      console.error("❌ Failed to set proxy config settings", {
        'error': chrome.runtime.lastError.message,
        'proxyConfig': {
          'ip': proxyConfig.proxyIp,
          'port': proxyConfig.proxyPort
        }
      });
    } else {
      console.info("🌐 Proxy config applied successfully", {
        'proxyHost': proxyConfig.proxyIp + ':' + proxyConfig.proxyPort,
        'hasAuth': !!(proxyConfig.proxyUsername && proxyConfig.proxyPassword)
      });
    }
  });
}
function applyProxySettings() {
  chrome.storage.local.get(["proxy_settings", "proxy_config"], _0x33aeae => {
    const settings = _0x33aeae.proxy_settings;
    const proxyConfig = _0x33aeae.proxy_config;
    console.debug("🔍 Retrieved proxy storage data", {
      'hasProxySettings': !!settings,
      'hasProxyConfig': !!proxyConfig,
      'activeProxy': settings?.["activeProxy"],
      'enableProxy': proxyConfig?.["enableProxy"]
    });
    if (settings && settings.activeProxy !== "disabled") {
      console.debug("🔧 Using proxy_settings system");
      applyProxyFromSettings(settings);
      return;
    }
    if (proxyConfig && proxyConfig.enableProxy) {
      console.debug("🔧 Using proxy_config system as fallback");
      applyProxyFromConfig(proxyConfig);
      return;
    }
    console.info("🔄 Clearing proxy settings - disabled or no settings");
    chrome.proxy.settings.clear({
      'scope': "regular"
    }, () => {
      console.info("✅ Proxy settings cleared successfully");
    });
  });
}
function disableRegularAuthHandler() {
  try {
    chrome.webRequest.onAuthRequired.removeListener(null);
    console.debug("🔧 Regular auth handler temporarily disabled");
    return true;
  } catch (error) {
    console.warn("⚠️ Error disabling regular auth handler", {
      'error': error.message
    });
    return false;
  }
  return false;
}
function enableRegularAuthHandler() {
  try {
    chrome.webRequest.onAuthRequired.addListener(null, {
      'urls': ["<all_urls>"]
    }, ["asyncBlocking"]);
    console.debug("🔧 Regular auth handler re-enabled");
    return true;
  } catch (error) {
    console.warn("⚠️ Error re-enabling regular auth handler", {
      'error': error.message
    });
    return false;
  }
  return false;
}
async function testProxyConnectivity(proxy) {
  console.info("🧪 Testing proxy connectivity", {
    'proxyHost': proxy.ip + ':' + proxy.port,
    'hasAuth': !!(proxy.user && proxy.pass),
    'userLength': proxy.user ? proxy.user.length : 0x0,
    'passLength': proxy.pass ? proxy.pass.length : 0x0
  });
  const _0xa1e215 = {
    'mode': "fixed_servers",
    'rules': {
      'singleProxy': {
        'scheme': "http",
        'host': proxy.ip,
        'port': parseInt(proxy.port, 0xa)
      },
      'bypassList': ["<local>"]
    }
  };
  let _0x55fc62 = false;
  let _0x4b0be6 = '';
  let _0x59c347 = null;
  let _0x54fe0f = false;
  try {
    if (proxy.user && proxy.pass) {
      console.debug("🔐 Setting up temporary auth handler for proxy test", {
        'hasUser': !!proxy.user,
        'hasPass': !!proxy.pass
      });
      const regularHandlerDisabled = disableRegularAuthHandler();
      console.debug("🔧 Regular handler disabled for test", {
        'success': regularHandlerDisabled
      });
      _0x59c347 = function (details, _0x55e6c3) {
        console.info("🔐 Test proxy auth challenge received", {
          'url': details.url,
          'challenger': details.challenger,
          'isProxy': details.isProxy,
          'scheme': details.scheme,
          'realm': details.realm
        });
        if (details.isProxy) {
          console.info("✅ Providing credentials for proxy test authentication", {
            'username': proxy.user,
            'hasPassword': !!proxy.pass
          });
          _0x54fe0f = true;
          _0x55e6c3({
            'authCredentials': {
              'username': proxy.user,
              'password': proxy.pass
            }
          });
        } else {
          console.debug("🔐 Not a proxy auth challenge, ignoring");
          _0x55e6c3({});
        }
      };
      chrome.webRequest.onAuthRequired.addListener(_0x59c347, {
        'urls': ["<all_urls>"]
      }, ["asyncBlocking"]);
      console.debug("🔧 Temporary auth handler registered, waiting for setup");
      await new Promise(_0x8ab697 => setTimeout(_0x8ab697, 0xc8));
    }
    await new Promise((_0x49f871, _0x8ab98e) => {
      chrome.proxy.settings.set({
        'value': _0xa1e215,
        'scope': "regular"
      }, () => {
        if (chrome.runtime.lastError) {
          const error = new Error("Failed to set proxy settings: " + chrome.runtime.lastError.message);
          console.error("❌ Proxy test setup failed", {
            'error': chrome.runtime.lastError.message,
            'proxyHost': proxy.ip + ':' + proxy.port
          });
          _0x8ab98e(error);
        } else {
          console.debug("✅ Temporary proxy set for testing", {
            'proxyHost': proxy.ip + ':' + proxy.port
          });
          _0x49f871();
        }
      });
    });
    const _0x4923fe = new AbortController();
    const timeoutId = self.setTimeout(() => _0x4923fe.abort(), 0x2710);
    try {
      console.debug("🧪 Making test request through proxy", {
        'url': "https://www.google.com/generate_204",
        'proxyHost': proxy.ip + ':' + proxy.port,
        'hasAuth': !!(proxy.user && proxy.pass)
      });
      const _0x5d5ec8 = await fetch("https://www.google.com/generate_204", {
        'signal': _0x4923fe.signal
      });
      self.clearTimeout(timeoutId);
      console.debug("🧪 Test request completed", {
        'status': _0x5d5ec8.status,
        'statusText': _0x5d5ec8.statusText,
        'ok': _0x5d5ec8.ok
      });
      if (_0x5d5ec8.status === 0xcc) {
        _0x55fc62 = true;
        _0x4b0be6 = "Proxy is working.";
        console.info("✅ Proxy connectivity test passed", {
          'proxyHost': proxy.ip + ':' + proxy.port,
          'responseStatus': _0x5d5ec8.status
        });
      } else if (_0x5d5ec8.status === 0x197) {
        _0x55fc62 = false;
        if (proxy.user && proxy.pass) {
          if (_0x54fe0f) {
            _0x4b0be6 = "Proxy authentication failed. Username or password may be incorrect.";
            console.warn("🔐 Proxy authentication failed during test (credentials were provided)", {
              'proxyHost': proxy.ip + ':' + proxy.port,
              'status': _0x5d5ec8.status,
              'hasCredentials': true,
              'authAttempted': true
            });
          } else {
            _0x4b0be6 = "Proxy authentication handler was not called. This may be a timing issue.";
            console.warn("🔐 Proxy auth handler not triggered despite credentials", {
              'proxyHost': proxy.ip + ':' + proxy.port,
              'status': _0x5d5ec8.status,
              'hasCredentials': true,
              'authAttempted': false
            });
          }
        } else {
          _0x4b0be6 = "Proxy requires authentication. Please provide username and password.";
          console.warn("🔐 Proxy requires authentication but no credentials provided", {
            'proxyHost': proxy.ip + ':' + proxy.port,
            'status': _0x5d5ec8.status
          });
        }
      } else {
        _0x55fc62 = false;
        _0x4b0be6 = "Proxy returned unexpected status: " + _0x5d5ec8.status;
        console.warn("⚠️ Proxy test returned unexpected status", {
          'proxyHost': proxy.ip + ':' + proxy.port,
          'status': _0x5d5ec8.status
        });
      }
    } catch (fetchError) {
      self.clearTimeout(timeoutId);
      if (fetchError.name === "AbortError") {
        _0x4b0be6 = "Proxy test timed out (10 seconds).";
        console.warn("⏰ Proxy test timed out", {
          'proxyHost': proxy.ip + ':' + proxy.port,
          'timeout': "10 seconds"
        });
      } else if (fetchError.message.includes("ERR_NO_SUPPORTED_PROXIES")) {
        _0x4b0be6 = "Proxy requires authentication or is unreachable. Please check username/password or IP/port.";
        console.error("🔐 Proxy authentication or connectivity issue", {
          'proxyHost': proxy.ip + ':' + proxy.port,
          'error': fetchError.message
        });
      } else {
        _0x4b0be6 = "Network error or proxy unreachable: " + fetchError.message;
        console.error("🌐 Network error during proxy test", {
          'proxyHost': proxy.ip + ':' + proxy.port,
          'error': fetchError.message
        });
      }
      _0x55fc62 = false;
    }
  } catch (proxyError) {
    _0x55fc62 = false;
    _0x4b0be6 = proxyError.message;
    console.error("❌ Proxy test failed with error", {
      'proxyHost': proxy.ip + ':' + proxy.port,
      'error': proxyError.message
    });
  } finally {
    if (_0x59c347) {
      try {
        chrome.webRequest.onAuthRequired.removeListener(_0x59c347);
        console.debug("🧹 Temporary auth handler removed after test");
      } catch (removeError) {
        console.warn("⚠️ Error removing temporary auth handler", {
          'error': removeError.message
        });
      }
      const regularHandlerReEnabled = enableRegularAuthHandler();
      console.debug("🔧 Regular handler re-enabled after test", {
        'success': regularHandlerReEnabled
      });
    }
    await new Promise(_0x5b879c => {
      chrome.proxy.settings.clear({
        'scope': "regular"
      }, () => {
        console.debug("🧹 Temporary proxy settings cleared after test");
        _0x5b879c();
      });
    });
  }
  console.info("🧪 Proxy connectivity test completed", {
    'proxyHost': proxy.ip + ':' + proxy.port,
    'success': _0x55fc62,
    'message': _0x4b0be6
  });
  return {
    'success': _0x55fc62,
    'message': _0x4b0be6
  };
}
chrome.webRequest.onAuthRequired.addListener((details, _0x50a9ec) => {
  console.log("Proxy authentication required:", details);
  chrome.storage.local.get("proxy_settings", _0x1f2a86 => {
    const settings = _0x1f2a86.proxy_settings;
    if (settings && settings.activeProxy !== "disabled") {
      const _0x9a0b15 = parseInt(settings.activeProxy, 0xa) - 0x1;
      const proxy = settings.proxies[_0x9a0b15];
      if (proxy && proxy.user && proxy.pass) {
        _0x50a9ec({
          'authCredentials': {
            'username': proxy.user,
            'password': proxy.pass
          }
        });
      } else {
        _0x50a9ec({
          'cancel': true
        });
      }
    } else {
      _0x50a9ec({
        'cancel': true
      });
    }
  });
  return {
    'cancel': false
  };
}, {
  'urls': ["<all_urls>"]
}, ["asyncBlocking"]);
applyProxySettings();
let tabDetails;
let status_updates = {};
function getMsg(_0x181bc6, _0x18598c) {
  return {
    'msg': {
      'type': _0x181bc6,
      'data': _0x18598c
    },
    'sender': 'popup',
    'id': "irctc"
  };
}
chrome.runtime.onMessage.addListener((_0x317ebf, _0x1e8c4d, _0x4e90fb) => {
  if (_0x317ebf.type === "FETCH_TRAIN_LIST" && _0x317ebf.url) {
    console.log("Background: Handling FETCH_TRAIN_LIST for URL:", _0x317ebf.url);
    fetch(_0x317ebf.url).then(_0x495961 => {
      if (!_0x495961.ok) {
        throw new Error("HTTP error! Status: " + _0x495961.status);
      }
      return _0x495961.text();
    }).then(_0x2f8e63 => {
      console.log("Background: Train list fetch SUCCESS. Sending response to popup.");
      _0x4e90fb({
        'success': true,
        'data': _0x2f8e63
      });
    })['catch'](_0x557add => {
      console.error("Background: Train list fetch FAILED. Error:", _0x557add);
      _0x4e90fb({
        'success': false,
        'error': _0x557add.message
      });
    });
    return true;
  }
  if (_0x317ebf.action === "checkProxyConnectivity") {
    console.log("Received request to check proxy connectivity:", _0x317ebf.proxy);
    testProxyConnectivity(_0x317ebf.proxy).then(_0x5b469c => {
      _0x4e90fb(_0x5b469c);
    });
    return true;
  }
  if (_0x317ebf.action === "updateProxy") {
    console.log("Received request to update proxy.");
    applyProxySettings();
    _0x4e90fb({
      'status': "Proxy settings updated."
    });
    return true;
  }
  if ("irctc" !== _0x317ebf.id) {
    _0x4e90fb("Invalid Id");
    return true;
  }
  let _0x10b3b2 = _0x317ebf.msg.type;
  let _0x1e9387 = _0x317ebf.msg.data;
  if ("activate_script" === _0x10b3b2) {
    if (_0x1e9387.fare_limit?.["bookInPopup"]) {
      chrome.windows.create({
        'url': "https://www.irctc.co.in/nget/train-search",
        'type': "popup",
        'width': 0x200,
        'height': 0x338
      }, _0x2b797c => {
        if (chrome.runtime.lastError) {
          console.error("[background_script.js] Error creating window:", chrome.runtime.lastError.message);
          _0x4e90fb("Error creating window: " + chrome.runtime.lastError.message);
          return;
        }
        if (_0x2b797c && _0x2b797c.tabs && _0x2b797c.tabs.length > 0x0) {
          tabDetails = _0x2b797c.tabs[0x0];
          chrome.scripting.executeScript({
            'target': {
              'tabId': tabDetails.id
            },
            'files': ["./content_script.js"]
          }, () => {
            if (chrome.runtime.lastError) {
              console.error("[background_script.2A42.js] Error injecting script into window:", chrome.runtime.lastError.message);
              _0x4e90fb("Error injecting script: " + chrome.runtime.lastError.message);
            } else {
              console.log("[background_script.js] Script activated in new window, tab ID:", tabDetails.id);
              _0x4e90fb("Script activated in new window");
            }
          });
        } else {
          console.error("[background_script.js] Failed to create popup window or get its tab details.");
          _0x4e90fb("Failed to activate script in popup window.");
        }
      });
    } else {
      chrome.tabs.create({
        'url': "https://www.irctc.co.in/nget/train-search"
      }, _0x268f86 => {
        if (chrome.runtime.lastError) {
          console.error("[background_script.js] Error creating tab:", chrome.runtime.lastError.message);
          _0x4e90fb("Error creating tab: " + chrome.runtime.lastError.message);
          return;
        }
        tabDetails = _0x268f86;
        chrome.scripting.executeScript({
          'target': {
            'tabId': tabDetails.id
          },
          'files': ["./content_script.js"]
        }, () => {
          if (chrome.runtime.lastError) {
            console.error("[background_script.js] Error injecting script into tab:", chrome.runtime.lastError.message);
            _0x4e90fb("Error injecting script: " + chrome.runtime.lastError.message);
          } else {
            console.log("[background_script.js] Script activated in new tab, tab ID:", tabDetails.id);
            _0x4e90fb("Script activated in new tab");
          }
        });
      });
    }
    return true;
  } else {
    if ("status_update" === _0x10b3b2) {
      const _0x39380a = _0x1e8c4d.tab?.['id'] || "popup_or_unknown";
      status_updates[_0x39380a] = status_updates[_0x39380a] || [];
      status_updates[_0x39380a].push({
        'sender': _0x1e8c4d,
        'data': _0x1e9387
      });
      _0x4e90fb("Status received");
    } else {
      _0x4e90fb("Something went wrong with message type");
    }
  }
  return true;
});
chrome.tabs.onUpdated.addListener((_0x3437d4, _0x1a22bc, _0x52ff32) => {
  if (_0x1a22bc?.["status"] !== "complete" || !_0x52ff32.url) {
    return;
  }
  const _0x41e3fd = _0x52ff32.url;
  let _0x14dbfd = null;
  let _0x3eb71b = null;
  let _0x3b389e = false;
  if (tabDetails && _0x3437d4 === tabDetails.id) {
    _0x3eb71b = tabDetails.id;
    console.log("[background_script.js] Main tab (" + _0x3eb71b + ") updated: " + _0x41e3fd);
    if (_0x41e3fd.includes("booking/train-list")) {
      _0x14dbfd = "selectJourney";
      _0x3b389e = true;
    } else if (_0x41e3fd.includes("booking/psgninput")) {
      _0x14dbfd = "fillPassengerDetails";
      _0x3b389e = true;
    } else if (_0x41e3fd.includes("booking/reviewBooking")) {
      _0x14dbfd = "reviewBooking";
      _0x3b389e = true;
    } else if (_0x41e3fd.includes("payment/bkgPaymentOptions")) {
      console.log("[background_script.js] Payment options page detected on main tab by URL:", _0x41e3fd);
      _0x14dbfd = "bkgPaymentOptions";
      _0x3b389e = true;
    }
  }
  if (_0x3b389e && _0x14dbfd && _0x3eb71b) {
    console.log("[background_script.js] Sending (main flow) " + _0x14dbfd + " to tab " + _0x3eb71b + " for URL: " + _0x41e3fd);
    chrome.tabs.sendMessage(_0x3eb71b, {
      'msg': {
        'type': _0x14dbfd,
        'data': null
      },
      'sender': 'popup',
      'id': "irctc"
    }).then(_0x3e09b1 => console.log("[background_script.js] (Main flow) " + _0x14dbfd + " message acknowledged by tab " + _0x3eb71b + ':', _0x3e09b1))['catch'](_0x2bcf99 => console.warn("[background_script.js] (Main flow) Error sending " + _0x14dbfd + " to tab " + _0x3eb71b + ':', _0x2bcf99.message));
  }
  if (_0x41e3fd.startsWith("https://www.irctc.co.in/") && (_0x41e3fd.includes("booking/train-ticket") || _0x41e3fd.includes("eticket") || _0x41e3fd.includes("booking-confirm"))) {
    console.log("[background_script.js] PNR page detected on tab " + _0x3437d4 + ": " + _0x41e3fd + '.');
    chrome.scripting.executeScript({
      'target': {
        'tabId': _0x3437d4
      },
      'files': ["./content_script.js"]
    }, _0x5380b5 => {
      if (chrome.runtime.lastError) {
        console.warn("[background_script.js] executeScript on PNR tab " + _0x3437d4 + " had an issue (might be ok if already injected): " + chrome.runtime.lastError.message);
      } else {
        console.log("[background_script.js] Content script ensured on PNR tab " + _0x3437d4 + '.');
      }
      setTimeout(() => {
        console.log("[background_script.js] Sending showPnrAnimation to tab " + _0x3437d4);
        chrome.tabs.sendMessage(_0x3437d4, {
          'msg': {
            'type': "showPnrAnimation",
            'data': null
          },
          'sender': 'popup',
          'id': "irctc"
        }).then(_0x510426 => console.log("[background_script.js] showPnrAnimation message acknowledged by tab " + _0x3437d4 + ':', _0x510426))['catch'](_0x1ae753 => console.warn("[background_script.js] Error sending showPnrAnimation to tab " + _0x3437d4 + " (content script might not be listening, or tab closed):", _0x1ae753.message));
      }, 0xfa);
    });
  }
});