<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'] ?? '';
    $new_password = $_POST['new_password'] ?? '';

    if (empty($user_id) || empty($new_password)) {
        header("location: " . $_SERVER['HTTP_REFERER'] . "?error=" . urlencode("User or password missing!"));
        exit;
    }

    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    $sql = "UPDATE users SET password = ? WHERE id = ?";
    if ($stmt = mysqli_prepare($link, $sql)) {
        mysqli_stmt_bind_param($stmt, "si", $hashed_password, $user_id);
        if (mysqli_stmt_execute($stmt)) {
            header("location: " . $_SERVER['HTTP_REFERER'] . "?msg=" . urlencode("Password changed successfully!"));
            exit;
        } else {
            header("location: " . $_SERVER['HTTP_REFERER'] . "?error=" . urlencode("Failed to update password."));
            exit;
        }
        mysqli_stmt_close($stmt);
    } else {
        header("location: " . $_SERVER['HTTP_REFERER'] . "?error=" . urlencode("Failed to prepare statement."));
        exit;
    }
}
?>