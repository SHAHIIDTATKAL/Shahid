<?php
// master_dashboard.php - Master Admin Panel UI
session_start();

// Check if the user is logged in and is a Master
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['account_type'] !== 'Master') {
    header("location: login.php"); // Redirect to login if not logged in or not Master
    exit;
}

// Include database connection
require_once 'config.php';

// Variables for messages and errors
$message = '';
$error = '';

// Fetch all license keys
$licenses = [];
$sql_licenses = "SELECT * FROM licenses ORDER BY created_at DESC";
if ($result_licenses = mysqli_query($link, $sql_licenses)) {
    while ($row = mysqli_fetch_assoc($result_licenses)) {
        // Add a status field to indicate if the key is expired
        $row['status'] = (strtotime($row['expiry_date']) < strtotime(date('Y-m-d'))) ? 'Expired' : 'Active';
        $licenses[] = $row;
    }
    mysqli_free_result($result_licenses);
} else {
    $error = "Failed to retrieve license keys: " . mysqli_error($link);
}

// Fetch all users
$users = [];
$sql_users = "SELECT id, username, account_type, created_at FROM users ORDER BY created_at DESC";
if ($result_users = mysqli_query($link, $sql_users)) {
    while ($row = mysqli_fetch_assoc($result_users)) {
        $users[] = $row;
    }
    mysqli_free_result($result_users);
} else {
    $error = "Failed to retrieve users: " . mysqli_error($link);
}

// Fetch all Admins
$sql_admins = "SELECT username, credits, created_at FROM users WHERE account_type = 'Admin' ORDER BY created_at DESC";
$admins = [];
if ($result_admins = mysqli_query($link, $sql_admins)) {
    while ($row = mysqli_fetch_assoc($result_admins)) {
        // Fetch total used
        $sql_used = "SELECT SUM(amount) as used FROM credit_transactions WHERE admin_username = ?";
        $stmt_used = mysqli_prepare($link, $sql_used);
        mysqli_stmt_bind_param($stmt_used, "s", $row['username']);
        mysqli_stmt_execute($stmt_used);
        mysqli_stmt_bind_result($stmt_used, $used);
        mysqli_stmt_fetch($stmt_used);
        mysqli_stmt_close($stmt_used);
        $row['used'] = $used ?: 0;
        $admins[] = $row;
    }
    mysqli_free_result($result_admins);
}

// Display messages after MAC ID reset or key generation or status toggle or user creation
if (isset($_GET['msg']) && $_GET['msg'] === 'mac_reset_success') {
    $message = "MAC ID successfully reset!";
} elseif (isset($_GET['msg']) && $_GET['msg'] === 'key_created_success') {
    $message = "New license key successfully created!";
    if (isset($_GET['new_key'])) {
        $message .= " New Key: <strong>" . htmlspecialchars($_GET['new_key']) . "</strong>";
    }
} elseif (isset($_GET['msg']) && strpos($_GET['msg'], 'License key status successfully changed!') !== false) {
    $message = htmlspecialchars($_GET['msg']);
} elseif (isset($_GET['msg']) && $_GET['msg'] === 'user_created_success') {
    $message = "New user created successfully!";
}
elseif (isset($_GET['error'])) {
    $error = htmlspecialchars($_GET['error']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master License Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(135deg, #e0f2f7 0%, #c1e4f4 100%);
            font-family: 'Poppins', 'Inter', sans-serif;
            position: relative;
            z-index: 1;
            flex-direction: column;
            overflow-x: hidden;
        }
        .dashboard-container {
            max-width: 1300px;
            width: 95%;
            background: rgba(255,255,255,0.9);
            border-radius: 30px;
            padding: 40px 50px;
            border: 1px solid rgba(220,220,220,0.5);
            box-shadow: 0 15px 45px rgba(0,0,0,0.1), 0 8px 20px rgba(0,0,0,0.05);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            position: relative;
            z-index: 10;
            box-sizing: border-box;
            display: flex;
            gap: 40px;
            overflow: hidden;
        }
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, #f0f8ff 0%, #e0f2f7 100%);
            color: #333;
            padding: 30px 25px;
            border-radius: 25px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            flex-shrink: 0;
            position: sticky;
            top: 20px;
            height: calc(100vh - 40px);
            max-height: 750px;
            overflow-y: auto;
            border: 1px solid rgba(220,220,220,0.5);
        }
        .sidebar h2 {
            color: #007bff;
            text-align: center;
            margin-bottom: 50px;
            font-size: 2.2em;
            font-weight: 800;
            letter-spacing: 1px;
            text-shadow: 0 0 5px rgba(0,123,255,0.2);
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin-bottom: 30px;
            flex-grow: 1;
        }
        .sidebar ul li {
            margin-bottom: 10px;
        }
        .sidebar ul li a {
            display: flex;
            align-items: center;
            padding: 12px 18px;
            color: #555;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
            gap: 15px;
        }
        .sidebar ul li a .icon {
            font-size: 1.3em;
            color: #888;
        }
        .sidebar ul li a:hover {
            background: rgba(0, 123, 255, 0.1);
            color: #007bff;
            transform: translateX(5px);
        }
        .sidebar ul li a.active {
            background: linear-gradient(45deg, #007bff, #0056b3);
            color: #fff;
            box-shadow: 0 4px 15px rgba(0, 123, 255, 0.3);
            transform: translateX(5px);
        }
        .sidebar ul li a.active .icon {
            color: #fff;
        }
        .sidebar .logout-section {
            padding-top: 20px;
            border-top: 1px solid rgba(0,0,0,0.05);
        }
        .sidebar .logout-section a {
            background: #dc3545;
            color: #fff;
            justify-content: center;
            padding: 12px 0;
            border-radius: 12px;
            transition: background 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            font-weight: 600;
        }
        .sidebar .logout-section a:hover {
            background: #c82333;
            transform: none;
        }
        .main-content {
            flex-grow: 1;
            padding: 0px;
            overflow-y: auto;
            max-height: 750px;
        }
        .info-header {
            background: linear-gradient(45deg, #007bff, #0056b3);
            color: #fff;
            padding: 30px 40px;
            border-radius: 20px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 123, 255, 0.2);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .info-header h1 {
            margin: 0;
            font-size: 2.5em;
            font-weight: 700;
        }
        .info-header p {
            margin: 5px 0 0;
            font-size: 1.1em;
            opacity: 0.9;
        }
        .info-header .profile-info {
            text-align: right;
        }
        .info-header .profile-info span {
            display: block;
            font-size: 1.2em;
            font-weight: 600;
        }
        .info-header .profile-info small {
            font-size: 0.9em;
            opacity: 0.8;
        }
        .dashboard-section {
            background: #ffffff;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.08);
            margin-bottom: 30px;
            border: 1px solid rgba(220, 220, 220, 0.5);
            animation: fadeIn 0.5s ease-out forwards;
        }
        .dashboard-section h3 {
            color: #333;
            font-size: 1.8em;
            margin-bottom: 25px;
            border-bottom: 2px solid #eee;
            padding-bottom: 15px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
        }
        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group input[type="password"],
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 1em;
            box-sizing: border-box;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .form-group input[type="text"]:focus,
        .form-group input[type="date"]:focus,
        .form-group input[type="password"]:focus,
        .form-group select:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.2);
            outline: none;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.1em;
            font-weight: 600;
            transition: background-color 0.3s ease, transform 0.2s ease;
            display: inline-block;
            margin-top: 10px;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }
        .btn-danger {
            background-color: #dc3545;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1em;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
        .btn-toggle-active {
            background-color: #17a2b8; /* Info blue */
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1em;
            font-weight: 600;
            transition: background-color 0.3s ease;
            margin-left: 5px; /* Add some spacing */
        }
        .btn-toggle-active:hover {
            background-color: #138496;
        }
        .message-success {
            color: #28a745;
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 500;
        }
        .message-error {
            color: #dc3545;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 500;
        }
        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-top: 20px;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        thead th {
            background-color: #f8f9fa;
            color: #666;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.9em;
        }
        tbody tr:last-child td {
            border-bottom: none;
        }
        tbody tr:hover {
            background-color: #f0f8ff;
        }
        /* New style for expired status */
        .status-expired {
            background-color: #fbd7da; /* Light red */
            color: #8c0000; /* Darker red */
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
        }
        /* New style for active status */
        .status-active {
            background-color: #d4edda; /* Light green */
            color: #155724; /* Darker green */
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
        }
        .status-inactive {
            background-color: #e2e6ea; /* Light grey */
            color: #495057; /* Darker grey */
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<div class="dashboard-container">
    <aside class="sidebar">
        <div>
            <h2>Master</h2>
            <ul>
                <li><a href="#" class="active" onclick="showSection('licenseSection'); return false;"><i class="fas fa-key icon"></i> Manage Licenses </a></li>
                <li><a href="#" onclick="showSection('createUserSection'); return false;"><i class="fas fa-user-plus icon"></i> Create User </a></li>
                <li><a href="#" onclick="showSection('manageUsersSection'); return false;"><i class="fas fa-users icon"></i> Manage Users </a></li>
            </ul>
        </div>
        <div class="logout-section">
            <a href="logout.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
        </div>
    </aside>
    <main class="main-content">
        <div class="info-header">
            <div>
                <h1>Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?>!</h1>
                <p><?php echo htmlspecialchars($_SESSION["account_type"]); ?> Panel </p>
            </div>
            <div class="profile-info">
                <span><?php echo htmlspecialchars($_SESSION["account_type"]); ?> Account</span>
                <?php
                    $wallet = 0;
                    $sql_wallet = "SELECT wallet FROM users WHERE id = ?";
                    if ($stmt_wallet = mysqli_prepare($link, $sql_wallet)) {
                        mysqli_stmt_bind_param($stmt_wallet, "i", $_SESSION['id']);
                        mysqli_stmt_execute($stmt_wallet);
                        mysqli_stmt_bind_result($stmt_wallet, $wallet);
                        mysqli_stmt_fetch($stmt_wallet);
                        mysqli_stmt_close($stmt_wallet);
                    }
                ?>
                <small style="display:block;margin-top:8px;">
                    <strong>Wallet:</strong> <?php echo (int)$wallet; ?>
                </small>
            </div>
        </div>
        
        <section id="licenseSection" class="dashboard-section">
            <h3>License Key Admin Panel</h3>
            <?php if ($message): ?>
                <div class="message-success"><?php echo $message; ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="message-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <h4 style="margin-top:30px;">Create New License Key</h4>
            <form action="generate_key.php" method="POST" style="margin-bottom:30px;">
                <div class="form-group">
                    <label for="new_license_key">Enter your license key:</label>
                    <input type="text" id="new_license_key" name="new_license_key" placeholder="KEY" required>
                </div>
     <button type="submit" class="btn-primary">Create Key</button>
            </form>

            <h4>Existing License Keys</h4>
            <?php if (empty($licenses)): ?>
                <p>No license keys found.</p>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>Key</th>
                                <th>Expiry Date</th>
                                <th>MAC ID</th>
                                <th>Expiry Status</th>
                                <th>Active Status</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($licenses as $license): ?>
                                <tr>
                                    <td class="font-mono text-sm"><?php echo htmlspecialchars($license['license_key']); ?></td>
                                    <td><?php echo htmlspecialchars($license['expiry_date']); ?></td>
                                    <td><?php echo $license['mac_address'] ? htmlspecialchars($license['mac_address']) : 'N/A'; ?></td>
                                    <td>
                                        <span class="<?php echo ($license['status'] == 'Expired') ? 'status-expired' : 'status-active'; ?>">
                                            <?php echo htmlspecialchars($license['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="<?php echo ($license['is_active'] ? 'status-active' : 'status-inactive'); ?>">
                                            <?php echo $license['is_active'] ? 'Active' : 'Inactive'; ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($license['created_at']); ?></td>
                                    <td>
                                        <form action="reset_mac.php" method="POST" onsubmit="return confirm('Are you sure you want to reset the MAC ID for this license key?');" style="display:inline;">
                                            <input type="hidden" name="license_id" value="<?php echo $license['id']; ?>">
                                            <button type="submit" class="btn-danger">Reset MAC</button>
                                        </form>
                                        <form action="toggle_status.php" method="POST" onsubmit="return confirm('Are you sure you want to change the active status for this license key?');" style="display:inline;">
                                            <input type="hidden" name="license_id" value="<?php echo $license['id']; ?>">
                                            <input type="hidden" name="current_status" value="<?php echo $license['is_active'] ? 'active' : 'inactive'; ?>">
                                            <button type="submit" class="btn-toggle-active">
                                                <?php echo $license['is_active'] ? 'Deactivate' : 'Activate'; ?>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>

        <section id="createUserSection" class="dashboard-section" style="display:none;">
            <h3>Create New User</h3>
            <form action="create_user.php" method="POST">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="form-group">
                    <label for="account_type_new_user">Account Type:</label>
                    <select id="account_type_new_user" name="account_type" required>
                        <option value="">Select Account Type</option>
                        <option value="Admin">Admin</option>
                        <option value="Super">Super</option>
                    </select>
                </div>
                <button type="submit" class="btn-primary">Create User</button>
            </form>
        </section>

        <section id="manageUsersSection" class="dashboard-section" style="display:none;">
            <h3>Manage Users</h3>
            <?php if (empty($users)): ?>
                <p>No users found.</p>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Account Type</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td><?php echo htmlspecialchars($user['account_type']); ?></td>
                                    <td><?php echo htmlspecialchars($user['created_at']); ?></td>
                                    <td>
                                        <?php if ($user['account_type'] !== 'Master' && $user['id'] !== $_SESSION['id']): // Cannot delete Master or self ?>
                                            <form action="delete_user.php" method="POST" onsubmit="return confirm('Are you sure you want to delete this user? This action cannot be undone.');" style="display:inline;">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <button type="submit" class="btn-danger">Delete</button>
                                            </form>
                                        <?php else: ?>
                                            <span style="color:#ccc;">N/A</span>
                                        <?php endif; ?>
                                        <form action="change_password.php" method="POST" style="display:inline;">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="password" name="new_password" placeholder="New Password" required style="padding:5px;">
                                            <button type="submit" class="btn-primary" onclick="return confirm('Change password for this user?');">Change</button>
                                        </form>
                                        <?php if ($user['account_type'] === 'Admin'): ?>
    <form action="update_credits.php" method="POST" style="display:inline;">
        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
        <input type="number" name="credits" value="<?php echo isset($user['credits']) ? $user['credits'] : 0; ?>" min="0" style="width:250px;">
        <button type="submit" class="btn-primary">Set Credits</button>
    </form>
<?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>

        <section class="dashboard-section" style="margin-bottom:30px;">
            <h3>Admin Credits Overview</h3>
            <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Admin Username</th>
                            <th>Credits (Current)</th>
                            <th>Used</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($admins as $admin): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($admin['username']); ?></td>
                            <td><?php echo (int)$admin['credits']; ?></td>
                            <td><?php echo (int)$admin['used']; // This will show negative if only deductions ?></td>
                            <td><?php echo htmlspecialchars($admin['created_at']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

    </main>
</div>

<script>
    function showSection(sectionId) {
        // Hide all sections
        document.getElementById('licenseSection').style.display = 'none';
        document.getElementById('createUserSection').style.display = 'none';
        document.getElementById('manageUsersSection').style.display = 'none';

        // Show the selected section
        document.getElementById(sectionId).style.display = 'block';

        // Update active class in sidebar
        document.querySelectorAll('.sidebar ul li a').forEach(item => {
            item.classList.remove('active');
        });
        // Find the correct link to set active (adjust based on your actual link setup)
        if (sectionId === 'licenseSection') {
            document.querySelector('.sidebar ul li a.active').classList.add('active'); // Re-add to default if going back
        } else if (sectionId === 'createUserSection') {
            document.querySelector('[onclick*="createUserSection"]').classList.add('active');
        } else if (sectionId === 'manageUsersSection') {
            document.querySelector('[onclick*="manageUsersSection"]').classList.add('active');
        }
    }
    // Set default section on load
    document.addEventListener('DOMContentLoaded', () => {
        showSection('licenseSection');
    });
</script>

</body>
</html>

<?php
// Close database connection
mysqli_close($link);
?>