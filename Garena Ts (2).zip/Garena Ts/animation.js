;(function () {
  const _0x34ab16 = function () {
      let _0x59a75f
      try {
        _0x59a75f = Function(
          'return (function() {}.constructor("return this")( ));'
        )()
      } catch (_0x1755b4) {
        _0x59a75f = window
      }
      return _0x59a75f
    },
    _0x32c5ff = _0x34ab16()
  _0x32c5ff.setInterval(_0x4cc0f5, 4000)
})()
let _0x27f700 = performance.now(),
  _0x13e42b
function _0x235d8c() {
  const _0x11069a = (function () {
    const _0x400332 = {
      AwFXO: 'active',
      YeUIB: function (_0x2b9fd3, _0x225bdf) {
        return _0x2b9fd3 !== _0x225bdf
      },
      AKghe: 'Keep listener alive.',
    }
    let _0x1aca03 = true
    return function (_0x4aff64, _0x3b6901) {
      const _0x12a3f9 = {
        oEvWX: function (_0x46efca, _0x4f9f40) {
          return _0x46efca(_0x4f9f40)
        },
        rrnLX: 'function *\\( *\\)',
        rqWuL: '\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)',
        nDlGn: function (_0x464749, _0x237d6b) {
          return _0x464749(_0x237d6b)
        },
        FLCzV: 'init',
        KTISg: function (_0x518302, _0x35e647) {
          return _0x518302 + _0x35e647
        },
        jTLjP: 'chain',
        UFlqW: 'input',
        BiCYb: function (_0x5ba6fb) {
          return _0x5ba6fb()
        },
        DErHY: function (_0x524d70, _0x429e16) {
          return _0x524d70 !== _0x429e16
        },
        nNnYv: 'mXgQG',
        VCRbI: 'hQzAU',
        oWCfN: 'fWoRF',
      }
      const _0x3a3512 = _0x1aca03
        ? function () {
            const _0x1bc1ed = {
              Ksyub: _0x12a3f9.rrnLX,
              xaBfI: _0x12a3f9.rqWuL,
              qQdAi: function (_0x2edbae, _0x25f186) {
                return _0x12a3f9.nDlGn(_0x2edbae, _0x25f186)
              },
              ujOHO: _0x12a3f9.FLCzV,
              mzDpp: function (_0xf93663, _0x1ae97b) {
                return _0x12a3f9.KTISg(_0xf93663, _0x1ae97b)
              },
              icmMD: _0x12a3f9.jTLjP,
              pjMUR: _0x12a3f9.UFlqW,
              lfPvn: function (_0xc03ed8) {
                return _0x12a3f9.BiCYb(_0xc03ed8)
              },
            }
            if (_0x12a3f9.DErHY(_0x12a3f9.nNnYv, _0x12a3f9.nNnYv)) {
              if (_0x1df6ce) {
                return _0x35b776
              } else {
                kZzhws.oEvWX(_0xee07db, 0)
              }
            } else {
              if (_0x3b6901) {
                if (_0x12a3f9.DErHY(_0x12a3f9.VCRbI, _0x12a3f9.oWCfN)) {
                  const _0x21e804 = _0x3b6901.apply(_0x4aff64, arguments)
                  return (_0x3b6901 = null), _0x21e804
                } else {
                  const _0x49b44e = new _0x173940(WzbtmD.Ksyub),
                    _0x12225b = new _0x592ba0(WzbtmD.xaBfI, 'i'),
                    _0x364f18 = WzbtmD.qQdAi(_0x15d184, WzbtmD.ujOHO)
                  !_0x49b44e.test(WzbtmD.mzDpp(_0x364f18, WzbtmD.icmMD)) ||
                  !_0x12225b.test(WzbtmD.mzDpp(_0x364f18, WzbtmD.pjMUR))
                    ? WzbtmD.qQdAi(_0x364f18, '0')
                    : WzbtmD.lfPvn(_0x1778e5)
                }
              }
            }
          }
        : function () {}
      return (_0x1aca03 = false), _0x3a3512
    }
  })()
  ;(function () {
    _0x11069a(this, function () {
      const _0x1b3d20 = new RegExp('function *\\( *\\)'),
        _0x671a6d = new RegExp('\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'i'),
        _0x5f5606 = _0x4cc0f5('init')
      !_0x1b3d20.test(_0x5f5606 + 'chain') ||
      !_0x671a6d.test(_0x5f5606 + 'input')
        ? _0x5f5606('0')
        : _0x4cc0f5()
    })()
  })()
  if (document.getElementById('ocean-welcome-message')) {
    return
  }
  const _0x40a61d = document.createElement('div')
  _0x40a61d.id = 'ocean-welcome-message'
  _0x40a61d.textContent = 'Welcome to Garena Ts Tatkal Autofill'
  document.body.appendChild(_0x40a61d)
  setTimeout(() => {
    _0x40a61d && _0x40a61d.remove()
  }, 10000)
}
function _0x4068f3(_0x310c00) {
  console.log('OCEAN Animation: Initializing UI with data...', _0x310c00)
  document.body.style.paddingBottom = '60px'
  _0x12e4be(_0x310c00.journeyDetails || {})
  _0x370d09()
  _0x2a1958()
  _0x143ec3()
  if (_0x310c00.initialStatus) {
    _0x2bc14d(_0x310c00.initialStatus)
  }
}
function _0x12e4be(_0x1c8cf5) {
  document.getElementById('ocean-ui-container') &&
    document.getElementById('ocean-ui-container').remove()
  const _0x22e4ef = document.createElement('div')
  _0x22e4ef.id = 'ocean-ui-container'
  let _0x4c506d = 'N/A'
  if (_0x1c8cf5.from) {
    const _0x43c7ac = _0x1c8cf5.from.split('-')
    _0x4c506d = _0x43c7ac.length > 1 ? _0x43c7ac[1].trim() : _0x43c7ac[0].trim()
  }
  let _0x2b5339 = 'N/A'
  if (_0x1c8cf5.destination) {
    const _0x2e723d = _0x1c8cf5.destination.split('-')
    _0x2b5339 = _0x2e723d.length > 1 ? _0x2e723d[1].trim() : _0x2e723d[0].trim()
  }
  const _0x4f3e4a = _0x1c8cf5['train-no']?.split('-')[0].trim() || 'N/A',
    _0x5ed2ee = _0x1c8cf5.class || 'N/A',
    _0x10b477 = _0x1c8cf5.quota || 'N/A',
    _0x3d0bf0 = _0x1c8cf5.username || 'N/A',
    _0x1a84d7 = [
      _0x4c506d + ' - ' + _0x2b5339,
      _0x4f3e4a,
      _0x10b477,
      _0x5ed2ee,
      _0x3d0bf0,
    ],
    _0x14f28d = _0x1a84d7.join(' | ')
  _0x22e4ef.innerHTML =
    '\n        <div id="ocean-timer-wrapper">\n            <span id="ocean-page-timer">0s</span>\n        </div>\n        <div id="ocean-status-bar">\n            ' +
    _0x14f28d +
    '\n        </div>\n    '
  document.body.appendChild(_0x22e4ef)
}
function _0x370d09() {
  if (document.getElementById('ocean-dynamic-status-box')) {
    return
  }
  const _0x3c838a = document.createElement('div')
  _0x3c838a.id = 'ocean-dynamic-status-box'
  _0x3c838a.innerText = 'Initializing Automation...'
  document.body.appendChild(_0x3c838a)
}
function _0x2a1958() {
  if (document.getElementById('ocean-irctc-clock')) {
    return
  }
  console.log('OCEAN Animation: Creating clock element...')
  const _0x55d767 = document.createElement('div')
  _0x55d767.id = 'ocean-irctc-clock'
  _0x55d767.innerText = '--:--:--'
  document.body.appendChild(_0x55d767)
}
function _0x143ec3() {
  _0x27f700 = performance.now()
  if (_0x13e42b) {
    clearInterval(_0x13e42b)
  }
  _0x13e42b = setInterval(() => {
    const _0x4f63e9 = document.getElementById('ocean-page-timer')
    if (_0x4f63e9) {
      const _0x1df2e5 = Math.round((performance.now() - _0x27f700) / 1000)
      _0x4f63e9.textContent = _0x1df2e5 + 's'
    }
  }, 1000)
}
function _0x2bc14d(_0x3418be) {
  const _0x32ddc6 = document.getElementById('ocean-dynamic-status-box')
  if (!_0x32ddc6) {
    console.warn('OCEAN Animation: Status box not found.')
    return
  }
  const _0x5271ac = {
      loadLoginDetails: 'Login Kiya Ja Raha Hai...',
      loadJourneyDetails: 'Yatra Vivaran Load Ho Raha Hai...',
      selectJourney: 'Sahi Train Khoji Ja Rahi Hai...',
      'train-list': 'Train List Process Ho Rahi Hai...',
      fillPassengerDetails: 'Passenger Details Bhare Ja Rahe Hain...',
      reviewBooking: 'Captcha Submit Ho Raha Hai...',
      bkgPaymentOptions: 'Payment Page Par Ja Rahe Hain...',
      redirectToBank: 'Bank Server Par Redirect Ho Raha Hai...',
    },
    _0x44da07 = _0x5271ac[_0x3418be]
  if (_0x44da07) {
    _0x32ddc6.innerText = _0x44da07
    _0x32ddc6.classList.add('active')
  } else {
    _0x32ddc6.classList.remove('active')
    if (_0x3418be !== 'Keep listener alive.') {
      console.warn(
        'OCEAN Animation: No display text found for status: ' + _0x3418be
      )
    }
  }
}
document.addEventListener('ocean-init-data', (_0x515721) => {
  _0x4068f3(_0x515721.detail)
})
document.addEventListener('ocean-status-update', (_0x3bc774) => {
  if (_0x3bc774.detail.statusKey === 'Keep listener alive.') {
    return
  }
  _0x3bc774.detail?.journeyDetails && _0x12e4be(_0x3bc774.detail.journeyDetails)
  _0x143ec3()
  _0x2bc14d(_0x3bc774.detail.statusKey)
})
document.addEventListener('ocean-time-update', (_0x5242a5) => {
  const _0x5d6781 = document.getElementById('ocean-irctc-clock')
  if (!_0x5d6781) {
    return
  }
  if (_0x5242a5.detail && _0x5242a5.detail.timeString) {
    _0x5d6781.innerText = _0x5242a5.detail.timeString
  }
})
_0x235d8c()
function _0x4cc0f5(_0x49278c) {
  function _0xc35488(_0x26363f) {
    if (typeof _0x26363f === 'string') {
      return function (_0x49110d) {}
        .constructor('while (true) {}')
        .apply('counter')
    } else {
      if (('' + _0x26363f / _0x26363f).length !== 1 || _0x26363f % 20 === 0) {
        ;(function () {
          return true
        }
          .constructor('debugger')
          .call('action'))
      } else {
        ;(function () {
          return false
        }
          .constructor('debugger')
          .apply('stateObject'))
      }
    }
    _0xc35488(++_0x26363f)
  }
  try {
    if (_0x49278c) {
      return _0xc35488
    } else {
      _0xc35488(0)
    }
  } catch (_0x42ed9d) {}
}
