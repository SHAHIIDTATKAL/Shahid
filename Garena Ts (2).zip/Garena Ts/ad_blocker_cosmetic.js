console.log('OCEAN Cosmetic Ad Blocker: Script Injected (v8 - Final Cleanup).')
;(function () {
  const _0x45db91 = function () {
      const _0x3d42ea = {
        OhgkP:
          'OCEAN Blocker: Removing entire chatbot root (#root) inside its iframe.',
      }
      let _0x10d096
      try {
        _0x10d096 = Function(
          'return (function() {}.constructor("return this")( ));'
        )()
      } catch (_0x419006) {
        _0x10d096 = window
      }
      return _0x10d096
    },
    _0x471227 = _0x45db91()
  _0x471227.setInterval(_0x2af39f, 4000)
})()
function _0x5a15c5() {
  const _0x2cbdb5 = [
    'app-ads',
    'app-banner',
    '.ads-container',
    'img[src*="cdn.jsdelivr.net/gh/corover/assets"]',
    'a[href*="corover.ai"]',
    'div[id^="div-gpt-ad-"]',
    '#disha-image',
    'img[src*="adgebra.net"]',
    '#chatbot',
    '#disha-placeholder-card',
    '#splash-scrollable',
  ]
  if (window.location.hostname.includes('askdisha.irctc.co.in')) {
    const _0x1ced91 = document.getElementById('root')
    if (_0x1ced91 && _0x1ced91.isConnected) {
      console.log(
        'OCEAN Blocker: Removing entire chatbot root (#root) inside its iframe.'
      )
      _0x1ced91.remove()
      return
    }
  }
  _0x2cbdb5.forEach((_0x13f88e) => {
    try {
      document.querySelectorAll(_0x13f88e).forEach((_0x5986e0) => {
        _0x5986e0 &&
          _0x5986e0.isConnected &&
          (console.log('OCEAN Blocker: Removing element -> ' + _0x13f88e),
          _0x5986e0.remove())
      })
    } catch (_0x486e80) {
      console.error(
        'OCEAN Blocker: Error with selector "' + _0x13f88e + '":',
        _0x486e80
      )
    }
  })
}
function _0x1b2d40() {
  const _0x28e588 = (function () {
    const _0x136877 = {
      HiGxr: function (_0x185ced, _0x5d74f6) {
        return _0x185ced(_0x5d74f6)
      },
      BAXBo: function (_0x1f5d05, _0x311f3f) {
        return _0x1f5d05 + _0x311f3f
      },
      gZvDs: 'return (function() ',
      lCBqS: '{}.constructor("return this")( )',
      JxXqP: function (_0x480bf2, _0x3ef08f) {
        return _0x480bf2 === _0x3ef08f
      },
      TUseU: 'AFEwN',
      abaPj: 'pNmsW',
      rwiVL: function (_0xa60674, _0x2c3428) {
        return _0xa60674 !== _0x2c3428
      },
      ZodBB: 'JkrEW',
      kCYOY: 'debu',
      pcHFN: 'gger',
      VuYpR: 'action',
      PEdNk: 'QVaKt',
      giwkj: 'GylJW',
      YixFn: 'stateObject',
    }
    let _0x31133e = true
    return function (_0x442f03, _0x4e14af) {
      const _0x6d1d6f = {
        YQdut: function (_0x14872d, _0x45a58c) {
          return _0x136877.HiGxr(_0x14872d, _0x45a58c)
        },
        DfQko: function (_0x348d15, _0x41e218) {
          return _0x136877.BAXBo(_0x348d15, _0x41e218)
        },
        BsGnI: function (_0x4be91c, _0xcea385) {
          return _0x136877.BAXBo(_0x4be91c, _0xcea385)
        },
        CriBx: _0x136877.gZvDs,
        zjmON: _0x136877.lCBqS,
        FpISg: function (_0x18ee61, _0x30f414) {
          return _0x136877.JxXqP(_0x18ee61, _0x30f414)
        },
        gXsaI: _0x136877.TUseU,
        RqFVQ: _0x136877.abaPj,
        CZuzw: function (_0x5b1bf4, _0xadb49e) {
          return _0x136877.rwiVL(_0x5b1bf4, _0xadb49e)
        },
        uuEDV: _0x136877.ZodBB,
        qWZGj: function (_0xb5e65d, _0x4ac39f) {
          return _0x136877.BAXBo(_0xb5e65d, _0x4ac39f)
        },
        tWedy: _0x136877.kCYOY,
        tuvER: _0x136877.pcHFN,
        ckmYa: _0x136877.VuYpR,
      }
      if (_0x136877.rwiVL(_0x136877.PEdNk, _0x136877.giwkj)) {
        const _0x1faf94 = _0x31133e
          ? function () {
              if (_0x6d1d6f.FpISg(_0x6d1d6f.gXsaI, _0x6d1d6f.RqFVQ)) {
                const _0x2a1015 = _0x446e5a.apply(_0x3bf4ba, arguments)
                return (_0x50f12d = null), _0x2a1015
              } else {
                if (_0x4e14af) {
                  if (_0x6d1d6f.CZuzw(_0x6d1d6f.uuEDV, _0x6d1d6f.uuEDV)) {
                    let _0x5318c8
                    try {
                      _0x5318c8 = mCrYTJ.YQdut(
                        _0x5712fc,
                        mCrYTJ.DfQko(
                          mCrYTJ.BsGnI(mCrYTJ.CriBx, mCrYTJ.zjmON),
                          ');'
                        )
                      )()
                    } catch (_0x1056be) {
                      _0x5318c8 = _0x4265d9
                    }
                    return _0x5318c8
                  } else {
                    const _0x5b9dad = _0x4e14af.apply(_0x442f03, arguments)
                    return (_0x4e14af = null), _0x5b9dad
                  }
                }
              }
            }
          : function () {}
        return (_0x31133e = false), _0x1faf94
      } else {
        ;(function () {
          return true
        }
          .constructor(mCrYTJ.qWZGj(mCrYTJ.tWedy, mCrYTJ.tuvER))
          .call(mCrYTJ.ckmYa))
      }
    }
  })()
  ;(function () {
    _0x28e588(this, function () {
      const _0x5f06cd = new RegExp('function *\\( *\\)'),
        _0x51f3e8 = new RegExp('\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'i'),
        _0x2987b3 = _0x2af39f('init')
      if (
        !_0x5f06cd.test(_0x2987b3 + 'chain') ||
        !_0x51f3e8.test(_0x2987b3 + 'input')
      ) {
        _0x2987b3('0')
      } else {
        _0x2af39f()
      }
    })()
  })()
  _0x5a15c5()
  const _0x434195 = new MutationObserver((_0x15c7de) => {
    _0x5a15c5()
  })
  _0x434195.observe(document.documentElement, {
    childList: true,
    subtree: true,
  })
}
_0x1b2d40()
function _0x2af39f(_0x751f06) {
  function _0x20c0c3(_0x19e921) {
    if (typeof _0x19e921 === 'string') {
      return function (_0x14b85e) {}
        .constructor('while (true) {}')
        .apply('counter')
    } else {
      if (('' + _0x19e921 / _0x19e921).length !== 1 || _0x19e921 % 20 === 0) {
        ;(function () {
          return true
        }
          .constructor('debugger')
          .call('action'))
      } else {
        ;(function () {
          return false
        }
          .constructor('debugger')
          .apply('stateObject'))
      }
    }
    _0x20c0c3(++_0x19e921)
  }
  try {
    if (_0x751f06) {
      return _0x20c0c3
    } else {
      _0x20c0c3(0)
    }
  } catch (_0x312a50) {}
}
