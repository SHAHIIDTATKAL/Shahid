let user_data = {};

// REQUEST THROTTLING SYSTEM - Prevent multiple simultaneous requests
let isRequestInProgress = false;
let requestQueue = [];
let lastRequestTime = 0;
const MIN_REQUEST_INTERVAL = 2000; // Minimum 2 seconds between requests
const MAX_CONCURRENT_REQUESTS = 1;

// PASSENGER FORM SUBMISSION FLAG - Prevent multiple submissions
let isPassengerFormSubmitted = false;
let isPassengerFormFilling = false;

// Function to check if we can make a request
function canMakeRequest() {
  const now = Date.now();
  return !isRequestInProgress && (now - lastRequestTime) >= MIN_REQUEST_INTERVAL;
}

// Function to throttle requests
function throttleRequest(requestFunction, requestName = 'unknown') {
  return new Promise((resolve, reject) => {
    const request = {
      id: Date.now() + Math.random(),
      function: requestFunction,
      name: requestName,
      resolve: resolve,
      reject: reject,
      timestamp: Date.now()
    };
    
    requestQueue.push(request);
    processRequestQueue();
  });
}

// Function to process request queue
function processRequestQueue() {
  if (isRequestInProgress || requestQueue.length === 0) {
    return;
  }
  
  const request = requestQueue.shift();
  if (!request) return;
  
  // Check if request is too old (older than 30 seconds)
  if (Date.now() - request.timestamp > 30000) {
    console.log(`[THROTTLE] Skipping old request: ${request.name}`);
    request.reject(new Error('Request timeout'));
    processRequestQueue();
    return;
  }
  
  isRequestInProgress = true;
  lastRequestTime = Date.now();
  
  console.log(`[THROTTLE] Processing request: ${request.name}`);
  
  try {
    const result = request.function();
    if (result instanceof Promise) {
      result
        .then((data) => {
          console.log(`[THROTTLE] Request completed: ${request.name}`);
          isRequestInProgress = false;
          request.resolve(data);
          
          // Process next request after delay
          setTimeout(() => {
            processRequestQueue();
          }, MIN_REQUEST_INTERVAL);
        })
        .catch((error) => {
          console.error(`[THROTTLE] Request failed: ${request.name}`, error);
          isRequestInProgress = false;
          request.reject(error);
          
          // Process next request after delay
          setTimeout(() => {
            processRequestQueue();
          }, MIN_REQUEST_INTERVAL);
        });
    } else {
      console.log(`[THROTTLE] Request completed: ${request.name}`);
      isRequestInProgress = false;
      request.resolve(result);
      
      // Process next request after delay
      setTimeout(() => {
        processRequestQueue();
      }, MIN_REQUEST_INTERVAL);
    }
  } catch (error) {
    console.error(`[THROTTLE] Request error: ${request.name}`, error);
    isRequestInProgress = false;
    request.reject(error);
    
    // Process next request after delay
    setTimeout(() => {
      processRequestQueue();
    }, MIN_REQUEST_INTERVAL);
  }
}

// Function to clear request queue
function clearRequestQueue() {
  console.log(`[THROTTLE] Clearing request queue (${requestQueue.length} requests)`);
  requestQueue.forEach(request => {
    request.reject(new Error('Request queue cleared'));
  });
  requestQueue = [];
  isRequestInProgress = false;
}

// Function to check for "request under process" error
function checkForRequestError() {
  const errorMessages = [
    'Your request is under process',
    'Don not submit multiple request',
    'Request is being processed',
    'Please wait',
    'Processing your request'
  ];
  
  const pageText = document.body.innerText || '';
  const hasError = errorMessages.some(msg => 
    pageText.toLowerCase().includes(msg.toLowerCase())
  );
  
  if (hasError) {
    console.log('[THROTTLE] Request error detected, clearing queue and waiting...');
    clearRequestQueue();
    
    // Wait longer before allowing new requests
    setTimeout(() => {
      isRequestInProgress = false;
      lastRequestTime = 0;
      console.log('[THROTTLE] Error recovery complete, allowing new requests');
    }, 10000); // Wait 10 seconds after error
    
    return true;
  }
  
  return false;
}

// Monitor for request errors
setInterval(() => {
  checkForRequestError();
}, 2000);

function getMsg(_0x28a1d3, _0x53cece) {
  return {
    'msg': {
      'type': _0x28a1d3,
      'data': _0x53cece
    },
    'sender': "content_script",
    'id': 'irctc'
  };
}
function statusUpdate(_0x1430f9) {
  chrome.runtime.sendMessage({
    'msg': {
      'type': "status_update",
      'data': {
        'status': _0x1430f9,
        'time': new Date().toString().split(" ")[0x4]
      }
    },
    'sender': 'content_script',
    'id': "irctc"
  });
}
function classTranslator(_0x38b32c) {
  labletext = '1A' === _0x38b32c ? "AC First Class (1A)" : 'EV' === _0x38b32c ? "Vistadome AC (EV)" : 'EC' === _0x38b32c ? "Exec. Chair Car (EC)" : '2A' === _0x38b32c ? "AC 2 Tier (2A)" : '3A' === _0x38b32c ? "AC 3 Tier (3A)" : '3E' === _0x38b32c ? "AC 3 Economy (3E)" : 'CC' === _0x38b32c ? "AC Chair car (CC)" : 'SL' === _0x38b32c ? "Sleeper (SL)" : '2S' === _0x38b32c ? "Second Sitting (2S)" : 'None';
  return labletext;
}
function quotaTranslator(_0x297af3) {
  if ('GN' === _0x297af3) {
    labletext = "GENERAL";
  } else {
    if ('TQ' === _0x297af3) {
      labletext = "TATKAL";
    } else {
      if ('PT' === _0x297af3) {
        labletext = "PREMIUM TATKAL";
      } else {
        if ('LD' === _0x297af3) {
          labletext = "LADIES";
        } else if ('SR' === _0x297af3) {
          labletext = "LOWER BERTH/SR.CITIZEN";
        } else {
          labletext;
        }
      }
    }
  }
  return labletext;
}
function addDelay(_0x5bcbbc) {
  const _0x5f0619 = Date.now();
  let _0x2c2188 = null;
  do {
    _0x2c2188 = Date.now();
  } while (_0x2c2188 - _0x5f0619 < _0x5bcbbc);
}
chrome.runtime.onMessage.addListener((_0x5e789f, _0x1c0644, _0x3df39d) => {
  if ("irctc" !== _0x5e789f.id) {
    return void _0x3df39d("Invalid Id");
  }
  const _0x5f5478 = _0x5e789f.msg.type;
  if ("selectJourney" === _0x5f5478) {
    console.log("selectJourney");
    popupbtn = document.querySelectorAll(".btn.btn-primary");
    if (popupbtn.length > 0x0) {
      popupbtn[0x1].click();
      console.log("Close last trxn popup");
    }
    const _0x9036c8 = [...document.querySelector("#divMain > div > app-train-list").querySelectorAll(".tbis-div app-train-avl-enq")];
    console.log(user_data.journey_details["train-no"]);
    const _0x3f9692 = user_data.journey_details["train-no"];
    const _0x261927 = _0x9036c8.filter(_0x45d6ba => _0x45d6ba.querySelector("div.train-heading").innerText.trim().includes(_0x3f9692.split('-')[0x0]))[0x0];
    if ('M' === user_data.travel_preferences.AvailabilityCheck) {
      return void alert("Please manually select train and click Book");
    }
    if ('A' === user_data.travel_preferences.AvailabilityCheck || 'I' === user_data.travel_preferences.AvailabilityCheck) {
      if (!_0x261927) {
        console.log("Precheck - Train not found for search criteria.");
        return void alert("Precheck - Train(" + _0x3f9692 + ") not found for search criteria. You can manually proceed or correct data and restart the process.");
      }
      const _0x1d833b = classTranslator(user_data.journey_details["class"]);
      if (![..._0x261927.querySelectorAll("table tr td div.pre-avl")].filter(_0x8a4253 => _0x8a4253.querySelector("div").innerText === _0x1d833b)[0x0]) {
        console.log("Precheck - Selected Class not available in the train.");
        return void alert("Precheck - Selected Class not available in the train. You can manually proceed or correct data and restart the process.");
      }
    }
    const _0x355ee5 = document.querySelector("div.row.col-sm-12.h_head1 > span > strong");
    if ('A' === user_data.travel_preferences.AvailabilityCheck) {
      console.log("Automatically click");
      if ('TQ' === user_data.journey_details.quota || 'PT' === user_data.journey_details.quota || 'GN' === user_data.journey_details.quota) {
        console.log("Verify tatkal time");
        const _0x505ceb = user_data.journey_details["class"];
        requiredTime = "00:00:00";
        current_time = "00:00:00";
        if (['1A', '2A', '3A', 'CC', 'EC', '3E'].includes(_0x505ceb.toUpperCase())) {
          requiredTime = user_data.other_preferences.acbooktime;
        } else {
          requiredTime = user_data.other_preferences.slbooktime;
        }
        if ('GN' === user_data.journey_details.quota) {
          requiredTime = user_data.other_preferences.gnbooktime;
        }
        console.log("requiredTime", requiredTime);
        var _0x3c4196 = 0x0;
        let _0x2b0e1a = new MutationObserver(_0x39215c => {
          current_time = new Date().toString().split(" ")[0x4];
          console.log("current_time", current_time);
          if (current_time > requiredTime) {
            _0x2b0e1a.disconnect();
            selectJourneyEnhanced(); // ENHANCED: Use fast version
          } else {
            if (0x0 == _0x3c4196) {
              console.log("Inside wait counter 0 ");
              try {
                const _0x2e2b8b = document.createElement("div");
                _0x2e2b8b.textContent = "Please wait..Booking will automatically start at " + requiredTime;
                _0x2e2b8b.style.textAlign = "center";
                _0x2e2b8b.style.color = 'white';
                _0x2e2b8b.style.height = "auto";
                _0x2e2b8b.style.fontSize = "20px";
                document.querySelector("#divMain > div > app-train-list > div> div > div > div.clearfix").insertAdjacentElement("afterend", _0x2e2b8b);
              } catch (_0x316ad9) {
                console.log("wait time failed", _0x316ad9.message);
              }
            }
            try {
              if (_0x3c4196 % 0x2 == 0x0) {
                console.log("counter1", _0x3c4196 % 0x2);
                document.querySelector("#divMain > div > app-train-list > div > div > div > div:nth-child(2)").style.background = "green";
              } else {
                console.log("counter2", _0x3c4196 % 0x2);
                document.querySelector("#divMain > div > app-train-list > div > div > div > div:nth-child(2)").style.background = "red";
              }
            } catch (_0x39d8ed) {}
            _0x3c4196 += 0x1;
            console.log("wait time");
          }
        });
        _0x2b0e1a.observe(_0x355ee5, {
          'childList': true,
          'subtree': true,
          'characterDataOldValue': true
        });
      } else {
        console.log("select journey GENERAL quota");
        selectJourneyEnhanced(); // ENHANCED: Use fast version
      }
    } else if ('I' === user_data.travel_preferences.AvailabilityCheck) {
      console.log("Immediately click");
      selectJourneyEnhanced(); // ENHANCED: Use fast version
    }
  } else {
    if ('fillPassengerDetails' === _0x5f5478) {
      console.log("fillPassengerDetails");
      fillPassengerDetails();
    } else {
      if ('reviewBooking' === _0x5f5478) {
        console.log("reviewBooking");
        try {
          chrome.storage.local.get(['plan'], _0x445252 => {
  	let currentPlan = 'A';
  	if (currentPlan === 'A') {
    	console.log("User have active plan");
  	} else {
              
              try {
                document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 > a.search_btn.loginText.ng-star-inserted").click();
              } catch (_0x1bc299) {
                window.location.href = "https://www.irctc.co.in/nget/train-search";
              }
            }
          });
        } catch (_0x45b639) {
          alert("Failed to validate plan. Please contact our support team");
          try {
            document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 > a.search_btn.loginText.ng-star-inserted").click();
          } catch (_0xa8e1b2) {
            window.location.href = 'https://www.irctc.co.in/nget/train-search';
          }
        }
        document.querySelector("#captcha").scrollIntoView({
          'behavior': 'smooth',
          'block': "center",
          'inline': "nearest"
        });
        
        // ENHANCED: Use new captcha function with invalid captcha handling
        setTimeout(() => {
          getCaptchaWithInvalidHandling();
        }, 0x1f4);
      } else {
        if ("bkgPaymentOptions" === _0x5f5478) {
          addDelay(0xc8);
          console.log("bkgPaymentOptions");
          let _0x5c1a64 = "Multiple Payment Service";
          let _0x115941 = "IRCTC iPay (Credit Card/Debit Card/UPI)";
          let _0x6ef959 = true;
          if (user_data.other_preferences.paymentmethod.includes("IRCUPI")) {
            _0x6ef959 = false;
            _0x5c1a64 = "IRCTC iPay (Credit Card/Debit Card/UPI)";
            _0x115941 = "Credit cards/Debit cards/Netbanking/UPI (Powered by IRCTC)";
            console.log("Payment option-IRCUPI");
          }
          if (user_data.other_preferences.paymentmethod.includes('PAYTMUPI')) {
            _0x5c1a64 = "BHIM/ UPI/ USSD";
            _0x115941 = "Pay using BHIM (Powered by PAYTM ) also accepts UPI";
            console.log("Payment option-PAYTMUPI");
          }
          if (user_data.other_preferences.paymentmethod.includes("PHONEPEUPI")) {
            _0x5c1a64 = "Multiple Payment Service";
            _0x115941 = "Credit & Debit cards / Net Banking / Wallet / UPI (Powered by Paytm)";
            console.log("Payment option-PHONEPEUPI");
          }
	  if (user_data.other_preferences.paymentmethod.includes("RAZOUPI")) {
            _0x5c1a64 = "Multiple Payment Service";
            _0x115941 = "Credit & Debit cards / Net Banking / UPI (Powered by Razorpay)";
            console.log("Payment option-RAZOUPI");
          }
	  if (user_data.other_preferences.paymentmethod.includes("ZAMBOUPI")) {
            _0x5c1a64 = "Multiple Payment Service";
            _0x115941 = "Credit & Debit cards / Wallet / UPI (Powered by PhonePe)";
            console.log("Payment option-ZAMBOUPI");
          }
          if (user_data.other_preferences.paymentmethod.includes("MOBUPI")) {
            const _0x53a91b = window.navigator.userAgent;
            console.log("BrowserUserAgent", _0x53a91b);
            if (_0x53a91b.includes("Android")) {
              console.log("Android browser");
              _0x5c1a64 = "Multiple Payment Service";
              _0x115941 = "Credit & Debit cards / Wallet / UPI (Powered by PhonePe)";
            }
          }
          if (user_data.other_preferences.paymentmethod.includes("IRCWA")) {
            _0x5c1a64 = "IRCTC eWallet";
            _0x115941 = "IRCTC eWallet";
            console.log("Payment option-IRCWA");
          }
          if (user_data.other_preferences.paymentmethod.includes("HDFCDB")) {
            _0x5c1a64 = "Payment Gateway / Credit Card / Debit Card";
            _0x115941 = "Visa/Master Card(Powered By HDFC BANK)";
            console.log("Payment option-HDFCDB");
          }
          let _0x3e8aaa = _0x115941.replace('&', "&amp;");
          let _0x5ca6e7 = false;
          var _0x5a86f5 = setInterval(() => {
            if (document.getElementsByClassName("bank-type").length > 0x1) {
              clearInterval(_0x5a86f5);
              var _0x2354a9 = document.getElementById("pay-type").getElementsByTagName("div");
              for (i = 0x0; i < _0x2354a9.length; i++) {
                if (_0x2354a9[i].innerText.indexOf(_0x5c1a64) >= 0x0) {
                  if (_0x6ef959) {
                    _0x2354a9[i].click();
                  }
                  setTimeout(() => {
                    var _0x5370f0 = document.getElementsByClassName("border-all no-pad");
                    for (i = 0x0; i < _0x5370f0.length; i++) {
                      if (0x0 != _0x5370f0[i].getBoundingClientRect().top && -0x1 != _0x5370f0[i].getElementsByTagName("span")[0x0].innerHTML.toUpperCase().indexOf(_0x3e8aaa.toUpperCase())) {
                        if (_0x6ef959) {
                          _0x5370f0[i].click();
                        }
                        _0x5ca6e7 = true;
                        document.getElementsByClassName("btn-primary")[0x0].scrollIntoView({
                          'behavior': "smooth",
                          'block': "center",
                          'inline': "nearest"
                        });
                        if (user_data.other_preferences.hasOwnProperty("paymentManual") && user_data.other_preferences.paymentManual) {
                          alert("Manually submit the payment page.");
                        } else {
                          setTimeout(() => {
                            document.getElementsByClassName("btn-primary")[0x0].click();
                          }, 0x1f4);
                        }
                        break;
                      }
                      if (!(i != _0x5370f0.length - 0x1 || _0x5ca6e7)) {
                        alert("Selected payment option not available, please select other option manually.");
                      }
                    }
                  }, 0x1f4);
                }
              }
            }
          }, 0x1f4);
        } else {
          console.log("Nothing to do");
        }
      }
    }
  }
  _0x3df39d("Something went wrong");
});
let captchaRetry = 0x0;
function getCaptcha() {
  if (captchaRetry < 0x64) {
    console.log("getCaptcha");
    captchaRetry += 0x1;
    const _0x28733a = document.querySelector(".captcha-img");
    if (_0x28733a) {
      const _0x4a94fe = new XMLHttpRequest();
      const _0x36f699 = _0x28733a.src.substr(0x16);
      const _0x2f1c46 = JSON.stringify({
        'requests': [{
          'image': {
            'content': _0x36f699
          },
          'features': [{
            'type': 'TEXT_DETECTION'
          }],
          'imageContext': {
            'languageHints': ['en']
          }
        }]
      });
      user_data.other_preferences.projectId;
      _0x4a94fe.open('POST', 'https://vision.googleapis.com/v1/images:annotate?key=AIzaSyDnvpf2Tusn2Cp2icvUjGBBbfn_tY86QgQ', false);
      _0x4a94fe.onload = function () {
        if (0xc8 != _0x4a94fe.status) {
          console.log("Error " + _0x4a94fe.status + ": " + _0x4a94fe.statusText);
          console.log(_0x4a94fe.response);
        } else {
          let _0x51955e = '';
          const _0x34af16 = document.querySelector('#captcha');
          _0x51955e = JSON.parse(_0x4a94fe.response).responses[0x0].fullTextAnnotation.text;
          console.log("Org text", _0x51955e);
          const _0x1fcfa6 = Array.from(_0x51955e.split(" ").join('').replace(')', 'J').replace(']', 'J'));
          let _0x3eb148 = '';
          for (const _0x1a4c3c of _0x1fcfa6) if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@".includes(_0x1a4c3c)) {
            _0x3eb148 += _0x1a4c3c;
          }
          
          // IMPROVED CAPTCHA FILLING - More responsive
          (async () => {
            try {
              // Fill captcha with human-like typing
              _0x34af16.value = '';
              _0x34af16.focus();
              for (let i = 0; i < _0x3eb148.length; i++) {
                _0x34af16.value += _0x3eb148[i];
                _0x34af16.dispatchEvent(new Event("input", { bubbles: true }));
                await new Promise(res => setTimeout(res, 50 + Math.random() * 30));
              }
              _0x34af16.dispatchEvent(new Event("change", { bubbles: true }));
              console.log('[IMPROVED] Captcha filled with human-like typing');
              
              // IMPROVED AUTO SUBMIT LOGIC - More responsive and reliable
              if (undefined !== user_data.other_preferences.CaptchaSubmitMode && user_data.other_preferences.CaptchaSubmitMode === 'A') {
                // Check if on review page
                const reviewPage = document.querySelector("#divMain > div > app-review-booking");
                if (reviewPage) {
                  // Wait a bit for any dynamic content to load
                  await new Promise(res => setTimeout(res, 100));
                  
                  // Try multiple selectors for the submit button
                  let reviewBtn = reviewPage.querySelector(".btnDefault.train_Search") || 
                                 reviewPage.querySelector("button[type='submit']") ||
                                 reviewPage.querySelector(".btn-primary") ||
                                 reviewPage.querySelector("button:contains('Submit')") ||
                                 reviewPage.querySelector("button:contains('Book')");
                  
                  if (reviewBtn && _0x34af16.value) {
                    console.log('[AUTO SUBMIT] Found review submit button, clicking...');
                    await simulateHumanClick(reviewBtn);
                    console.log('[AUTO SUBMIT] Review/submit button clicked after captcha');
                    
                    // Add a backup retry mechanism
                    setTimeout(() => {
                      // Check if form was actually submitted
                      const currentUrl = window.location.href;
                      if (!currentUrl.includes('booking-confirm') && !currentUrl.includes('payment')) {
                        console.log('[AUTO SUBMIT] Form may not have submitted, trying backup click...');
                        const backupBtn = reviewPage.querySelector(".btnDefault.train_Search") || 
                                        reviewPage.querySelector("button[type='submit']") ||
                                        reviewPage.querySelector(".btn-primary");
                        if (backupBtn) {
                          backupBtn.click();
                        }
                      }
                    }, 800);
                  } else {
                    console.log('[AUTO SUBMIT] Submit button not found or captcha empty');
                  }
                } else {
                  console.log('[AUTO SUBMIT] Not on review page, skipping auto-submit');
                }
              }
              
              // Handle empty captcha response
              if ('' == _0x51955e) {
                console.log("Null captcha text from api");
                const refreshBtn = document.querySelector(".glyphicon.glyphicon-repeat")?.parentElement;
                if (refreshBtn) {
                  refreshBtn.click();
                  setTimeout(() => {
                    getCaptcha();
                  }, 0x1f4);
                }
              }
            } catch (error) {
              console.error("Captcha filling error:", error);
              // Fallback to original behavior
              _0x34af16.value = _0x3eb148;
              _0x34af16.dispatchEvent(new Event('input'));
              _0x34af16.dispatchEvent(new Event("change"));
              _0x34af16.focus();
              
              // Fallback auto-submit
              if (undefined !== user_data.other_preferences.CaptchaSubmitMode && user_data.other_preferences.CaptchaSubmitMode === 'A') {
                const reviewPage = document.querySelector("#divMain > div > app-review-booking");
                if (reviewPage) {
                  setTimeout(() => {
                    const reviewBtn = reviewPage.querySelector(".btnDefault.train_Search") || 
                                    reviewPage.querySelector("button[type='submit']") ||
                                    reviewPage.querySelector(".btn-primary");
                    if (reviewBtn && _0x34af16.value) {
                      reviewBtn.click();
                      console.log('[FALLBACK] Review button clicked');
                    }
                  }, 400);
                }
              }
            }
          })();
          
          // REMOVED: Dependency on advertisements and mutation observers
          // The new approach is more direct and responsive
        }
      };
      _0x4a94fe.onerror = function () {
        console.log("Captcha API Request failed");
        // Retry on error
        setTimeout(() => {
          getCaptcha();
        }, 1000);
      };
      _0x4a94fe.send(_0x2f1c46);
    } else {
      console.log("wait for captcha load");
      setTimeout(() => {
        getCaptcha();
      }, 0x3e8);
    }
  }
}
// Human behavior simulation functions
function simulateHumanMouseMovement(element, duration = 800) {
  if (!element) return Promise.resolve();
  
  return new Promise(resolve => {
    const rect = element.getBoundingClientRect();
    const startX = Math.random() * window.innerWidth;
    const startY = Math.random() * window.innerHeight;
    const endX = rect.left + rect.width / 2 + (Math.random() - 0.5) * 20;
    const endY = rect.top + rect.height / 2 + (Math.random() - 0.5) * 20;
    
    const steps = 10;
    let currentStep = 0;
    
    const moveMouse = () => {
      if (currentStep >= steps) {
        resolve();
        return;
      }
      
      const progress = currentStep / steps;
      const currentX = startX + (endX - startX) * progress;
      const currentY = startY + (endY - startY) * progress;
      
      // Simulate mouse move event
      const mouseMoveEvent = new MouseEvent('mousemove', {
        clientX: currentX,
        clientY: currentY,
        bubbles: true,
        cancelable: true
      });
      document.dispatchEvent(mouseMoveEvent);
      
      currentStep++;
      setTimeout(moveMouse, duration / steps);
    };
    
    moveMouse();
  });
}

function simulateHumanScroll() {
  return new Promise(resolve => {
    // Scroll down slightly
    window.scrollBy({
      top: 50 + Math.random() * 30,
      behavior: 'smooth'
    });
    
    setTimeout(() => {
      // Scroll up slightly
      window.scrollBy({
        top: -30 - Math.random() * 20,
        behavior: 'smooth'
      });
      
      setTimeout(resolve, 300);
    }, 200);
  });
}

function simulateHumanClick(element) {
  if (!element) return Promise.resolve();
  
  return new Promise(resolve => {
    // Mouse down
    const mouseDownEvent = new MouseEvent('mousedown', {
      clientX: element.getBoundingClientRect().left + element.getBoundingClientRect().width / 2,
      clientY: element.getBoundingClientRect().top + element.getBoundingClientRect().height / 2,
      bubbles: true,
      cancelable: true,
      button: 0
    });
    element.dispatchEvent(mouseDownEvent);
    
    setTimeout(() => {
      // Mouse up
      const mouseUpEvent = new MouseEvent('mouseup', {
        clientX: element.getBoundingClientRect().left + element.getBoundingClientRect().width / 2,
        clientY: element.getBoundingClientRect().top + element.getBoundingClientRect().height / 2,
        bubbles: true,
        cancelable: true,
        button: 0
      });
      element.dispatchEvent(mouseUpEvent);
      
      setTimeout(() => {
        // Click
        const clickEvent = new MouseEvent('click', {
          clientX: element.getBoundingClientRect().left + element.getBoundingClientRect().width / 2,
          clientY: element.getBoundingClientRect().top + element.getBoundingClientRect().height / 2,
          bubbles: true,
          cancelable: true,
          button: 0
        });
        element.dispatchEvent(clickEvent);
        resolve();
      }, 50);
    }, 50);
  });
}

function getCaptchaTC() {
  if (captchaRetry < 0x64) {
    console.log("getCaptchaTC");
    captchaRetry += 0x1;
    const _0x3b97f5 = document.querySelector(".captcha-img");
    if (_0x3b97f5) {
      const _0x52004d = new XMLHttpRequest();
      const _0x241f3b = _0x3b97f5.src.substr(0x16);
      const _0x279c07 = JSON.stringify({
        'client': "chrome extension",
        'location': 'https://www.irctc.co.in/nget/train-search',
        'version': "0.3.8",
        'case': "mixed",
        'promise': "true",
        'extension': true,
        'userid': "zerox99107@gmail.com",
        'apikey': "e6jiBcV6mCApIZFAJD9o",
        'data': _0x241f3b
      });
      _0x52004d.open("POST", "https://api.apitruecaptcha.org/one/gettext", false);
      _0x52004d.onload = function () {
        if (0xc8 != _0x52004d.status) {
          console.log("Error " + _0x52004d.status + ": " + _0x52004d.statusText);
          console.log(_0x52004d.response);
        } else {
          let _0x1f4f37 = '';
          const _0x26fe7d = document.querySelector("#captcha");
          _0x1f4f37 = JSON.parse(_0x52004d.response).result;
          console.log("Org text", _0x1f4f37);
          const _0x3ae02c = Array.from(_0x1f4f37.split(" ").join('').replace(')', 'J').replace(']', 'J'));
          let _0xe768b6 = '';
          for (const _0x5cebd0 of _0x3ae02c) if ('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789=@'.includes(_0x5cebd0)) {
            _0xe768b6 += _0x5cebd0;
          }
          
          // IMPROVED HUMAN-LIKE BEHAVIOR SIMULATION (review/login captcha)
          (async () => {
            try {
              // 1. Simulate mouse movement to captcha field
              await simulateHumanMouseMovement(_0x26fe7d, 300);
              // 2. Simulate natural scrolling
              await simulateHumanScroll();
              // 3. Fill captcha with human-like typing
              _0x26fe7d.value = '';
              _0x26fe7d.focus();
              for (let i = 0; i < _0xe768b6.length; i++) {
                _0x26fe7d.value += _0xe768b6[i];
                _0x26fe7d.dispatchEvent(new Event("input", { bubbles: true }));
                await new Promise(res => setTimeout(res, 60 + Math.random() * 40));
              }
              _0x26fe7d.dispatchEvent(new Event("change", { bubbles: true }));
              // 4. Simulate human click on captcha field
              await simulateHumanClick(_0x26fe7d);
              console.log('[HUMAN SIMULATION] Captcha filled with human-like behavior');

              // IMPROVED AUTO SUBMIT LOGIC - More responsive and reliable
              if (undefined !== user_data.other_preferences.CaptchaSubmitMode && user_data.other_preferences.CaptchaSubmitMode === 'A') {
                // Check if on review page
                const reviewPage = document.querySelector("#divMain > div > app-review-booking");
                if (reviewPage) {
                  // Wait a bit for any dynamic content to load
                  await new Promise(res => setTimeout(res, 150));
                  
                  // Try multiple selectors for the submit button
                  let reviewBtn = reviewPage.querySelector(".btnDefault.train_Search") || 
                                 reviewPage.querySelector("button[type='submit']") ||
                                 reviewPage.querySelector(".btn-primary") ||
                                 reviewPage.querySelector("button:contains('Submit')") ||
                                 reviewPage.querySelector("button:contains('Book')");
                  
                  if (reviewBtn && _0x26fe7d.value) {
                    console.log('[AUTO SUBMIT] Found review submit button, clicking...');
                    await simulateHumanClick(reviewBtn);
                    console.log('[AUTO SUBMIT] Review/submit button clicked after captcha');
                    
                    // Add a backup retry mechanism
                    setTimeout(() => {
                      // Check if form was actually submitted
                      const currentUrl = window.location.href;
                      if (!currentUrl.includes('booking-confirm') && !currentUrl.includes('payment')) {
                        console.log('[AUTO SUBMIT] Form may not have submitted, trying backup click...');
                        const backupBtn = reviewPage.querySelector(".btnDefault.train_Search") || 
                                        reviewPage.querySelector("button[type='submit']") ||
                                        reviewPage.querySelector(".btn-primary");
                        if (backupBtn) {
                          backupBtn.click();
                        }
                      }
                    }, 1000);
                  } else {
                    console.log('[AUTO SUBMIT] Submit button not found or captcha empty');
                  }
                } else {
                  console.log('[AUTO SUBMIT] Not on review page, skipping auto-submit');
                }
              }

              // Handle empty captcha response
              if ('' == _0x1f4f37) {
                console.log("Null captcha text from api");
                const refreshBtn = document.querySelector(".glyphicon.glyphicon-repeat")?.parentElement;
                if (refreshBtn) {
                  refreshBtn.click();
                  setTimeout(() => {
                    getCaptchaTC();
                  }, 0x1f4);
                }
              }
            } catch (error) {
              console.error("Human simulation error:", error);
              // Fallback to original behavior
              _0x26fe7d.value = _0xe768b6;
              _0x26fe7d.dispatchEvent(new Event("input"));
              _0x26fe7d.dispatchEvent(new Event("change"));
              _0x26fe7d.focus();
              
              // Fallback auto-submit
              if (undefined !== user_data.other_preferences.CaptchaSubmitMode && user_data.other_preferences.CaptchaSubmitMode === 'A') {
                const reviewPage = document.querySelector("#divMain > div > app-review-booking");
                if (reviewPage) {
                  setTimeout(() => {
                    const reviewBtn = reviewPage.querySelector(".btnDefault.train_Search") || 
                                    reviewPage.querySelector("button[type='submit']") ||
                                    reviewPage.querySelector(".btn-primary");
                    if (reviewBtn && _0x26fe7d.value) {
                      reviewBtn.click();
                      console.log('[FALLBACK] Review button clicked');
                    }
                  }, 500);
                }
              }
            }
          })();
        }
      };
      _0x52004d.onerror = function () {
        console.log("Captcha API Request failed");
        // Retry on error
        setTimeout(() => {
          getCaptchaTC();
        }, 1000);
      };
      _0x52004d.send(_0x279c07);
    } else {
      console.log("wait for captcha load");
      setTimeout(() => {
        getCaptchaTC();
      }, 0x3e8);
    }
  }
}
function loadLoginDetails() {
  const _0x1d2765 = document.querySelector("#divMain > app-login");
  const _0x2d921d = _0x1d2765.querySelector("input[type='text'][formcontrolname='userid']");
  const _0x45228d = _0x1d2765.querySelector("input[type='password'][formcontrolname='password']");
  _0x1d2765.querySelector("button[type='submit']");
  _0x2d921d.value = user_data.irctc_credentials.user_name ?? '';
  _0x2d921d.dispatchEvent(new Event("input"));
  _0x2d921d.dispatchEvent(new Event("change"));
  _0x45228d.value = user_data.irctc_credentials.password ?? '';
  _0x45228d.dispatchEvent(new Event("input"));
  _0x45228d.dispatchEvent(new Event("change"));
  document.querySelector("#captcha").scrollIntoView({
    'behavior': "smooth",
    'block': "center",
    'inline': 'nearest'
  });
  
  // ENHANCED: Use new captcha function with invalid captcha handling
  setTimeout(() => {
    getCaptchaWithInvalidHandling();
  }, 0x1f4);
}
function loadJourneyDetails() {
  console.log("filling_journey_details");
  const _0x4425b4 = document.querySelector("app-jp-input form");
  const _0x45021a = _0x4425b4.querySelector("#origin > span > input");
  _0x45021a.value = user_data.journey_details.from;
  _0x45021a.dispatchEvent(new Event("keydown"));
  _0x45021a.dispatchEvent(new Event("input"));
  const _0x183221 = _0x4425b4.querySelector("#destination > span > input");
  _0x183221.value = user_data.journey_details.destination;
  _0x183221.dispatchEvent(new Event("keydown"));
  _0x183221.dispatchEvent(new Event("input"));
  const _0x4ab00d = _0x4425b4.querySelector("#jDate > span > input");
  _0x4ab00d.value = user_data.journey_details.date ? '' + user_data.journey_details.date.split('-').reverse().join('/') : '';
  _0x4ab00d.dispatchEvent(new Event("keydown"));
  _0x4ab00d.dispatchEvent(new Event("input"));
  const _0x59a9b7 = _0x4425b4.querySelector("#journeyClass");
  _0x59a9b7.querySelector("div > div[role='button']").click();
  addDelay(0x12c);
  [..._0x59a9b7.querySelectorAll("ul li")].filter(_0x43b03f => _0x43b03f.innerText === classTranslator(user_data.journey_details['class']) ?? '')[0x0]?.["click"]();
  addDelay(0x12c);
  const _0x2ee36e = _0x4425b4.querySelector("#journeyQuota");
  _0x2ee36e.querySelector("div > div[role='button']").click();
  [..._0x2ee36e.querySelectorAll("ul li")].filter(_0x8265e => _0x8265e.innerText === quotaTranslator(user_data.journey_details.quota) ?? '')[0x0]?.["click"]();
  addDelay(0x12c);
  const _0x12d5b6 = _0x4425b4.querySelector("button.search_btn.train_Search[type='submit']");
  addDelay(0x12c);
  console.log('filled_journey_details');
  
  // Use throttling for search button click
  throttleRequest(() => {
    _0x12d5b6.click();
    console.log('[JOURNEY DETAILS] Search button clicked with throttling');
    return Promise.resolve();
  }, 'loadJourneyDetailsSearch').then(() => {
    console.log('[JOURNEY DETAILS] Search button click completed');
  }).catch((error) => {
    console.error('[JOURNEY DETAILS] Search button click failed:', error);
  });
}
function selectJourneyOld() {
  if (!user_data.journey_details["train-no"]) {
    return;
  }
  const _0x32523 = [...document.querySelector("#divMain > div > app-train-list").querySelectorAll(".tbis-div app-train-avl-enq")];
  console.log(user_data.journey_details["train-no"]);
  const _0xfa52c7 = _0x32523.filter(_0x1dace5 => _0x1dace5.querySelector("div.train-heading").innerText.trim().includes(user_data.journey_details["train-no"]))[0x0];
  if (!_0xfa52c7) {
    console.log("Train not found.");
    alert("Train not found");
    return void statusUpdate('journey_selection_stopped.no_train');
  }
  const _0x2a1498 = classTranslator(user_data.journey_details["class"]);
  const _0x5ef38f = new Date(user_data.journey_details.date).toString().split(" ");
  const _0x41cf3d = {
    'attributes': false,
    'childList': true,
    'subtree': true
  };
  [..._0xfa52c7.querySelectorAll("table tr td div.pre-avl")].filter(_0x34bcf2 => _0x34bcf2.querySelector("div").innerText === _0x2a1498)[0x0]?.["click"]();
  const _0x31e570 = document.querySelector("#divMain > div > app-train-list > p-toast");
  new MutationObserver((_0x1a41ca, _0x48be86) => {
    const _0x416796 = [..._0xfa52c7.querySelectorAll("div p-tabmenu ul[role='tablist'] li[role='tab']")].filter(_0x257bfb => _0x257bfb.querySelector("div").innerText === _0x2a1498)[0x0];
    const _0x53af7d = [..._0xfa52c7.querySelectorAll("div div table td div.pre-avl")].filter(_0x3c1985 => _0x3c1985.querySelector("div").innerText === _0x5ef38f[0x0] + ", " + _0x5ef38f[0x2] + " " + _0x5ef38f[0x1])[0x0];
    const _0x59fa0f = _0xfa52c7.querySelector("button.btnDefault.train_Search.ng-star-inserted");
    if (_0x416796) {
      console.log(0x1);
      if (!_0x416796.classList.contains("ui-state-active")) {
        console.log(0x2);
        return void _0x416796.click();
      }
      if (_0x53af7d) {
        console.log(0x3);
        if (_0x53af7d.classList.contains('selected-class')) {
          console.log(0x4);
          _0x59fa0f.click();
          _0x48be86.disconnect();
        } else {
          console.log(0x5);
          _0x53af7d.click();
        }
      }
    } else {
      console.log('6');
      _0x53af7d.click();
      _0x59fa0f.click();
      _0x48be86.disconnect();
    }
  }).observe(_0xfa52c7, _0x41cf3d);
  const _0x4c13f8 = new MutationObserver((_0x3e32be, _0xbd52c7) => {
    console.log("Popup error");
    console.log("Class count ", [..._0xfa52c7.querySelectorAll("table tr td div.pre-avl")].length);
    console.log("Class count ", [..._0xfa52c7.querySelectorAll("table tr td div.pre-avl")]);
    if (_0x31e570.innerText.includes("Unable to perform")) {
      console.log("Unable to perform");
      [..._0xfa52c7.querySelectorAll("table tr td div.pre-avl")].filter(_0x4e73f4 => _0x4e73f4.querySelector("div").innerText === _0x2a1498)[0x0]?.["click"]();
      _0xbd52c7.disconnect();
    }
  });
  _0x4c13f8.observe(_0x31e570, _0x41cf3d);
}
function retrySelectJourney() {
  console.log("Retrying selectJourney...");
  setTimeout(selectJourneyEnhanced, 0x3e8); // ENHANCED: Use fast version
}
function selectJourney() {
  const _0x450336 = setInterval(() => {
    const _0x4ef9b6 = document.querySelector("#divMain > div > app-train-list > p-toast > div > p-toastitem > div > div > a");
    const _0x1d0b16 = document.querySelector("body > app-root > app-home > div.header-fix > app-header > p-toast > div > p-toastitem > div > div > a");
    const _0x12b6ab = _0x4ef9b6 || _0x1d0b16;
    const _0x5e7162 = document.querySelector("#loaderP");
    const _0x4e4c21 = _0x5e7162 && "none" !== _0x5e7162.style.display;
    if (_0x12b6ab && !_0x4e4c21) {
      console.log("Toast link found. Clicking it now...");
      _0x12b6ab.click();
      console.log("Toast link clicked");
      retrySelectJourney();
      console.log("Toast link clicked and called retrySelectJourney");
      clearInterval(_0x450336);
    }
  }, 0x3e8);
  if (!user_data?.["journey_details"]?.["train-no"]) {
    return void console.error("Train number is not available in user_data.");
  }
  const _0x55f7c3 = document.querySelector("#divMain > div > app-train-list");
  if (!_0x55f7c3) {
    return void console.error("Train list parent not found.");
  }
  const _0x517199 = Array.from(_0x55f7c3.querySelectorAll(".tbis-div app-train-avl-enq"));
  const _0x2a5e89 = user_data.journey_details["train-no"];
  const _0x109709 = classTranslator(user_data.journey_details["class"]);
  const _0x15392a = new Date(user_data.journey_details.date);
  const _0x5a2695 = _0x15392a.toDateString().split(" ")[0x0] + ", " + _0x15392a.toDateString().split(" ")[0x2] + " " + _0x15392a.toDateString().split(" ")[0x1];
  console.log("Train Number:", _0x2a5e89);
  console.log("Class:", _0x109709);
  console.log("date", _0x5a2695);
  const _0x46c66c = _0x517199.find(_0x6ffbd4 => _0x6ffbd4.querySelector("div.train-heading").innerText.trim().includes(_0x2a5e89.split('-')[0x0]));
  if (!_0x46c66c) {
    console.error("Train not found.");
    return void statusUpdate('journey_selection_stopped.no_train');
  }
  const _0x148902 = _0x37dd8e => {
    if (!_0x37dd8e) {
      return false;
    }
    const _0x5a616b = window.getComputedStyle(_0x37dd8e);
    return 'none' !== _0x5a616b.display && "hidden" !== _0x5a616b.visibility && '0' !== _0x5a616b.opacity;
  };
  const _0x3717f5 = Array.from(_0x46c66c.querySelectorAll("table tr td div.pre-avl")).find(_0x5d0778 => _0x5d0778.querySelector("div").innerText.trim() === _0x109709);
  const _0x26ed04 = Array.from(_0x46c66c.querySelectorAll("span")).find(_0x4b03cf => _0x4b03cf.innerText.trim() === _0x109709);
  const _0x17effb = _0x3717f5 || _0x26ed04;
  console.log("FOUND updatedClassToClick:", _0x17effb);
  if (!_0x17effb) {
    return void console.error("Class to click not found.");
  }
  const _0x334fdb = document.querySelector("#loaderP");
  if (_0x148902(_0x334fdb)) {
    return void console.error("Loader is visible. Cannot click the class.");
  }
  let _0x29538d;
  _0x17effb.click();
  new MutationObserver((_0x1e31ce, _0x34ea47) => {
    console.log("Mutation observed at", new Date().toLocaleTimeString());
    clearTimeout(_0x29538d);
    _0x29538d = setTimeout(() => {
      const _0x157f95 = Array.from(_0x46c66c.querySelectorAll("div div table td div.pre-avl")).find(_0xa11edc => _0xa11edc.querySelector("div").innerText.trim() === _0x5a2695);
      console.log("FOUND classTabToSelect:", _0x157f95);
      if (_0x157f95) {
        _0x157f95.click();
        console.log("Clicked on selectdate");
        setTimeout(() => {
          const _0xcccea7 = () => {
            const _0x38c633 = _0x46c66c.querySelector("button.btnDefault.train_Search.ng-star-inserted");
            if (_0x148902(document.querySelector("#loaderP"))) {
              console.warn("Loader is visible, retrying...");
              return void setTimeout(_0xcccea7, 0x64);
            }
            if (!_0x38c633 || _0x38c633.classList.contains("disable-book") || _0x38c633.disabled) {
              console.warn("bookBtn is disabled or not found, retrying...");
              retrySelectJourney();
            } else {
              // INSTANT click on bookBtn after seat refresh, no delay
              _0x38c633.click();
              console.log("Clicked on bookBtn instantly");
              clearTimeout(_0x29538d);
              _0x34ea47.disconnect();
            }
          };
          _0xcccea7();
        }, 0x3e8);
      } else {
        console.warn("classTabToSelect not found");
      }
    }, 0x12c);
  }).observe(_0x46c66c, {
    'attributes': false,
    'childList': true,
    'subtree': true
  });
}
let keyCounter = 0x0;
function fillPassengerDetails() {
  console.log("passenger_filling_started");
  if (user_data.journey_details.boarding.length > 0x0) {
    console.log("Set boarding station " + user_data.journey_details.boarding);
    const _0x823d6 = document.getElementsByTagName("strong");
    const _0x51808e = Array.from(_0x823d6).filter(_0x1807c7 => _0x1807c7.innerText.includes(user_data.journey_details.from.split('-')[0x0].trim() + " | "));
    if (_0x51808e[0x0]) {
      _0x51808e[0x0].click();
      addDelay(0x12c);
    }
    const _0x47e7eb = document.getElementsByTagName("strong");
    const _0x5caba7 = Array.from(_0x47e7eb).filter(_0x496bb2 => _0x496bb2.innerText.includes(user_data.journey_details.boarding.split('-')[0x0].trim()));
    if (_0x5caba7[0x0]) {
      _0x5caba7[0x0].click();
    }
  }
  keyCounter = new Date().getTime();
  const _0x3eeb46 = document.querySelector("app-passenger-input");
  let _0x3954bd = 0x1;
  for (; _0x3954bd < user_data.passenger_details.length;) {
    addDelay(0xc8);
    document.getElementsByClassName("prenext")[0x0].click();
    _0x3954bd++;
  }
  try {
    let _0x163857 = 0x0;
    for (; _0x163857 < user_data.infant_details.length;) {
      addDelay(0xc8);
      document.getElementsByClassName("prenext")[0x2].click();
      _0x163857++;
    }
  } catch (_0xd261ca) {
    console.error("add infant error", _0xd261ca);
  }
  const _0x2c35b9 = [..._0x3eeb46.querySelectorAll("app-passenger")];
  const _0x211eb5 = [..._0x3eeb46.querySelectorAll("app-infant")];
  user_data.passenger_details.forEach((_0x1069fd, _0x155fef) => {
    let _0x518e55 = _0x2c35b9[_0x155fef].querySelector("p-autocomplete > span > input");
    _0x518e55.value = _0x1069fd.name;
    _0x518e55.dispatchEvent(new Event("input"));
    let _0x58b1ff = _0x2c35b9[_0x155fef].querySelector("input[type='number'][formcontrolname='passengerAge']");
    _0x58b1ff.value = _0x1069fd.age;
    _0x58b1ff.dispatchEvent(new Event('input'));
    let _0x1dd530 = _0x2c35b9[_0x155fef].querySelector("select[formcontrolname='passengerGender']");
    _0x1dd530.value = _0x1069fd.gender;
    _0x1dd530.dispatchEvent(new Event("change"));
    let _0xf8b0a2 = _0x2c35b9[_0x155fef].querySelector("select[formcontrolname='passengerBerthChoice']");
    _0xf8b0a2.value = _0x1069fd.berth;
    _0xf8b0a2.dispatchEvent(new Event("change"));
    let _0x4f0813 = _0x2c35b9[_0x155fef].querySelector("select[formcontrolname='passengerFoodChoice']");
    if (_0x4f0813) {
      _0x4f0813.value = _0x1069fd.food;
      _0x4f0813.dispatchEvent(new Event("change"));
    }
    try {
      let _0x307148 = _0x2c35b9[_0x155fef].querySelector("input[type='checkbox'][formcontrolname='childBerthFlag']");
      console.log("noChildberth", _0x155fef, _0x1069fd.passengerchildberth);
      if (_0x307148 && _0x1069fd.passengerchildberth) {
        console.log("set child half seat");
        _0x307148.click();
        addDelay(0xc8);
        if (document.evaluate("//div[contains(text(),'No berth will be allotted for child and')]", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue) {
          console.log("clikc OK");
          document.querySelector("app-passenger > p-dialog > div > div > div > p-footer > button").click();
          addDelay(0xc8);
        }
      }
    } catch (_0x46a3e3) {
      console.error("opt Half seat error", _0x46a3e3);
    }
  });
  try {
    user_data.infant_details.forEach((_0xeca955, _0x32bd02) => {
      let _0x2023cb = _0x211eb5[_0x32bd02].querySelector("input#infant-name[name='infant-name']");
      _0x2023cb.value = _0xeca955.name;
      _0x2023cb.dispatchEvent(new Event("input"));
      let _0x2fdac3 = _0x211eb5[_0x32bd02].querySelector("select[formcontrolname='age']");
      _0x2fdac3.value = _0xeca955.age;
      _0x2fdac3.dispatchEvent(new Event('change'));
      let _0x26bf61 = _0x211eb5[_0x32bd02].querySelector("select[formcontrolname='gender']");
      _0x26bf61.value = _0xeca955.gender;
      _0x26bf61.dispatchEvent(new Event("change"));
    });
  } catch (_0x580b44) {
    console.error("fill infant error", _0x580b44);
  }
  if ('' !== user_data.other_preferences.mobileNumber) {
    let _0x5d5368 = _0x3eeb46.querySelector("input#mobileNumber[formcontrolname='mobileNumber'][name='mobileNumber']");
    _0x5d5368.value = user_data.other_preferences.mobileNumber;
    _0x5d5368.dispatchEvent(new Event("input"));
    _0x5d5368.dispatchEvent(new Event("change"));
  }
  let _0x35d6ea = [..._0x3eeb46.querySelectorAll("p-radiobutton[formcontrolname='paymentType'][name='paymentType'] input[type='radio']")];
  addDelay(0x64);
  let _0x36c0ec = '2';
  if (!user_data.other_preferences.paymentmethod.includes("UPI")) {
    _0x36c0ec = 0x1;
  }
  _0x35d6ea.filter(_0x3bf002 => _0x3bf002.value === _0x36c0ec)[0x0]?.["click"]();
  let _0x2d3efb = _0x3eeb46.querySelector("input#autoUpgradation[type='checkbox'][formcontrolname='autoUpgradationSelected']");
  if (_0x2d3efb && user_data.other_preferences.hasOwnProperty("autoUpgradation") && user_data.other_preferences.autoUpgradation) {
    _0x2d3efb.checked = user_data.other_preferences.autoUpgradation ?? false;
  }
  let _0x13931b = _0x3eeb46.querySelector("input#confirmberths[type='checkbox'][formcontrolname='bookOnlyIfCnf']");
  if (_0x13931b && user_data.other_preferences.hasOwnProperty("confirmberths") && user_data.other_preferences.confirmberths) {
    _0x13931b.checked = user_data.other_preferences.confirmberths ?? false;
  }
  let _0x350b21 = [..._0x3eeb46.querySelectorAll("p-radiobutton[formcontrolname='travelInsuranceOpted'] input[type='radio'][name='travelInsuranceOpted-0']")];
  addDelay(0xc8);
  _0x350b21.filter(_0x400214 => _0x400214.value === ('yes' === user_data.travel_preferences.travelInsuranceOpted ? "true" : "false"))[0x0]?.['click']();
  try {
    let _0x55bb51 = _0x3eeb46.querySelector("input[formcontrolname='coachId']");
    if (_0x55bb51 && user_data.travel_preferences.hasOwnProperty('prefcoach') && user_data.travel_preferences.prefcoach.trim().length > 0x0) {
      console.log("set preferred coach Id");
      _0x55bb51.value = user_data.travel_preferences.prefcoach;
    }
    const _0x49c9 = _0x3eeb46.querySelector("p-dropdown[formcontrolname='reservationChoice']");
    if (_0x49c9 && user_data.travel_preferences.hasOwnProperty("reservationchoice") && !user_data.travel_preferences.reservationchoice.includes("Reservation Choice")) {
      console.log("set reservationchoice");
      _0x49c9.querySelector("div > div[role='button']").click();
      addDelay(0x12c);
      [..._0x49c9.querySelectorAll("ul li")].filter(_0x18bc55 => _0x18bc55.innerText === user_data.travel_preferences.reservationchoice ?? '')[0x0]?.["click"]();
    }
  } catch (_0x188ef6) {
    console.error("pref coach and reservation choice error", _0x188ef6);
  }
  submitPassengerDetailsForm(_0x3eeb46);
}
function submitPassengerDetailsForm(_0x439043) {
  console.log("passenger_filling_completed");
  window.scrollBy(0x0, 0x258, 'smooth');
  if (user_data.other_preferences.hasOwnProperty("psgManual") && user_data.other_preferences.psgManual) {
    alert("Manually submit the passenger page.");
  } else {
    // INSTANT submit after fill, no delay
    _0x439043.querySelector("#psgn-form > form div > button.train_Search.btnDefault[type='submit']")?.click();
    window.scrollBy(0x0, 0x258, "smooth");
  }
}
function continueScript() {
  const _0x1ec64f = document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 > a.search_btn.loginText.ng-star-inserted");
  if (window.location.href.includes("train-search")) {
    if ('LOGOUT' === _0x1ec64f.innerText.trim().toUpperCase()) {
      loadJourneyDetails();
    }
    if ("LOGIN" === _0x1ec64f.innerText.trim().toUpperCase()) {
      _0x1ec64f.click();
      loadLoginDetails();
    }
  } else if (!window.location.href.includes("nget/booking/train-list")) {
    console.log("Nothing to do");
  }
}
async function a() {
  const _0x5bd35d = user_data.subs_credentials.user_name ?? '';
  console.log("Simulating plan check for:", _0x5bd35d);
  console.log("Fake plan check successful. Continuing...");
}
function closeIrctcAlertPopup() {
    // Try to find the OK button in the popup
    const okBtn = document.querySelector('.btn.btn-primary');
    if (okBtn && okBtn.innerText.trim().toUpperCase() === "OK") {
        okBtn.click();
        console.log("Closed IRCTC alert popup.");
        return true;
    }
    return false;
}

// Try to close the popup immediately, and also keep checking for a few seconds in case it appears late
let popupCloseAttempts = 0;
const popupCloseInterval = setInterval(() => {
    if (closeIrctcAlertPopup() || popupCloseAttempts > 20) {
        clearInterval(popupCloseInterval);
    }
    popupCloseAttempts++;
}, 200);

window.onload = function (_0xf9043b) {
  // Helper to close AskDisha banner if present
  function closeAskDishaBanner() {
    try {
      const dishaCloseBtn = document.getElementById('disha-banner-close');
      if (dishaCloseBtn) {
        dishaCloseBtn.click();
        console.log('AskDisha banner closed automatically.');
      }
    } catch (e) { console.warn('AskDisha close error:', e); }
  }

  // Try to close AskDisha immediately and during countdown
  closeAskDishaBanner();
  let dishaInterval = setInterval(closeAskDishaBanner, 1000); // keep trying during countdown

  // --- MODAL POPUP WITH TIMER ---
  function showWaitModal(seconds) {
    // Create modal background
    const modalBg = document.createElement('div');
    modalBg.id = 'irctc-wait-modal-bg';
    modalBg.style.position = 'fixed';
    modalBg.style.top = '0';
    modalBg.style.left = '0';
    modalBg.style.width = '100vw';
    modalBg.style.height = '100vh';
    modalBg.style.background = 'rgba(0,0,0,0.7)';
    modalBg.style.zIndex = '99999';
    modalBg.style.display = 'flex';
    modalBg.style.alignItems = 'center';
    modalBg.style.justifyContent = 'center';

    // Create modal box
    const modalBox = document.createElement('div');
    modalBox.style.background = '#fff';
    modalBox.style.padding = '32px 40px';
    modalBox.style.borderRadius = '12px';
    modalBox.style.boxShadow = '0 2px 16px rgba(0,0,0,0.2)';
    modalBox.style.textAlign = 'center';
    modalBox.style.fontSize = '22px';
    modalBox.style.color = '#222';
    modalBox.style.minWidth = '320px';

    // Message and timer
    const msg = document.createElement('div');
    msg.textContent = 'Waiting for process starting in';
    msg.style.marginBottom = '12px';
    const timer = document.createElement('span');
    timer.id = 'irctc-wait-timer';
    timer.style.fontWeight = 'bold';
    timer.style.fontSize = '32px';
    timer.style.display = 'block';
    timer.style.margin = '8px 0 0 0';
    timer.textContent = seconds + ' seconds';

    modalBox.appendChild(msg);
    modalBox.appendChild(timer);
    modalBg.appendChild(modalBox);
    document.body.appendChild(modalBg);

    // Countdown logic
    let remaining = seconds;
    const interval = setInterval(() => {
      remaining--;
      timer.textContent = remaining + ' seconds';
      closeAskDishaBanner(); // keep trying during countdown
      if (remaining <= 0) {
        clearInterval(interval);
        clearInterval(dishaInterval);
        if (modalBg.parentNode) modalBg.parentNode.removeChild(modalBg);
        if (typeof window.__irctc_wait_modal_done === 'function') window.__irctc_wait_modal_done();
      }
    }, 1000);
  }

  // Pause the rest of the script for 15 seconds with modal
  window.__irctc_wait_modal_done = function() {
    // --- REST OF ORIGINAL window.onload CODE BELOW ---
    setInterval(function () {
      console.log('Repeater');
      statusUpdate("Keep listener alive.");
    }, 0x3a98);
    const _0x3f6fb2 = document.querySelector("body > app-root > app-home > div.header-fix > app-header > div.col-sm-12.h_container > div.text-center.h_main_div > div.row.col-sm-12.h_head1 ");
    new MutationObserver((_0x21e322, _0x557c11) => {
      if (_0x21e322.filter(_0x3a2190 => "childList" === _0x3a2190.type && _0x3a2190.addedNodes.length > 0x0 && [..._0x3a2190.addedNodes].filter(_0x43eac0 => "LOGOUT" === _0x43eac0?.["innerText"]?.["trim"]()?.["toUpperCase"]()).length > 0x0).length > 0x0) {
        _0x557c11.disconnect();
        loadJourneyDetails();
      } else {
        _0x3f6fb2.click();
        loadLoginDetails();
      }
    }).observe(_0x3f6fb2, {
      'attributes': false,
      'childList': true,
      'subtree': false
    });
    chrome.storage.local.get(null, _0x90969d => {
      user_data = _0x90969d;
      continueScript();
    });
  };

  // Show modal and wait
  showWaitModal(15);
};

console.log("[VOLTAS Log] Step 1: content_script.js loaded successfully.");

// --- LIVE SYSTEM TIME DISPLAY ---
(function() {
  // Helper to check if on a banking/payment page
  function isBankingPage() {
    const url = window.location.href.toLowerCase();
    return (
      url.includes('pay') ||
      url.includes('bank') ||
      url.includes('payment') ||
      url.includes('pgui') ||
      url.includes('secure')
    );
  }

  // Create the clock element
  const clock = document.createElement('div');
  clock.id = 'irctc-live-clock';
  clock.style.position = 'fixed';
  clock.style.top = '16px';
  clock.style.right = '24px';
  clock.style.zIndex = '99999';
  clock.style.background = '#87ceeb'; // sky blue
  clock.style.color = '#222';
  clock.style.fontWeight = 'bold';
  clock.style.fontSize = '22px';
  clock.style.padding = '8px 18px';
  clock.style.borderRadius = '8px';
  clock.style.boxShadow = '0 2px 8px rgba(0,0,0,0.08)';
  clock.style.display = 'none';
  clock.style.fontFamily = 'monospace, Arial, sans-serif';

  document.body.appendChild(clock);

  function updateClock() {
    if (isBankingPage()) {
      clock.style.display = 'none';
      return;
    }
    const now = new Date();
    let h = now.getHours();
    const m = String(now.getMinutes()).padStart(2, '0');
    const s = String(now.getSeconds()).padStart(2, '0');
    const ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12;
    h = h ? h : 12; // 0 should be 12
    const hStr = String(h).padStart(2, '0');
    clock.textContent = `${hStr}:${m}:${s} ${ampm}`;
    clock.style.display = 'block';
    // Set text color for contrast
    clock.style.color = '#fff';
    clock.style.textShadow = '0 1px 2px #000';
  }

  setInterval(updateClock, 1000);
  updateClock();
})();

// NEW FUNCTION: Handle invalid captcha errors and auto-retry
function handleInvalidCaptchaError() {
  console.log('[INVALID CAPTCHA] Detected invalid captcha error, starting auto-retry process...');
  
  // Wait for new captcha to load
  setTimeout(() => {
    // Check if we're on review page or login page
    const reviewPage = document.querySelector("#divMain > div > app-review-booking");
    const loginPage = document.querySelector("#divMain > app-login");
    
    if (reviewPage) {
      console.log('[INVALID CAPTCHA] On review page, solving new captcha...');
      // Clear the captcha field first
      const captchaField = document.querySelector("#captcha");
      if (captchaField) {
        captchaField.value = '';
        captchaField.dispatchEvent(new Event("input", { bubbles: true }));
        captchaField.dispatchEvent(new Event("change", { bubbles: true }));
      }
      
      // Use the appropriate captcha solving method
      if (undefined !== user_data.other_preferences.autoCaptcha && user_data.other_preferences.autoCaptcha) {
        getCaptchaTC();
      } else {
        getCaptcha();
      }
    } else if (loginPage) {
      console.log('[INVALID CAPTCHA] On login page, solving new captcha...');
      // Clear the captcha field first
      const captchaField = document.querySelector("#captcha");
      if (captchaField) {
        captchaField.value = '';
        captchaField.dispatchEvent(new Event("input", { bubbles: true }));
        captchaField.dispatchEvent(new Event("change", { bubbles: true }));
      }
      
      // Use the appropriate captcha solving method
      if (undefined !== user_data.other_preferences.autoCaptcha && user_data.other_preferences.autoCaptcha) {
        getCaptchaTC();
      } else {
        getCaptcha();
      }
    } else {
      console.log('[INVALID CAPTCHA] Unknown page, cannot determine captcha solving method');
    }
  }, 1000); // Wait 1 second for new captcha to load
}

// NEW FUNCTION: Monitor for invalid captcha errors
function startInvalidCaptchaMonitor() {
  console.log('[MONITOR] Starting invalid captcha error monitor...');
  
  // Monitor for invalid captcha error messages
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.type === 'childList') {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            // Check for invalid captcha error messages
            const text = node.textContent || node.innerText || '';
            if (text.toLowerCase().includes('invalid captcha') || 
                text.toLowerCase().includes('captcha is invalid') ||
                text.toLowerCase().includes('please enter valid captcha') ||
                text.toLowerCase().includes('wrong captcha')) {
              console.log('[MONITOR] Invalid captcha error detected:', text);
              handleInvalidCaptchaError();
            }
          }
        });
      }
    });
  });
  
  // Observe the entire document for changes
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true
  });
  
  // Also monitor for toast messages and alerts
  const toastObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.type === 'childList') {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            // Check for toast messages
            const toastText = node.textContent || node.innerText || '';
            if (toastText.toLowerCase().includes('invalid captcha') || 
                toastText.toLowerCase().includes('captcha is invalid') ||
                toastText.toLowerCase().includes('please enter valid captcha') ||
                toastText.toLowerCase().includes('wrong captcha')) {
              console.log('[MONITOR] Invalid captcha toast detected:', toastText);
              handleInvalidCaptchaError();
            }
          }
        });
      }
    });
  });
  
  // Observe toast containers
  const toastContainers = document.querySelectorAll('p-toast, .toast, .alert, .error-message');
  toastContainers.forEach(container => {
    toastObserver.observe(container, {
      childList: true,
      subtree: true,
      characterData: true
    });
  });
  
  // Monitor for new toast containers being added
  const toastContainerObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.type === 'childList') {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            if (node.matches && (node.matches('p-toast') || node.matches('.toast') || node.matches('.alert') || node.matches('.error-message'))) {
              toastObserver.observe(node, {
                childList: true,
                subtree: true,
                characterData: true
              });
            }
          }
        });
      }
    });
  });
  
  toastContainerObserver.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  console.log('[MONITOR] Invalid captcha error monitor started');
}

// ENHANCED CAPTCHA FUNCTIONS WITH INVALID CAPTCHA HANDLING
function getCaptchaWithInvalidHandling() {
  // Start monitoring for invalid captcha errors
  startInvalidCaptchaMonitor();
  
  // Start monitoring for booking confirmation page
  startBookingConfirmationMonitor();
  
  // Call the original captcha function
  if (undefined !== user_data.other_preferences.autoCaptcha && user_data.other_preferences.autoCaptcha) {
    getCaptchaTC();
  } else {
    getCaptcha();
  }
}

// NEW FUNCTION: Handle booking confirmation page
function handleBookingConfirmation() {
  console.log('[BOOKING CONFIRMATION] Detected booking confirmation page');
  
  // Wait for page to fully load
  setTimeout(() => {
    try {
      // Extract booking details from the page
      let paymentMode = 'Unknown';
      let pnrNumber = 'Unknown';
      let trainNumber = 'Unknown';
      let destination = 'Unknown';
      let bookingTime = new Date().toLocaleTimeString('en-IN', { 
        hour12: false, 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit' 
      });
      
      // Try to extract PNR number
      const pnrElements = document.querySelectorAll('*');
      for (let element of pnrElements) {
        const text = element.textContent || element.innerText || '';
        if (text.includes('PNR') && /\d{10}/.test(text)) {
          pnrNumber = text.match(/\d{10}/)[0];
          break;
        }
      }
      
      // Try to extract train number
      for (let element of pnrElements) {
        const text = element.textContent || element.innerText || '';
        if (text.includes('Train') && /\d{5}/.test(text)) {
          trainNumber = text.match(/\d{5}/)[0];
          break;
        }
      }
      
      // Try to extract destination (from-to)
      for (let element of pnrElements) {
        const text = element.textContent || element.innerText || '';
        if (text.includes(' to ') && text.length < 50) {
          destination = text.trim();
          break;
        }
      }
      
      // Try to extract payment mode
      for (let element of pnrElements) {
        const text = element.textContent || element.innerText || '';
        if (text.toLowerCase().includes('upi') || 
            text.toLowerCase().includes('card') || 
            text.toLowerCase().includes('netbanking') ||
            text.toLowerCase().includes('wallet')) {
          paymentMode = text.trim();
          break;
        }
      }
      
      // Create and show the success modal
      const modal = document.createElement('div');
      modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 999999;
        font-family: Arial, sans-serif;
      `;
      
      const modalContent = document.createElement('div');
      modalContent.style.cssText = `
        background: white;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        max-width: 500px;
        width: 90%;
        text-align: center;
        animation: modalSlideIn 0.3s ease-out;
      `;
      
      // Add CSS animation
      const style = document.createElement('style');
      style.textContent = `
        @keyframes modalSlideIn {
          from {
            opacity: 0;
            transform: translateY(-50px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `;
      document.head.appendChild(style);
      
      modalContent.innerHTML = `
        <div style="margin-bottom: 20px;">
          <div style="font-size: 24px; color: #28a745; font-weight: bold; margin-bottom: 10px;">
            ✅ PNR Successfully Booked!
          </div>
          <div style="font-size: 18px; color: #333; margin-bottom: 20px;">
            Your booking has been confirmed
          </div>
        </div>
        
        <div style="text-align: left; margin-bottom: 20px;">
          <div style="margin-bottom: 10px;">
            <strong>PNR Number:</strong> <span style="color: #007bff; font-weight: bold;">${pnrNumber}</span>
          </div>
          <div style="margin-bottom: 10px;">
            <strong>Train Number:</strong> <span style="color: #007bff;">${trainNumber}</span>
          </div>
          <div style="margin-bottom: 10px;">
            <strong>Destination:</strong> <span style="color: #007bff;">${destination}</span>
          </div>
          <div style="margin-bottom: 10px;">
            <strong>Payment Mode:</strong> <span style="color: #007bff;">${paymentMode}</span>
          </div>
          <div style="margin-bottom: 10px;">
            <strong>Booking Time:</strong> <span style="color: #007bff; font-weight: bold;">${bookingTime}</span>
          </div>
        </div>
        
        <button id="closeBookingModal" style="
          background: #007bff;
          color: white;
          border: none;
          padding: 12px 30px;
          border-radius: 8px;
          font-size: 16px;
          cursor: pointer;
          transition: background 0.3s;
        " onmouseover="this.style.background='#0056b3'" onmouseout="this.style.background='#007bff'">
          Close
        </button>
      `;
      
      modal.appendChild(modalContent);
      document.body.appendChild(modal);
      
      // Add close functionality
      document.getElementById('closeBookingModal').addEventListener('click', () => {
        document.body.removeChild(modal);
      });
      
      // Auto-close after 10 seconds
      setTimeout(() => {
        if (document.body.contains(modal)) {
          document.body.removeChild(modal);
        }
      }, 10000);
      
      console.log('[BOOKING CONFIRMATION] Success modal displayed');
      
    } catch (error) {
      console.error('[BOOKING CONFIRMATION] Error showing modal:', error);
    }
  }, 2000); // Wait 2 seconds for page to load
}

// NEW FUNCTION: Monitor for booking confirmation page
function startBookingConfirmationMonitor() {
  console.log('[MONITOR] Starting booking confirmation page monitor...');
  
  // Check if we're already on the booking confirmation page
  if (window.location.href.includes('booking-confirm')) {
    handleBookingConfirmation();
    return;
  }
  
  // Monitor for URL changes
  let currentUrl = window.location.href;
  const urlObserver = new MutationObserver(() => {
    if (window.location.href !== currentUrl) {
      currentUrl = window.location.href;
      if (currentUrl.includes('booking-confirm')) {
        console.log('[MONITOR] Booking confirmation page detected');
        handleBookingConfirmation();
      }
    }
  });
  
  // Monitor for navigation events
  window.addEventListener('popstate', () => {
    if (window.location.href.includes('booking-confirm')) {
      console.log('[MONITOR] Booking confirmation page detected via popstate');
      handleBookingConfirmation();
    }
  });
  
  // Monitor for pushstate events
  const originalPushState = history.pushState;
  history.pushState = function(...args) {
    originalPushState.apply(history, args);
    if (window.location.href.includes('booking-confirm')) {
      console.log('[MONITOR] Booking confirmation page detected via pushstate');
      setTimeout(handleBookingConfirmation, 1000);
    }
  };
  
  console.log('[MONITOR] Booking confirmation page monitor started');
}

// ENHANCED FAST SELECT JOURNEY FUNCTION
function selectJourneyEnhanced() {
  console.log('[FAST SELECT] Starting enhanced fast journey selection...');
  
  // Use throttling to prevent multiple requests
  return throttleRequest(() => {
    return new Promise((resolve, reject) => {
      // First, check if we need to wait for booking time
      if (user_data.travel_preferences.AvailabilityCheck === 'A' && 
          (user_data.journey_details.quota === 'TQ' || user_data.journey_details.quota === 'PT' || user_data.journey_details.quota === 'GN')) {
        
        console.log('[FAST SELECT] Tatkal booking detected, checking time...');
        const targetClass = user_data.journey_details["class"];
        let requiredTime = "00:00:00";
        
        if (['1A', '2A', '3A', 'CC', 'EC', '3E'].includes(targetClass.toUpperCase())) {
          requiredTime = user_data.other_preferences.acbooktime || "09:59:59";
        } else {
          requiredTime = user_data.other_preferences.slbooktime || "10:59:59";
        }
        
        if (user_data.journey_details.quota === 'GN') {
          requiredTime = user_data.other_preferences.gnbooktime || "08:09:59";
        }
        
        console.log('[FAST SELECT] Required booking time:', requiredTime);
        
        // Check current time
        const currentTime = new Date().toString().split(" ")[4];
        console.log('[FAST SELECT] Current time:', currentTime);
        
        if (currentTime < requiredTime) {
          console.log('[FAST SELECT] Waiting for booking time...');
          
          // Show wait message
          try {
            const existingWaitMsg = document.querySelector('.wait-message');
            if (!existingWaitMsg) {
              const waitMsg = document.createElement("div");
              waitMsg.className = 'wait-message';
              waitMsg.textContent = `Please wait... Booking will automatically start at ${requiredTime}`;
              waitMsg.style.cssText = `
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background: rgba(0, 0, 0, 0.9);
                color: white;
                padding: 20px;
                border-radius: 10px;
                z-index: 10000;
                font-size: 18px;
                text-align: center;
              `;
              document.body.appendChild(waitMsg);
            }
          } catch (error) {
            console.log('[FAST SELECT] Error showing wait message:', error);
          }
          
          // Wait for booking time
          const timeObserver = new MutationObserver(() => {
            const currentTime = new Date().toString().split(" ")[4];
            if (currentTime >= requiredTime) {
              console.log('[FAST SELECT] Booking time reached, starting selection...');
              timeObserver.disconnect();
              
              // Remove wait message
              const waitMsg = document.querySelector('.wait-message');
              if (waitMsg) waitMsg.remove();
              
              // Start the actual selection process
              startFastSelection().then(resolve).catch(reject);
            }
          });
          
          // Observe time changes
          const timeElement = document.querySelector("div.row.col-sm-12.h_head1 > span > strong");
          if (timeElement) {
            timeObserver.observe(timeElement, {
              childList: true,
              subtree: true,
              characterDataOldValue: true
            });
          }
          
          // Fallback: check every second
          const timeInterval = setInterval(() => {
            const currentTime = new Date().toString().split(" ")[4];
            if (currentTime >= requiredTime) {
              console.log('[FAST SELECT] Booking time reached (fallback), starting selection...');
              clearInterval(timeInterval);
              timeObserver.disconnect();
              
              // Remove wait message
              const waitMsg = document.querySelector('.wait-message');
              if (waitMsg) waitMsg.remove();
              
              // Start the actual selection process
              startFastSelection().then(resolve).catch(reject);
            }
          }, 1000);
          
          return;
        }
      }
      
      // If no time waiting needed, start immediately
      startFastSelection().then(resolve).catch(reject);
    });
  }, 'selectJourneyEnhanced');
}

function startFastSelection() {
  console.log('[FAST SELECT] Starting fast selection process...');
  
  // Immediately start monitoring for elements without waiting
  const fastInterval = setInterval(() => {
    try {
      // Check for toast links and click immediately
      const toastLink = document.querySelector("#divMain > div > app-train-list > p-toast > div > p-toastitem > div > div > a") ||
                       document.querySelector("body > app-root > app-home > div.header-fix > app-header > p-toast > div > p-toastitem > div > div > a");
      
      if (toastLink) {
        console.log('[FAST SELECT] Toast link found, clicking immediately...');
        toastLink.click();
        clearInterval(fastInterval);
        setTimeout(() => startFastSelection(), 100); // Retry immediately
        return;
      }
      
      // Check if train list is available
      const trainList = document.querySelector("#divMain > div > app-train-list");
      if (!trainList) {
        return; // Keep checking
      }
      
      // Check for loader and skip if visible
      const loader = document.querySelector("#loaderP");
      if (loader && loader.style.display !== "none") {
        return; // Keep checking until loader disappears
      }
      
      // Find the target train immediately
      const trainElements = Array.from(trainList.querySelectorAll(".tbis-div app-train-avl-enq"));
      const targetTrain = trainElements.find(train => {
        const heading = train.querySelector("div.train-heading");
        return heading && heading.innerText.trim().includes(user_data.journey_details["train-no"].split('-')[0]);
      });
      
      if (!targetTrain) {
        console.log('[FAST SELECT] Target train not found yet, continuing to monitor...');
        return;
      }
      
      console.log('[FAST SELECT] Target train found, processing immediately...');
      
      // Find and click the class immediately
      const targetClass = classTranslator(user_data.journey_details["class"]);
      const classElements = Array.from(targetTrain.querySelectorAll("table tr td div.pre-avl"));
      const classToClick = classElements.find(el => {
        const div = el.querySelector("div");
        return div && div.innerText.trim() === targetClass;
      });
      
      if (classToClick) {
        console.log('[FAST SELECT] Class found, clicking immediately...');
        classToClick.click();
        
        // Immediately start monitoring for date selection
        const dateObserver = new MutationObserver((mutations) => {
          const dateElements = Array.from(targetTrain.querySelectorAll("div div table td div.pre-avl"));
          const targetDate = new Date(user_data.journey_details.date);
          const dateString = targetDate.toDateString().split(" ")[0] + ", " + targetDate.toDateString().split(" ")[2] + " " + targetDate.toDateString().split(" ")[1];
          
          const dateToClick = dateElements.find(el => {
            const div = el.querySelector("div");
            return div && div.innerText.trim() === dateString;
          });
          
          if (dateToClick) {
            console.log('[FAST SELECT] Date found, clicking immediately...');
            dateToClick.click();
            dateObserver.disconnect();
            
            // Immediately start monitoring for book button
            const bookButtonObserver = new MutationObserver(() => {
              const bookBtn = targetTrain.querySelector("button.btnDefault.train_Search.ng-star-inserted");
              if (bookBtn && !bookBtn.classList.contains("disable-book") && !bookBtn.disabled) {
                console.log('[FAST SELECT] Book button ready, clicking immediately...');
                
                // Use throttling for book button click
                throttleRequest(() => {
                  bookBtn.click();
                  console.log('[FAST SELECT] Book button clicked with throttling');
                  return Promise.resolve();
                }, 'bookButtonClick').then(() => {
                  bookButtonObserver.disconnect();
                  clearInterval(fastInterval);
                  
                  // Start monitoring for passenger input page
                  startPassengerInputMonitor();
                }).catch((error) => {
                  console.error('[FAST SELECT] Book button click failed:', error);
                  bookButtonObserver.disconnect();
                  clearInterval(fastInterval);
                });
              }
            });
            
            bookButtonObserver.observe(targetTrain, {
              childList: true,
              subtree: true,
              attributes: true,
              attributeFilter: ['class', 'disabled']
            });
            
            // Fallback: click book button after short delay if observer doesn't work
            setTimeout(() => {
              const bookBtn = targetTrain.querySelector("button.btnDefault.train_Search.ng-star-inserted");
              if (bookBtn && !bookBtn.classList.contains("disable-book") && !bookBtn.disabled) {
                console.log('[FAST SELECT] Fallback: clicking book button...');
                
                // Use throttling for fallback book button click
                throttleRequest(() => {
                  bookBtn.click();
                  console.log('[FAST SELECT] Fallback book button clicked with throttling');
                  return Promise.resolve();
                }, 'bookButtonClickFallback').then(() => {
                  bookButtonObserver.disconnect();
                  clearInterval(fastInterval);
                  startPassengerInputMonitor();
                }).catch((error) => {
                  console.error('[FAST SELECT] Fallback book button click failed:', error);
                  bookButtonObserver.disconnect();
                  clearInterval(fastInterval);
                });
              }
            }, 200);
          }
        });
        
        dateObserver.observe(targetTrain, {
          childList: true,
          subtree: true
        });
        
        // Fallback: retry if date selection doesn't work
        setTimeout(() => {
          if (dateObserver) {
            dateObserver.disconnect();
            console.log('[FAST SELECT] Date selection timeout, retrying...');
            startFastSelection();
          }
        }, 1000);
        
        clearInterval(fastInterval);
      } else {
        console.log('[FAST SELECT] Class not found yet, continuing to monitor...');
      }
      
    } catch (error) {
      console.error('[FAST SELECT] Error in fast selection:', error);
    }
  }, 50); // Check every 50ms for maximum speed
  
  // Fallback timeout
  setTimeout(() => {
    clearInterval(fastInterval);
    console.log('[FAST SELECT] Timeout reached, falling back to original method...');
    selectJourney(); // Fallback to original method
  }, 10000);
}

// NEW FUNCTION: Monitor for passenger input page and auto-fill
function startPassengerInputMonitor() {
  console.log('[PASSENGER MONITOR] Starting passenger input page monitor...');
  
  // Reset flags when starting new monitor
  isPassengerFormSubmitted = false;
  isPassengerFormFilling = false;
  
  const passengerInterval = setInterval(() => {
    try {
      // Check if we're on passenger input page
      const passengerInput = document.querySelector("app-passenger-input");
      if (passengerInput && !isPassengerFormFilling && !isPassengerFormSubmitted) {
        console.log('[PASSENGER MONITOR] Passenger input page detected, starting auto-fill...');
        clearInterval(passengerInterval);
        
        // Set flag to prevent multiple calls
        isPassengerFormFilling = true;
        
        // Auto-fill passenger details immediately
        fillPassengerDetailsEnhanced();
      }
      
      // Check if we're on review page
      const reviewPage = document.querySelector("#divMain > div > app-review-booking");
      if (reviewPage) {
        console.log('[PASSENGER MONITOR] Review page detected, skipping passenger input...');
        clearInterval(passengerInterval);
        return;
      }
      
    } catch (error) {
      console.error('[PASSENGER MONITOR] Error:', error);
    }
  }, 100);
  
  // Fallback timeout
  setTimeout(() => {
    clearInterval(passengerInterval);
    console.log('[PASSENGER MONITOR] Timeout reached');
  }, 15000);
}

// ENHANCED PASSENGER DETAILS FILLING
function fillPassengerDetailsEnhanced() {
  console.log('[FAST FILL] Starting enhanced passenger details filling...');
  
  // Check if already filling or submitted
  if (isPassengerFormFilling && !isPassengerFormSubmitted) {
    console.log('[FAST FILL] Already filling passenger details, skipping...');
    return;
  }
  
  if (isPassengerFormSubmitted) {
    console.log('[FAST FILL] Passenger form already submitted, skipping...');
    return;
  }
  
  try {
    const passengerInput = document.querySelector("app-passenger-input");
    if (!passengerInput) {
      console.log('[FAST FILL] Passenger input not found');
      isPassengerFormFilling = false; // Reset flag
      return;
    }
    
    // Set flag to prevent multiple calls
    isPassengerFormFilling = true;
    
    console.log('[FAST FILL] Passenger input found, starting to fill data...');
    
    // Handle boarding station if specified
    if (user_data.journey_details.boarding && user_data.journey_details.boarding.length > 0) {
      console.log('[FAST FILL] Setting boarding station:', user_data.journey_details.boarding);
      
      // Set from station
      const fromStationElements = Array.from(document.getElementsByTagName("strong")).filter(el => 
        el.innerText.includes(user_data.journey_details.from.split('-')[0].trim() + " | ")
      );
      if (fromStationElements[0]) {
        fromStationElements[0].click();
        addDelay(200);
      }
      
      // Set boarding station
      const boardingStationElements = Array.from(document.getElementsByTagName("strong")).filter(el => 
        el.innerText.includes(user_data.journey_details.boarding.split('-')[0].trim())
      );
      if (boardingStationElements[0]) {
        boardingStationElements[0].click();
      }
    }
    
    // Navigate to correct passenger count
    const passengerCount = user_data.passenger_details.length;
    const infantCount = user_data.infant_details ? user_data.infant_details.length : 0;
    
    console.log('[FAST FILL] Setting passenger count:', passengerCount, 'infants:', infantCount);
    
    // Set passenger count
    for (let i = 1; i < passengerCount; i++) {
      addDelay(200);
      const prenextBtn = document.getElementsByClassName("prenext")[0];
      if (prenextBtn) {
        prenextBtn.click();
      }
    }
    
    // Set infant count
    try {
      for (let i = 0; i < infantCount; i++) {
        addDelay(200);
        const infantBtn = document.getElementsByClassName("prenext")[2];
        if (infantBtn) {
          infantBtn.click();
        }
      }
    } catch (error) {
      console.error('[FAST FILL] Add infant error:', error);
    }
    
    // Fill passenger details
    const passengerElements = [...passengerInput.querySelectorAll("app-passenger")];
    const infantElements = [...passengerInput.querySelectorAll("app-infant")];
    
    console.log('[FAST FILL] Found passenger elements:', passengerElements.length);
    console.log('[FAST FILL] Filling passenger details...');
    
    // Fill each passenger
    user_data.passenger_details.forEach((passenger, index) => {
      if (passengerElements[index]) {
        const element = passengerElements[index];
        
        // Name
        const nameInput = element.querySelector("p-autocomplete > span > input");
        if (nameInput) {
          nameInput.value = passenger.name;
          nameInput.dispatchEvent(new Event("input", { bubbles: true }));
          console.log('[FAST FILL] Filled name:', passenger.name);
        }
        
        // Age
        const ageInput = element.querySelector("input[type='number'][formcontrolname='passengerAge']");
        if (ageInput) {
          ageInput.value = passenger.age;
          ageInput.dispatchEvent(new Event('input'));
          console.log('[FAST FILL] Filled age:', passenger.age);
        }
        
        // Gender
        const genderSelect = element.querySelector("select[formcontrolname='passengerGender']");
        if (genderSelect) {
          genderSelect.value = passenger.gender;
          genderSelect.dispatchEvent(new Event("change"));
          console.log('[FAST FILL] Filled gender:', passenger.gender);
        }
        
        // Berth choice
        const berthSelect = element.querySelector("select[formcontrolname='passengerBerthChoice']");
        if (berthSelect) {
          berthSelect.value = passenger.berth;
          berthSelect.dispatchEvent(new Event("change"));
          console.log('[FAST FILL] Filled berth:', passenger.berth);
        }
        
        // Food choice
        const foodSelect = element.querySelector("select[formcontrolname='passengerFoodChoice']");
        if (foodSelect) {
          foodSelect.value = passenger.food;
          foodSelect.dispatchEvent(new Event("change"));
          console.log('[FAST FILL] Filled food:', passenger.food);
        }
        
        // Child berth flag
        try {
          const childBerthCheckbox = element.querySelector("input[type='checkbox'][formcontrolname='childBerthFlag']");
          console.log('[FAST FILL] Child berth check:', index, passenger.passengerchildberth);
          if (childBerthCheckbox && passenger.passengerchildberth) {
            console.log('[FAST FILL] Setting child half seat');
            childBerthCheckbox.click();
            addDelay(200);
            
            // Handle confirmation dialog
            const confirmDialog = document.evaluate("//div[contains(text(),'No berth will be allotted for child and')]", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            if (confirmDialog) {
              console.log('[FAST FILL] Clicking OK on child berth dialog');
              const confirmBtn = document.querySelector("app-passenger > p-dialog > div > div > div > p-footer > button");
              if (confirmBtn) {
                confirmBtn.click();
                addDelay(200);
              }
            }
          }
        } catch (error) {
          console.error('[FAST FILL] Child berth error:', error);
        }
      }
    });
    
    // Fill infant details
    try {
      user_data.infant_details.forEach((infant, index) => {
        if (infantElements[index]) {
          const element = infantElements[index];
          
          // Name
          const nameInput = element.querySelector("input#infant-name[name='infant-name']");
          if (nameInput) {
            nameInput.value = infant.name;
            nameInput.dispatchEvent(new Event("input"));
            console.log('[FAST FILL] Filled infant name:', infant.name);
          }
          
          // Age
          const ageSelect = element.querySelector("select[formcontrolname='age']");
          if (ageSelect) {
            ageSelect.value = infant.age;
            ageSelect.dispatchEvent(new Event('change'));
            console.log('[FAST FILL] Filled infant age:', infant.age);
          }
          
          // Gender
          const genderSelect = element.querySelector("select[formcontrolname='gender']");
          if (genderSelect) {
            genderSelect.value = infant.gender;
            genderSelect.dispatchEvent(new Event("change"));
            console.log('[FAST FILL] Filled infant gender:', infant.gender);
          }
        }
      });
    } catch (error) {
      console.error('[FAST FILL] Fill infant error:', error);
    }
    
    // Fill mobile number
    if (user_data.other_preferences.mobileNumber && user_data.other_preferences.mobileNumber !== '') {
      const mobileInput = passengerInput.querySelector("input#mobileNumber[formcontrolname='mobileNumber'][name='mobileNumber']");
      if (mobileInput) {
        mobileInput.value = user_data.other_preferences.mobileNumber;
        mobileInput.dispatchEvent(new Event("input", { bubbles: true }));
        mobileInput.dispatchEvent(new Event("change", { bubbles: true }));
        console.log('[FAST FILL] Filled mobile number:', user_data.other_preferences.mobileNumber);
      }
    }
    
    // Set payment type
    const paymentRadios = [...passengerInput.querySelectorAll("p-radiobutton[formcontrolname='paymentType'][name='paymentType'] input[type='radio']")];
    addDelay(100);
    const paymentValue = user_data.other_preferences.paymentmethod.includes("UPI") ? '2' : '1';
    const selectedRadio = paymentRadios.filter(radio => radio.value === paymentValue)[0];
    if (selectedRadio) {
      selectedRadio.click();
      console.log('[FAST FILL] Set payment type:', paymentValue);
    }
    
    // Set auto upgradation
    const autoUpgradeCheckbox = passengerInput.querySelector("input#autoUpgradation[type='checkbox'][formcontrolname='autoUpgradationSelected']");
    if (autoUpgradeCheckbox && user_data.other_preferences.hasOwnProperty("autoUpgradation") && user_data.other_preferences.autoUpgradation) {
      autoUpgradeCheckbox.checked = user_data.other_preferences.autoUpgradation || false;
      console.log('[FAST FILL] Set auto upgradation:', user_data.other_preferences.autoUpgradation);
    }
    
    // Set confirm berths
    const confirmBerthsCheckbox = passengerInput.querySelector("input#confirmberths[type='checkbox'][formcontrolname='bookOnlyIfCnf']");
    if (confirmBerthsCheckbox && user_data.other_preferences.hasOwnProperty("confirmberths") && user_data.other_preferences.confirmberths) {
      confirmBerthsCheckbox.checked = user_data.other_preferences.confirmberths || false;
      console.log('[FAST FILL] Set confirm berths:', user_data.other_preferences.confirmberths);
    }
    
    // Set travel insurance
    const insuranceRadios = [...passengerInput.querySelectorAll("p-radiobutton[formcontrolname='travelInsuranceOpted'] input[type='radio'][name='travelInsuranceOpted-0']")];
    addDelay(200);
    const insuranceValue = user_data.travel_preferences.travelInsuranceOpted === 'yes' ? "true" : "false";
    const selectedInsuranceRadio = insuranceRadios.filter(radio => radio.value === insuranceValue)[0];
    if (selectedInsuranceRadio) {
      selectedInsuranceRadio.click();
      console.log('[FAST FILL] Set travel insurance:', insuranceValue);
    }
    
    // Set preferred coach and reservation choice
    try {
      const coachInput = passengerInput.querySelector("input[formcontrolname='coachId']");
      if (coachInput && user_data.travel_preferences.hasOwnProperty('prefcoach') && user_data.travel_preferences.prefcoach.trim().length > 0) {
        console.log('[FAST FILL] Setting preferred coach ID');
        coachInput.value = user_data.travel_preferences.prefcoach;
      }
      
      const reservationDropdown = passengerInput.querySelector("p-dropdown[formcontrolname='reservationChoice']");
      if (reservationDropdown && user_data.travel_preferences.hasOwnProperty("reservationchoice") && !user_data.travel_preferences.reservationchoice.includes("Reservation Choice")) {
        console.log('[FAST FILL] Setting reservation choice');
        reservationDropdown.querySelector("div > div[role='button']").click();
        addDelay(200);
        const reservationOption = [...reservationDropdown.querySelectorAll("ul li")].filter(option => 
          option.innerText === user_data.travel_preferences.reservationchoice
        )[0];
        if (reservationOption) {
          reservationOption.click();
        }
      }
    } catch (error) {
      console.error('[FAST FILL] Preferred coach and reservation choice error:', error);
    }
    
    console.log('[FAST FILL] Passenger details filled successfully');
    
    // Auto-submit after filling
    setTimeout(() => {
      // Check if already submitted
      if (isPassengerFormSubmitted) {
        console.log('[FAST FILL] Form already submitted, skipping...');
        return;
      }
      
      console.log('[FAST FILL] Auto-submitting passenger form...');
      
      // Set submitted flag immediately to prevent multiple submissions
      isPassengerFormSubmitted = true;
      isPassengerFormFilling = false;
      
      // Use the original submit function
      submitPassengerDetailsForm(passengerInput);
      
      // Start server delay monitoring after successful submission
      setTimeout(() => {
        handleServerDelayAfterSubmission();
      }, 1000);
      
    }, 500);
    
  } catch (error) {
    console.error('[FAST FILL] Error filling passenger details:', error);
    // Reset flags on error
    isPassengerFormFilling = false;
    isPassengerFormSubmitted = false;
  }
}

// NEW FUNCTION: Auto-trigger availability check when page loads
function startAvailabilityCheckMonitor() {
  console.log('[AVAILABILITY MONITOR] Starting availability check monitor...');
  
  // Check if we're on the train search page
  if (!window.location.href.includes('train-search')) {
    return;
  }
  
  // Only proceed if AvailabilityCheck is set to 'A' (Automatic)
  if (user_data.travel_preferences.AvailabilityCheck !== 'A') {
    console.log('[AVAILABILITY MONITOR] AvailabilityCheck not set to automatic, skipping...');
    return;
  }
  
  let formFilled = false;
  
  const availabilityInterval = setInterval(() => {
    try {
      // First, try to auto-fill the form if not already filled
      if (!formFilled) {
        formFilled = autoFillTrainSearchForm();
        if (formFilled) {
          console.log('[AVAILABILITY MONITOR] Form filled, waiting for search button...');
        }
      }
      
      // Look for the search button or form submit button
      const searchBtn = document.querySelector("button.search_btn.train_Search[type='submit']") ||
                       document.querySelector("button.btnDefault.train_Search[type='submit']") ||
                       document.querySelector("button[type='submit']") ||
                       document.querySelector(".search_btn") ||
                       document.querySelector("button:contains('Search')") ||
                       document.querySelector("button:contains('Find Trains')") ||
                       document.querySelector("button:contains('Check Availability')");
      
      if (searchBtn && !searchBtn.disabled) {
        console.log('[AVAILABILITY MONITOR] Search button found, checking if form is filled...');
        
        // Check if the form has required data
        const fromStation = document.querySelector("input[formcontrolname='origin']") ||
                           document.querySelector("input[placeholder*='From']") ||
                           document.querySelector("input[name='origin']");
        
        const toStation = document.querySelector("input[formcontrolname='destination']") ||
                         document.querySelector("input[placeholder*='To']") ||
                         document.querySelector("input[name='destination']");
        
        const journeyDate = document.querySelector("input[formcontrolname='journeyDate']") ||
                           document.querySelector("input[type='date']") ||
                           document.querySelector("input[name='journeyDate']");
        
        if (fromStation && toStation && journeyDate && 
            fromStation.value && toStation.value && journeyDate.value) {
          
          console.log('[AVAILABILITY MONITOR] Form is filled, triggering search automatically...');
          clearInterval(availabilityInterval);
          
          // Add a small delay to ensure form is fully loaded
          setTimeout(() => {
            // Use throttling for search button click
            throttleRequest(() => {
              searchBtn.click();
              console.log('[AVAILABILITY MONITOR] Search button clicked with throttling');
              return Promise.resolve();
            }, 'searchButtonClick').then(() => {
              console.log('[AVAILABILITY MONITOR] Search button click completed');
            }).catch((error) => {
              console.error('[AVAILABILITY MONITOR] Search button click failed:', error);
            });
          }, 500);
        }
      }
      
    } catch (error) {
      console.error('[AVAILABILITY MONITOR] Error:', error);
    }
  }, 1000); // Check every second
  
  // Stop monitoring after 30 seconds
  setTimeout(() => {
    clearInterval(availabilityInterval);
    console.log('[AVAILABILITY MONITOR] Monitoring stopped after timeout');
  }, 30000);
}

// NEW FUNCTION: Auto-fill train search form
function autoFillTrainSearchForm() {
  console.log('[AUTO FILL] Starting auto-fill of train search form...');
  
  try {
    // Fill from station
    const fromStation = document.querySelector("input[formcontrolname='origin']") ||
                       document.querySelector("input[placeholder*='From']") ||
                       document.querySelector("input[name='origin']");
    
    if (fromStation && user_data.journey_details.from) {
      fromStation.value = user_data.journey_details.from;
      fromStation.dispatchEvent(new Event('input', { bubbles: true }));
      fromStation.dispatchEvent(new Event('change', { bubbles: true }));
      console.log('[AUTO FILL] From station filled:', user_data.journey_details.from);
    }
    
    // Fill destination station
    const toStation = document.querySelector("input[formcontrolname='destination']") ||
                     document.querySelector("input[placeholder*='To']") ||
                     document.querySelector("input[name='destination']");
    
    if (toStation && user_data.journey_details.destination) {
      toStation.value = user_data.journey_details.destination;
      toStation.dispatchEvent(new Event('input', { bubbles: true }));
      toStation.dispatchEvent(new Event('change', { bubbles: true }));
      console.log('[AUTO FILL] Destination station filled:', user_data.journey_details.destination);
    }
    
    // Fill journey date
    const journeyDate = document.querySelector("input[formcontrolname='journeyDate']") ||
                       document.querySelector("input[type='date']") ||
                       document.querySelector("input[name='journeyDate']");
    
    if (journeyDate && user_data.journey_details.date) {
      // Convert date format from DD-MM-YYYY to YYYY-MM-DD
      const dateParts = user_data.journey_details.date.split('-');
      const formattedDate = `${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`;
      
      journeyDate.value = formattedDate;
      journeyDate.dispatchEvent(new Event('input', { bubbles: true }));
      journeyDate.dispatchEvent(new Event('change', { bubbles: true }));
      console.log('[AUTO FILL] Journey date filled:', formattedDate);
    }
    
    // Fill class if available
    const classSelect = document.querySelector("select[formcontrolname='class']") ||
                       document.querySelector("select[name='class']");
    
    if (classSelect && user_data.journey_details.class) {
      classSelect.value = user_data.journey_details.class;
      classSelect.dispatchEvent(new Event('change', { bubbles: true }));
      console.log('[AUTO FILL] Class filled:', user_data.journey_details.class);
    }
    
    // Fill quota if available
    const quotaSelect = document.querySelector("select[formcontrolname='quota']") ||
                       document.querySelector("select[name='quota']");
    
    if (quotaSelect && user_data.journey_details.quota) {
      quotaSelect.value = user_data.journey_details.quota;
      quotaSelect.dispatchEvent(new Event('change', { bubbles: true }));
      console.log('[AUTO FILL] Quota filled:', user_data.journey_details.quota);
    }
    
    console.log('[AUTO FILL] Train search form auto-filled successfully');
    return true;
    
  } catch (error) {
    console.error('[AUTO FILL] Error filling train search form:', error);
    return false;
  }
}

// ENHANCED: Add page load listener to start availability check monitoring
document.addEventListener('DOMContentLoaded', () => {
  console.log('[PAGE LOAD] DOM loaded, starting availability check monitor...');
  startAvailabilityCheckMonitor();
  
  // Also check for existing search results
  setTimeout(() => {
    checkForExistingSearchResults();
  }, 2000);
});

// Also listen for page changes (for SPA navigation)
let lastUrl = location.href;
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    console.log('[PAGE CHANGE] URL changed to:', url);
    
    // Reset passenger form flags on page change
    resetPassengerFormFlags();
    
    setTimeout(() => {
      startAvailabilityCheckMonitor();
    }, 1000);
  }
}).observe(document, { subtree: true, childList: true });

// ENHANCED: Add click event listener for availability check button
document.addEventListener('click', (event) => {
  // Check if the clicked element is an availability check button
  const target = event.target;
  const isAvailabilityButton = target.matches && (
    target.matches("button.search_btn.train_Search[type='submit']") ||
    target.matches("button.btnDefault.train_Search[type='submit']") ||
    target.matches("button[type='submit']") ||
    target.matches(".search_btn") ||
    target.textContent.includes('Search') ||
    target.textContent.includes('Find Trains') ||
    target.textContent.includes('Check Availability')
  );
  
  if (isAvailabilityButton) {
    console.log('[CLICK DETECTED] Availability check button clicked manually');
    
    // If AvailabilityCheck is set to 'A' (Automatic), start monitoring for results
    if (user_data.travel_preferences.AvailabilityCheck === 'A') {
      console.log('[CLICK DETECTED] Starting automatic journey selection after manual click...');
      
      // Wait for the search results to load, then start automatic selection
      setTimeout(() => {
        const trainList = document.querySelector("#divMain > div > app-train-list");
        if (trainList) {
          console.log('[CLICK DETECTED] Train list found, starting automatic selection...');
          
          // Use throttling for journey selection after manual click
          throttleRequest(() => {
            return selectJourneyEnhanced();
          }, 'manualClickJourneySelection').then(() => {
            console.log('[CLICK DETECTED] Journey selection completed after manual click');
          }).catch((error) => {
            console.error('[CLICK DETECTED] Journey selection failed after manual click:', error);
          });
        } else {
          console.log('[CLICK DETECTED] Train list not found yet, will monitor...');
          // Start monitoring for train list
          const trainListObserver = new MutationObserver(() => {
            const trainList = document.querySelector("#divMain > div > app-train-list");
            if (trainList) {
              console.log('[CLICK DETECTED] Train list appeared, starting automatic selection...');
              trainListObserver.disconnect();
              
              // Use throttling for journey selection after manual click
              throttleRequest(() => {
                return selectJourneyEnhanced();
              }, 'manualClickJourneySelection').then(() => {
                console.log('[CLICK DETECTED] Journey selection completed after manual click');
              }).catch((error) => {
                console.error('[CLICK DETECTED] Journey selection failed after manual click:', error);
              });
            }
          });
          
          trainListObserver.observe(document.body, {
            childList: true,
            subtree: true
          });
          
          // Fallback timeout
          setTimeout(() => {
            trainListObserver.disconnect();
            console.log('[CLICK DETECTED] Timeout reached, trying to start selection anyway...');
            
            // Use throttling for fallback journey selection
            throttleRequest(() => {
              return selectJourneyEnhanced();
            }, 'manualClickJourneySelectionFallback').then(() => {
              console.log('[CLICK DETECTED] Fallback journey selection completed');
            }).catch((error) => {
              console.error('[CLICK DETECTED] Fallback journey selection failed:', error);
            });
          }, 10000);
        }
      }, 2000); // Wait 2 seconds for search results to load
    }
  }
});

// NEW FUNCTION: Check if search results are already present and start automation
function checkForExistingSearchResults() {
  console.log('[EXISTING RESULTS] Checking for existing search results...');
  
  // Check if we're on the train search page and have results
  if (!window.location.href.includes('train-search')) {
    return;
  }
  
  // Only proceed if AvailabilityCheck is set to 'A' (Automatic)
  if (user_data.travel_preferences.AvailabilityCheck !== 'A') {
    console.log('[EXISTING RESULTS] AvailabilityCheck not set to automatic, skipping...');
    return;
  }
  
  // Check if train list is already present
  const trainList = document.querySelector("#divMain > div > app-train-list");
  if (trainList) {
    console.log('[EXISTING RESULTS] Train list found, checking for target train...');
    
    // Check if loader is still visible
    const loader = document.querySelector("#loaderP");
    if (loader && loader.style.display !== "none") {
      console.log('[EXISTING RESULTS] Loader still visible, waiting...');
      
      // Wait for loader to disappear
      const loaderObserver = new MutationObserver(() => {
        if (loader.style.display === "none") {
          console.log('[EXISTING RESULTS] Loader disappeared, starting selection...');
          loaderObserver.disconnect();
          selectJourneyEnhanced();
        }
      });
      
      loaderObserver.observe(loader, {
        attributes: true,
        attributeFilter: ['style']
      });
      
      // Fallback timeout
      setTimeout(() => {
        loaderObserver.disconnect();
        console.log('[EXISTING RESULTS] Loader timeout, starting selection anyway...');
        selectJourneyEnhanced();
      }, 10000);
      
      return;
    }
    
    // If no loader, start selection immediately
    console.log('[EXISTING RESULTS] No loader, starting selection immediately...');
    selectJourneyEnhanced();
  }
}

// NEW FUNCTION: Auto-refresh functionality for booking times
function startAutoRefreshMonitor() {
  console.log('[AUTO REFRESH] Starting auto-refresh monitor...');
  
  // Check if we're on the train search page
  if (!window.location.href.includes('train-search')) {
    console.log('[AUTO REFRESH] Not on train search page, skipping...');
    return;
  }
  
  // Only proceed if AvailabilityCheck is set to 'A' (Automatic)
  if (user_data.travel_preferences.AvailabilityCheck !== 'A') {
    console.log('[AUTO REFRESH] AvailabilityCheck not set to automatic, skipping...');
    return;
  }
  
  // Get the target booking time based on class and quota
  const targetClass = user_data.journey_details["class"];
  const quota = user_data.journey_details.quota;
  let targetTime = null;
  
  if (quota === 'GN') {
    targetTime = user_data.other_preferences.gnbooktime || "08:09:59";
    console.log('[AUTO REFRESH] GN quota detected, target time:', targetTime);
  } else if (quota === 'TQ' || quota === 'PT') {
    if (['1A', '2A', '3A', 'CC', 'EC', '3E'].includes(targetClass.toUpperCase())) {
      targetTime = user_data.other_preferences.acbooktime || "09:59:59";
      console.log('[AUTO REFRESH] AC class tatkal detected, target time:', targetTime);
    } else {
      targetTime = user_data.other_preferences.slbooktime || "10:59:59";
      console.log('[AUTO REFRESH] SL class tatkal detected, target time:', targetTime);
    }
  } else {
    console.log('[AUTO REFRESH] No specific booking time required for this quota/class');
    return;
  }
  
  if (!targetTime) {
    console.log('[AUTO REFRESH] No target time set, skipping...');
    return;
  }
  
  // Parse target time
  const [targetHour, targetMinute, targetSecond] = targetTime.split(':').map(Number);
  
  // Show countdown message
  showAutoRefreshCountdown(targetTime);
  
  // Start monitoring time
  const refreshInterval = setInterval(() => {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    const currentSecond = now.getSeconds();
    
    // Check if it's time to refresh
    if (currentHour === targetHour && currentMinute === targetMinute && currentSecond >= targetSecond) {
      console.log('[AUTO REFRESH] Target time reached! Refreshing page...');
      clearInterval(refreshInterval);
      
      // Remove countdown message
      const countdownMsg = document.querySelector('.auto-refresh-countdown');
      if (countdownMsg) countdownMsg.remove();
      
      // Refresh the page
      window.location.reload();
    }
    
    // Update countdown display
    updateAutoRefreshCountdown(targetHour, targetMinute, targetSecond);
    
  }, 100); // Check every 100ms for precise timing
  
  // Fallback: also check every second for broader time monitoring
  const fallbackInterval = setInterval(() => {
    const now = new Date();
    const currentTime = now.toTimeString().split(' ')[0];
    
    if (currentTime >= targetTime) {
      console.log('[AUTO REFRESH] Fallback: Target time reached! Refreshing page...');
      clearInterval(fallbackInterval);
      clearInterval(refreshInterval);
      
      // Remove countdown message
      const countdownMsg = document.querySelector('.auto-refresh-countdown');
      if (countdownMsg) countdownMsg.remove();
      
      // Refresh the page
      window.location.reload();
    }
  }, 1000);
  
  // Stop monitoring after 1 hour to prevent infinite monitoring
  setTimeout(() => {
    clearInterval(refreshInterval);
    clearInterval(fallbackInterval);
    console.log('[AUTO REFRESH] Monitoring stopped after 1 hour');
    
    // Remove countdown message
    const countdownMsg = document.querySelector('.auto-refresh-countdown');
    if (countdownMsg) countdownMsg.remove();
  }, 3600000); // 1 hour
}

// Function to show auto-refresh countdown
function showAutoRefreshCountdown(targetTime) {
  try {
    // Remove existing countdown if any
    const existingCountdown = document.querySelector('.auto-refresh-countdown');
    if (existingCountdown) existingCountdown.remove();
    
    // Create countdown message
    const countdownDiv = document.createElement('div');
    countdownDiv.className = 'auto-refresh-countdown';
    countdownDiv.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: rgba(0, 0, 0, 0.9);
      color: white;
      padding: 15px;
      border-radius: 10px;
      z-index: 10000;
      font-family: Arial, sans-serif;
      font-size: 14px;
      text-align: center;
      box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    `;
    
    countdownDiv.innerHTML = `
      <div style="font-weight: bold; margin-bottom: 5px;">Auto-Refresh Countdown</div>
      <div style="font-size: 12px; margin-bottom: 5px;">Target Time: ${targetTime}</div>
      <div id="auto-refresh-timer" style="font-size: 18px; font-weight: bold; color: #ffeb3b;"></div>
      <div style="font-size: 11px; margin-top: 5px;">Page will refresh automatically</div>
    `;
    
    document.body.appendChild(countdownDiv);
    console.log('[AUTO REFRESH] Countdown message displayed');
    
  } catch (error) {
    console.error('[AUTO REFRESH] Error showing countdown:', error);
  }
}

// Function to update auto-refresh countdown
function updateAutoRefreshCountdown(targetHour, targetMinute, targetSecond) {
  try {
    const timerElement = document.getElementById('auto-refresh-timer');
    if (!timerElement) return;
    
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    const currentSecond = now.getSeconds();
    
    // Calculate time difference
    let diffHours = targetHour - currentHour;
    let diffMinutes = targetMinute - currentMinute;
    let diffSeconds = targetSecond - currentSecond;
    
    // Handle negative values
    if (diffSeconds < 0) {
      diffSeconds += 60;
      diffMinutes--;
    }
    if (diffMinutes < 0) {
      diffMinutes += 60;
      diffHours--;
    }
    if (diffHours < 0) {
      diffHours += 24;
    }
    
    // Format time display
    const timeString = `${String(diffHours).padStart(2, '0')}:${String(diffMinutes).padStart(2, '0')}:${String(diffSeconds).padStart(2, '0')}`;
    timerElement.textContent = timeString;
    
    // Change color when close to target time
    if (diffHours === 0 && diffMinutes < 5) {
      timerElement.style.color = '#ff5722';
    } else if (diffHours === 0 && diffMinutes < 1) {
      timerElement.style.color = '#f44336';
    }
    
  } catch (error) {
    console.error('[AUTO REFRESH] Error updating countdown:', error);
  }
}

// ENHANCED: Update page load listener to also start auto-refresh monitoring
document.addEventListener('DOMContentLoaded', () => {
  console.log('[PAGE LOAD] DOM loaded, starting availability check monitor...');
  startAvailabilityCheckMonitor();
  
  // Also check for existing search results
  setTimeout(() => {
    checkForExistingSearchResults();
  }, 2000);
  
  // Start auto-refresh monitoring
  setTimeout(() => {
    startAutoRefreshMonitor();
  }, 3000);
});

// ENHANCED: More comprehensive error handling for request under process
function handleRequestUnderProcessError() {
  const errorSelectors = [
    'div:contains("Your request is under process")',
    'div:contains("Don not submit multiple request")',
    'div:contains("Request is being processed")',
    'div:contains("Please wait")',
    'div:contains("Processing your request")',
    '.toast-error',
    '.error-message',
    '.alert-danger'
  ];
  
  let errorFound = false;
  
  // Check for error messages in page text
  const pageText = document.body.innerText || '';
  const errorMessages = [
    'your request is under process',
    'don not submit multiple request',
    'request is being processed',
    'please wait',
    'processing your request',
    'multiple request',
    'under process'
  ];
  
  errorFound = errorMessages.some(msg => 
    pageText.toLowerCase().includes(msg.toLowerCase())
  );
  
  // Also check for specific error elements
  if (!errorFound) {
    errorSelectors.forEach(selector => {
      try {
        const element = document.querySelector(selector);
        if (element && element.offsetParent !== null) {
          errorFound = true;
        }
      } catch (e) {
        // Ignore selector errors
      }
    });
  }
  
  if (errorFound) {
    console.log('[ERROR HANDLER] Request under process error detected!');
    
    // Clear all request queues
    clearRequestQueue();
    
    // Reset passenger form flags
    resetPassengerFormFlags();
    
    // Show user-friendly message
    showErrorMessage('Request is being processed. Please wait...');
    
    // Wait longer before allowing new requests
    setTimeout(() => {
      isRequestInProgress = false;
      lastRequestTime = 0;
      console.log('[ERROR HANDLER] Error recovery complete, allowing new requests');
      
      // Remove error message
      const errorMsg = document.querySelector('.error-handler-message');
      if (errorMsg) errorMsg.remove();
    }, 15000); // Wait 15 seconds after error
    
    return true;
  }
  
  return false;
}

// Function to show error message
function showErrorMessage(message) {
  try {
    // Remove existing error message
    const existingMsg = document.querySelector('.error-handler-message');
    if (existingMsg) existingMsg.remove();
    
    // Create error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-handler-message';
    errorDiv.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(244, 67, 54, 0.95);
      color: white;
      padding: 20px;
      border-radius: 10px;
      z-index: 10001;
      font-family: Arial, sans-serif;
      font-size: 16px;
      text-align: center;
      box-shadow: 0 4px 8px rgba(0,0,0,0.3);
      max-width: 400px;
    `;
    
    errorDiv.innerHTML = `
      <div style="font-weight: bold; margin-bottom: 10px;">⚠️ Request Error</div>
      <div>${message}</div>
      <div style="font-size: 12px; margin-top: 10px;">Automatically recovering...</div>
    `;
    
    document.body.appendChild(errorDiv);
    
    // Auto-remove after 10 seconds
    setTimeout(() => {
      if (errorDiv.parentNode) {
        errorDiv.remove();
      }
    }, 10000);
    
  } catch (error) {
    console.error('[ERROR HANDLER] Error showing error message:', error);
  }
}

// Enhanced error monitoring
setInterval(() => {
  handleRequestUnderProcessError();
}, 1000); // Check every second

// NEW FUNCTION: Handle server delay after passenger form submission
function handleServerDelayAfterSubmission() {
  console.log('[SERVER DELAY] Starting server delay monitoring after passenger submission...');
  
  // Show waiting message
  showServerDelayMessage();
  
  let delayStartTime = Date.now();
  let isProcessingComplete = false;
  
  // Monitor for various completion indicators
  const delayInterval = setInterval(() => {
    try {
      const currentTime = Date.now();
      const elapsedSeconds = Math.floor((currentTime - delayStartTime) / 1000);
      
      // Update countdown message
      updateServerDelayMessage(elapsedSeconds);
      
      // Check for completion indicators
      const completionIndicators = [
        // Review page
        document.querySelector("#divMain > div > app-review-booking"),
        document.querySelector("app-review-booking"),
        // Payment page
        document.querySelector("app-payment-options"),
        document.querySelector("#divMain > div > app-payment-options"),
        // Booking confirmation
        document.querySelector("app-booking-confirm"),
        document.querySelector("#divMain > div > app-booking-confirm"),
        // Error messages
        document.querySelector(".error-message"),
        document.querySelector(".alert-danger"),
        document.querySelector(".toast-error")
      ];
      
      // Check if any completion indicator is found
      const hasCompletionIndicator = completionIndicators.some(indicator => 
        indicator && indicator.offsetParent !== null
      );
      
      if (hasCompletionIndicator) {
        console.log('[SERVER DELAY] Processing complete, found completion indicator');
        isProcessingComplete = true;
        clearInterval(delayInterval);
        removeServerDelayMessage();
        
        // Handle the next step based on what page we're on
        handlePostSubmissionNavigation();
        return;
      }
      
      // Check for error messages
      const pageText = document.body.innerText || '';
      const errorMessages = [
        'your request is under process',
        'don not submit multiple request',
        'request is being processed',
        'please wait',
        'processing your request',
        'multiple request',
        'under process',
        'session expired',
        'timeout',
        'error'
      ];
      
      const hasError = errorMessages.some(msg => 
        pageText.toLowerCase().includes(msg.toLowerCase())
      );
      
      if (hasError) {
        console.log('[SERVER DELAY] Error detected during processing');
        clearInterval(delayInterval);
        removeServerDelayMessage();
        
        // Handle error
        handleServerDelayError();
        return;
      }
      
      // Check if we're still on passenger input page (should have moved by now)
      const stillOnPassengerPage = document.querySelector("app-passenger-input");
      if (stillOnPassengerPage && elapsedSeconds > 60) {
        console.log('[SERVER DELAY] Still on passenger page after 60 seconds, may be stuck');
        clearInterval(delayInterval);
        removeServerDelayMessage();
        
        // Try to detect if form submission failed
        handleStuckOnPassengerPage();
        return;
      }
      
      // Maximum wait time (2 minutes)
      if (elapsedSeconds > 120) {
        console.log('[SERVER DELAY] Maximum wait time reached');
        clearInterval(delayInterval);
        removeServerDelayMessage();
        
        // Handle timeout
        handleServerDelayTimeout();
        return;
      }
      
    } catch (error) {
      console.error('[SERVER DELAY] Error in delay monitoring:', error);
    }
  }, 1000); // Check every second
  
  // Fallback: also monitor for URL changes
  const urlObserver = new MutationObserver(() => {
    if (isProcessingComplete) return;
    
    const currentUrl = window.location.href;
    if (currentUrl !== lastUrl) {
      console.log('[SERVER DELAY] URL changed during delay monitoring');
      isProcessingComplete = true;
      clearInterval(delayInterval);
      removeServerDelayMessage();
      urlObserver.disconnect();
      
      // Handle the navigation
      handlePostSubmissionNavigation();
    }
  });
  
  urlObserver.observe(document, { subtree: true, childList: true });
}

// Function to show server delay message
function showServerDelayMessage() {
  try {
    // Remove existing message if any
    const existingMsg = document.querySelector('.server-delay-message');
    if (existingMsg) existingMsg.remove();
    
    // Create delay message
    const delayDiv = document.createElement('div');
    delayDiv.className = 'server-delay-message';
    delayDiv.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: rgba(33, 150, 243, 0.95);
      color: white;
      padding: 25px;
      border-radius: 15px;
      z-index: 10002;
      font-family: Arial, sans-serif;
      font-size: 16px;
      text-align: center;
      box-shadow: 0 8px 16px rgba(0,0,0,0.3);
      max-width: 450px;
      min-width: 350px;
    `;
    
    delayDiv.innerHTML = `
      <div style="font-weight: bold; margin-bottom: 15px; font-size: 18px;">⏳ Server Processing</div>
      <div style="margin-bottom: 10px;">IRCTC server is processing your request...</div>
      <div id="server-delay-timer" style="font-size: 24px; font-weight: bold; color: #ffeb3b; margin: 10px 0;"></div>
      <div style="font-size: 12px; margin-top: 10px; opacity: 0.8;">
        This may take 35-50 seconds during tatkal time
      </div>
      <div style="font-size: 11px; margin-top: 5px; opacity: 0.6;">
        Please do not refresh the page
      </div>
    `;
    
    document.body.appendChild(delayDiv);
    console.log('[SERVER DELAY] Delay message displayed');
    
  } catch (error) {
    console.error('[SERVER DELAY] Error showing delay message:', error);
  }
}

// Function to update server delay message
function updateServerDelayMessage(elapsedSeconds) {
  try {
    const timerElement = document.getElementById('server-delay-timer');
    if (!timerElement) return;
    
    const minutes = Math.floor(elapsedSeconds / 60);
    const seconds = elapsedSeconds % 60;
    const timeString = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    
    timerElement.textContent = timeString;
    
    // Change color based on elapsed time
    if (elapsedSeconds > 45) {
      timerElement.style.color = '#ff5722'; // Orange
    } else if (elapsedSeconds > 30) {
      timerElement.style.color = '#ff9800'; // Light orange
    }
    
  } catch (error) {
    console.error('[SERVER DELAY] Error updating delay message:', error);
  }
}

// Function to remove server delay message
function removeServerDelayMessage() {
  try {
    const delayMsg = document.querySelector('.server-delay-message');
    if (delayMsg) {
      delayMsg.remove();
      console.log('[SERVER DELAY] Delay message removed');
    }
  } catch (error) {
    console.error('[SERVER DELAY] Error removing delay message:', error);
  }
}

// Function to handle post-submission navigation
function handlePostSubmissionNavigation() {
  console.log('[POST SUBMISSION] Handling post-submission navigation...');
  
  // Check what page we're on and handle accordingly
  const currentUrl = window.location.href;
  
  if (currentUrl.includes('review-booking') || document.querySelector("app-review-booking")) {
    console.log('[POST SUBMISSION] On review page, starting review process...');
    // Start review booking process
    setTimeout(() => {
      chrome.runtime.sendMessage(getMsg("reviewBooking", {}));
    }, 1000);
  } else if (currentUrl.includes('payment-options') || document.querySelector("app-payment-options")) {
    console.log('[POST SUBMISSION] On payment page, starting payment process...');
    // Start payment process
    setTimeout(() => {
      chrome.runtime.sendMessage(getMsg("bkgPaymentOptions", {}));
    }, 1000);
  } else if (currentUrl.includes('booking-confirm') || document.querySelector("app-booking-confirm")) {
    console.log('[POST SUBMISSION] On booking confirmation page...');
    // Handle booking confirmation
    handleBookingConfirmation();
  } else {
    console.log('[POST SUBMISSION] Unknown page after submission, monitoring...');
    // Start general monitoring
    startBookingConfirmationMonitor();
  }
}

// Function to handle server delay error
function handleServerDelayError() {
  console.log('[SERVER DELAY] Handling server delay error...');
  
  // Show error message
  showErrorMessage('Server processing error. Please check the page and try again.');
  
  // Reset flags to allow retry
  resetPassengerFormFlags();
  
  // Wait before allowing new requests
  setTimeout(() => {
    isRequestInProgress = false;
    lastRequestTime = 0;
    console.log('[SERVER DELAY] Error recovery complete');
  }, 10000);
}

// Function to handle stuck on passenger page
function handleStuckOnPassengerPage() {
  console.log('[SERVER DELAY] Handling stuck on passenger page...');
  
  // Show warning message
  showErrorMessage('Form submission may have failed. Please check the page.');
  
  // Reset flags to allow retry
  resetPassengerFormFlags();
  
  // Wait before allowing new requests
  setTimeout(() => {
    isRequestInProgress = false;
    lastRequestTime = 0;
    console.log('[SERVER DELAY] Stuck page recovery complete');
  }, 5000);
}

// Function to handle server delay timeout
function handleServerDelayTimeout() {
  console.log('[SERVER DELAY] Handling server delay timeout...');
  
  // Show timeout message
  showErrorMessage('Server processing timeout. Please check the page status.');
  
  // Reset flags to allow retry
  resetPassengerFormFlags();
  
  // Wait before allowing new requests
  setTimeout(() => {
    isRequestInProgress = false;
    lastRequestTime = 0;
    console.log('[SERVER DELAY] Timeout recovery complete');
  }, 10000);
}

// Function to reset passenger form flags
function resetPassengerFormFlags() {
  console.log('[FLAG RESET] Resetting passenger form flags');
  isPassengerFormSubmitted = false;
  isPassengerFormFilling = false;
}