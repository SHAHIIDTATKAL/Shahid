let user_data = {};
GetVpa();
function addDelay(_0x45a9b7) {
  const _0x3df56a = Date.now();
  let _0x3a0dd6 = null;
  do {
    _0x3a0dd6 = Date.now();
  } while (_0x3a0dd6 - _0x3df56a < _0x45a9b7);
}
let intervalID = '';
function DataHandler() {
  intervalID = setInterval(function () {
    if (!IsInPrograss()) {
      document.querySelector("button").click();
    }
  }, 0xc8);
}
function IsInPrograss() {
  if (document.querySelector("button")) {
    console.log("Show QR button found.");
    clearInterval(intervalID);
    return false;
  }
  return true;
}
function GetVpa() {
  console.log('GetVpa');
  chrome.storage.local.get(null, _0x2bea72 => {
    user_data = _0x2bea72;
    if (document.readyState !== "loading") {
      DataHandler();
    } else {
      document.addEventListener("DOMContentLoaded", function () {
        DataHandler();
      });
    }
  });
}