const container = document.getElementById("versionContainer");
fetch("https://shahidtatkal.github.io/accest/Version.json?nocache=" + new Date().getTime()).then(_0x7a3d28 => _0x7a3d28.json()).then(_0x2a7ef5 => {
  const _0x56289d = _0x2a7ef5.latestVersion;
  const _0x127540 = document.createElement("span");
  _0x127540.textContent = "Version: V1.5.8";
  _0x127540.style.fontWeight = 'bold';
  _0x127540.style.fontSize = "15px";
  const _0x192081 = document.createElement('div');
  _0x192081.appendChild(_0x127540);
  _0x192081.style.fontFamily = "Arial, sans-serif";
  _0x192081.style.paddingLeft = "10px";
  container.appendChild(_0x192081);
}).catch(error => {
  console.log("Version check skipped");
});

document.getElementById('openPopupTab').addEventListener("click", () => {
  chrome.tabs.create({
    'url': chrome.runtime.getURL("popup.html")
  });
});
(function () {
  const _0x5999a9 = setInterval(() => {
    const _0x3281e6 = document.getElementById("clearCheckbox");
    const _0xcd0e5d = document.getElementById("irctc-login");
    const _0x521748 = document.getElementById("irctc-password");
    if (!_0x3281e6 || !_0xcd0e5d || !_0x521748) {
      return;
    }
    clearInterval(_0x5999a9);
    const _0x32c310 = localStorage.getItem("irctcClearCheckbox");
    if (_0x32c310 === "checked") {
      _0x3281e6.checked = true;
      _0x1e918e();
    }
    _0x3281e6.addEventListener('change', function () {
      if (_0x3281e6.checked) {
        _0x1e918e();
        localStorage.setItem("irctcClearCheckbox", "checked");
      } else {
        _0xcd0e5d.disabled = false;
        _0x521748.disabled = false;
        localStorage.setItem("irctcClearCheckbox", "unchecked");
      }
    });
    function _0x1e918e() {
      _0x3d1685(_0xcd0e5d);
      _0x3d1685(_0x521748);
      _0xcd0e5d.disabled = true;
      _0x521748.disabled = true;
    }
    function _0x3d1685(_0x55e019) {
      _0x55e019.value = '';
      _0x55e019.dispatchEvent(new Event('input', {
        'bubbles': true
      }));
      _0x55e019.dispatchEvent(new Event("change", {
        'bubbles': true
      }));
    }
  }, 0x12c);
})();
document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get(["plan_expiry"], _0x407aef => {
    const _0x2176cc = document.getElementById("UserPlanExpairy");
    if (_0x2176cc && _0x407aef.plan_expiry !== undefined) {
      if (_0x407aef.plan_expiry) {
        _0x2176cc.textContent = _0x407aef.plan_expiry;
        const _0x534afb = new Date(_0x407aef.plan_expiry);
        const _0x18a2f0 = new Date();
        _0x2176cc.style.color = _0x18a2f0 <= _0x534afb ? "green" : "red";
      } else {
        _0x2176cc.textContent = "User Not Found";
        _0x2176cc.style.color = "orange";
      }
    }
  });
});
document.addEventListener('DOMContentLoaded', function () {
  const _0x2cfa5e = document.getElementById("submitBtn2autoClickCheckbox");
  chrome.storage.sync.get(["submitBtn2autoClickEnabled"], function (_0x2d5f52) {
    _0x2cfa5e.checked = _0x2d5f52.submitBtn2autoClickEnabled || false;
  });
  _0x2cfa5e.addEventListener("change", function () {
    chrome.storage.sync.set({
      'submitBtn2autoClickEnabled': _0x2cfa5e.checked
    }, function () {
      console.log("Setting saved:", _0x2cfa5e.checked);
    });
  });
});
document.addEventListener('DOMContentLoaded', function () {
  var _0x4e15bf = document.getElementById("cardexpiry");
  if (_0x4e15bf) {
    _0x4e15bf.addEventListener("input", function (_0x314f5a) {
      var _0x59ff38 = _0x314f5a.target.value.replace(/\D/g, '');
      if (_0x59ff38.length > 0x4) {
        _0x59ff38 = _0x59ff38.slice(0x0, 0x4);
      }
      if (_0x59ff38.length >= 0x3) {
        _0x59ff38 = _0x59ff38.slice(0x0, 0x2) + '/' + _0x59ff38.slice(0x2);
      }
      _0x314f5a.target.value = _0x59ff38;
    });
  }
});